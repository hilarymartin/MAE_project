#include "famtypes.h"

bool FT::commonRel(CFamily * f, CIndividual *p1, CIndividual *p2)
{
  bool common=false;
  for (int k=1; k<=f->nInFamily(); k++)
    {
      
      CIndividual * p3 = f->ind(k);
      
      if (p1!=p3 && p2!=p3)
	{
	  
 	  if ( ( p1->isAncestorOf(p3) || p3->isAncestorOf(p1) )  && 
	       ( p2->isAncestorOf(p3) || p3->isAncestorOf(p2) ) )
 	    common=true;	 
	}


//       // And any spouses of p3? 

//       for (int c=1; c<=p3->nChild(); c++) 
// 	{
// 	  CIndividual * p4 = p3->child(c)->pat;
// 	  if (p3==p4) p4 = p3->child(c)->mat;
	  
// 	  // is the spouse either test individual?
// 	  if (p4==p1 || p4==p2) common=true;
	  
// 	  if (p1->isAncestorOf(p4) && 
// 	      p2->isAncestorOf(p4) )
// 	    common=true;
	  
// 	  if (p4->isAncestorOf(p1) && 
// 	      p4->isAncestorOf(p2) )
// 	    common=true;

// 	  if (p1->isAncestorOf(p3) && 
// 	      p2->isAncestorOf(p4) )
// 	    common=true;

// 	  if (p1->isAncestorOf(p4) && 
// 	      p2->isAncestorOf(p3) )
// 	    common=true;

// 	  if (p3->isAncestorOf(p1) && 
// 	      p4->isAncestorOf(p2) )
// 	    common=true;

// 	  if (p4->isAncestorOf(p1) && 
// 	      p3->isAncestorOf(p2) )
// 	    common=true;
	  
//	}

    }
  return common;
}

void FT::printPed(CFamily * fam)
{
  for (int i=1; i<=fam->nInFamily(); i++)  
    {
      OUTPUT << fam->getID() << " ";
      OUTPUT << fam->ind(i)->getID() << " ";
      if (fam->ind(i)->pat != NULL)
	OUTPUT << fam->ind(i)->pat->getID() << " ";
	  else
	    OUTPUT << "0 ";
      
      if (fam->ind(i)->mat != NULL)
	OUTPUT << fam->ind(i)->mat->getID() << " ";
      else
	OUTPUT << "0 ";
      
      OUTPUT << fam->ind(i)->sex << "  " 
	     << fam->ind(i)->bt(1) << "  " 
	     << fam->ind(i)->bt(2) << "  "; 
      OUTPUT << "\n";
    }


}


void FT::printPedDisjoint(CFamily * fam, int ng, vector<int> & grp, bool np)
{

  // To file?
 if (np)
   {

    for (int g=1; g<=ng;g++)
    {
    
      for (int i=1; i<=fam->nInFamily(); i++)  
	{
	  if (grp[i-1]==g)
          {
	    
	    CIndividual * person = fam->ind(i);

	    NEWPED << "GRP"<<g<<"_";
	    NEWPED << fam->getID() << " ";
	    NEWPED << fam->ind(i)->getID() << "   ";
	    
	    if (fam->ind(i)->pat != NULL)
	      NEWPED<< fam->ind(i)->pat->getID() << " ";
	    else
	      NEWPED << "0 ";
	    
	    if (fam->ind(i)->mat != NULL)
	      NEWPED<< fam->ind(i)->mat->getID() << " ";
	    else
	      NEWPED << "0 ";
	    
	    NEWPED << fam->ind(i)->sex << "  "; 
	    
	    
	    if (person != NULL)
	      {
		if (has_Affection_col) NEWPED << person->bt(1) << " "; 
		if (has_Avail_col) NEWPED << person->bt(2) << " ";
		for (int i=1;i<=ex_ph;i++) NEWPED << person->cov(i) << " ";
		for (int i=1;i<=ex_ge;i++) NEWPED << person->loc(i).one << " "
						  << person->loc(i).two << " ";
		
	      }
	    else
	      {
		if (has_Affection_col) NEWPED << "0 ";
		if (has_Avail_col) NEWPED << "0 ";
		for (int i=1;i<=ex_ph;i++) NEWPED << "-9 ";
		for (int i=1;i<=ex_ge;i++) NEWPED << "0 0 ";
	      }
	    
	    NEWPED << "\n";
	  }
	}
    }
}
 else // or to screen??
{
  for (int g=1; g<=ng;g++)
    {
      
      for (int i=1; i<=fam->nInFamily(); i++)  
	{
	  if (grp[i-1]==g) 
	    {
	      
	   OUTPUT << "GRP " << g << " : " ;
	   
	   OUTPUT << fam->ind(i)->getID() << "   ";
	   
	   if (fam->ind(i)->pat != NULL)
	     OUTPUT<< fam->ind(i)->pat->getID() << " ";
	   else
	     OUTPUT << "0 ";
	   
	   if (fam->ind(i)->mat != NULL)
	     OUTPUT << fam->ind(i)->mat->getID() << " ";
	   else
	     OUTPUT << "0 ";
	   
	   OUTPUT << fam->ind(i)->sex << "  " 
		  << fam->ind(i)->bt(1) << " " 
		  << fam->ind(i)->bt(2) ; 
	   OUTPUT << "\n";
	    }
	}
      OUTPUT<< "\n";
    }
}
 
}


void FT::printPedJoint(CFamily * fam)
{

  // Redirect to file? 
  streambuf* saved_buffer;
  saved_buffer = cout.rdbuf();
  cout.rdbuf(NEWPED.rdbuf());
  
    
  for (int i=1; i<=fam->nInFamily(); i++) 
   {

     string pat ="0";
     string mat ="0";
     
     if (fam->ind(i)->pat != NULL) pat=fam->ind(i)->pat->getID();
     if (fam->ind(i)->mat != NULL) mat=fam->ind(i)->mat->getID();

     printPerson(fam->getID(),
		 fam->ind(i)->getID(),
		 pat,mat,
		 fam->ind(i)->sex,
		 fam->ind(i));

    }
  
  // Restore old "cout" buffer
  cout.rdbuf(saved_buffer);


}




MG FT::drawPed(CFamily * fam)
{

  //      m = male unaffected
  //      f = female unaffected
  //      M = male affected
  //      F = female affected
  //      o = unavailable person
  //      O = unavailable, known affected person

  // 1. Display pedigree
  // 2. Get user to choose a single nuclear family

  // Find all offspring, enter parents in list if not
  // previously seen

  vector<CIndividual*> nuc_pat;
  vector<CIndividual*> nuc_mat;
  vector<vector<CIndividual*> > nuc_kid;
  
  for (int i=1; i<=fam->nInFamily(); i++)
    {

      // is this individual a child?
      
      if (!fam->ind(i)->isFounder())
	{
	  
	  CIndividual * kid = fam->ind(i);
	  
	  // do we already have these unique pair
	  // of parents listed?
	  
	  bool seen = false;
	  for (int k=0; k<nuc_pat.size();k++)
	    {
	      if (nuc_pat[k] == kid->pat && 
		  nuc_mat[k] == kid->mat ) 
		seen = true;
	    }
	  if (!seen) 
	    {
	      nuc_pat.push_back(kid->pat);
	      nuc_mat.push_back(kid->mat);
	      
	      vector<CIndividual*> tmp;
	      for (int c=1; c<=fam->nInFamily();c++)
		if (fam->ind(c)->isChildOf(kid->pat) && 
		    fam->ind(c)->isChildOf(kid->mat) )
		  tmp.push_back(fam->ind(c));	      
	      nuc_kid.push_back(tmp);
	    }
	}
      
    }
  
  
  // Did we find any nuclear families?
  // If not, the only possible remaining option is a singleton:
  
  if (nuc_pat.size()==0)
    {
      if (fam->ind(1)->sex == 1) 
	{
	  nuc_pat.push_back(fam->ind(1));
	  nuc_mat.push_back(NULL);
	  vector<CIndividual *> tmp(0);
	  nuc_kid.push_back(tmp);
	}
      else
	{
	  nuc_mat.push_back(fam->ind(1));
	  nuc_pat.push_back(NULL);
	  vector<CIndividual *> tmp(0);
	  nuc_kid.push_back(tmp);

	}
    }
  else
    {
      // Display to screen
      // list nuclear families
  
      for (int k=0; k<nuc_pat.size();k++)
	{
	  OUTPUT << "\n";
	  
	  OUTPUT << "("<<k+1<<")\t";
	  
	  if (inAnother(nuc_pat[k],k,nuc_pat,nuc_mat,nuc_kid))
	    OUTPUT << "<" << nuc_pat[k]->getID() << ">";
	  else
	    OUTPUT << " " << nuc_pat[k]->getID() << " ";	
	  
	  string ftag;
	  if (nuc_pat[k]->bt(1)==2    &&   nuc_pat[k]->bt(2)) ftag =  "{A+}";
	  if (nuc_pat[k]->bt(1)==2    && (!nuc_pat[k]->bt(2))) ftag = "{A-}";
	  if (nuc_pat[k]->bt(1)==1    &&   nuc_pat[k]->bt(2)) ftag =  "{U+}";
	  if (nuc_pat[k]->bt(1)==1    && (!nuc_pat[k]->bt(2))) ftag = "{U-}";
	  if (nuc_pat[k]->bt(1)==0    &&   nuc_pat[k]->bt(2)) ftag =  "{?+}";
	  if (nuc_pat[k]->bt(1)==0    && (!nuc_pat[k]->bt(2))) ftag = "{?-}";
	  
	  OUTPUT << ftag ;
	  
	  OUTPUT << " ----- "; 
	  
	  if (inAnother(nuc_mat[k],k,nuc_pat,nuc_mat,nuc_kid))
	    OUTPUT << "<" << nuc_mat[k]->getID() << ">";
	  else
	    OUTPUT << " " << nuc_mat[k]->getID() ;   
	  
	  string mtag;
	  if (nuc_mat[k]->bt(1)==2    && nuc_mat[k]->bt(2)) mtag =     "{A+}";
	  if (nuc_mat[k]->bt(1)==2    && (!nuc_mat[k]->bt(2))) mtag =  "{A-}";
	  if (nuc_mat[k]->bt(1)==1    && nuc_mat[k]->bt(2)) mtag =     "{U+}";
	  if (nuc_mat[k]->bt(1)==1    && (!nuc_mat[k]->bt(2))) mtag =  "{U-}";
	  if (nuc_mat[k]->bt(1)==0    && nuc_mat[k]->bt(2)) mtag =     "{?+}";
	  if (nuc_mat[k]->bt(1)==0    && (!nuc_mat[k]->bt(2))) mtag =  "{?-}";
	  
	  OUTPUT << mtag << "\n";
	  
	  string spacer(nuc_pat[k]->getID().length()+ftag.length()+5,' ');
	  
	  OUTPUT << "\t" << spacer << "|\n";
	  OUTPUT << "\t" << spacer << "|\n";
	  
	  for (int c=0;c<nuc_kid[k].size();c++)
	    {
	      OUTPUT << "\t" << spacer;
	      if (inAnother(nuc_kid[k][c],k,nuc_pat,nuc_mat,nuc_kid))
		OUTPUT << "<" << nuc_kid[k][c]->getID() << ">";
	      else
		OUTPUT << nuc_kid[k][c]->getID();		 
	      
	      string ktag;
	      if (nuc_kid[k][c]->bt(1)==2    && nuc_kid[k][c]->bt(2))    ktag = "{A+}";
	      if (nuc_kid[k][c]->bt(1)==2    && (!nuc_kid[k][c]->bt(2))) ktag = "{A-}";
	      if (nuc_kid[k][c]->bt(1)==1 && nuc_kid[k][c]->bt(2))       ktag = "{U+}";
	      if (nuc_kid[k][c]->bt(1)==1 && (!nuc_kid[k][c]->bt(2)))    ktag = "{U-}";
	      if (nuc_kid[k][c]->bt(1)==0 && nuc_kid[k][c]->bt(2))       ktag = "{?+}";
	      if (nuc_kid[k][c]->bt(1)==0 && (!nuc_kid[k][c]->bt(2)))    ktag = "{?-}";
	      
	      OUTPUT << " " << ktag;
	      OUTPUT << "\n";
	    }
	  OUTPUT << "\n";
	  
	}
    }

  MG mg;
  mg.nuc_pat = nuc_pat;
  mg.nuc_mat = nuc_mat;
  mg.nuc_kid = nuc_kid;
 
  return mg;
}

bool FT::inAnother(CIndividual * i, int t,
		   vector<CIndividual*> & nuc_pat,
		   vector<CIndividual*> & nuc_mat,
		   vector<vector<CIndividual*> > & nuc_kids)
{
  bool match=false;
  for (int k=0; k<nuc_pat.size(); k++)
    {
      if (k!=t) // do not check current set
	{
	  if (i == nuc_pat[k] || i == nuc_mat[k])
	    match=true;      

	  for (int c=0; c<nuc_kids[k].size();c++)
	    if (i == nuc_kids[k][c]) match=true;
	}
    } 
  return match;  
}


bool FT::yesno(string q)
{
 
while(1)
{
	cout << q << " : [y/n] ? ";
	string a;
      cin >> a;
      
	if (a=="y" || a=="yes" || a=="Y" || a=="YES" || a=="Yes") return true;
	if (a=="n" || a=="no" || a=="N" || a=="NO" || a=="No") return false;
}
	
}


void FT::printPerson(string fid, string iid, string pat, string mat, int sex, 
		     CIndividual * person)
{
  cout << fid << " "
       << iid << " "
       << pat << " "
       << mat << " "
       << sex << " ";
  
  if (person != NULL)
    {
      if (has_Affection_col) 
	cout << person->bt(1) << " ";
      if (has_Avail_col) 
	cout << person->bt(2) << " ";
      for (int i=1;i<=ex_ph;i++) 
	cout << person->cov(i) << " ";
      for (int i=1;i<=ex_ge;i++) 
	cout << person->loc(i).one << " "
	     << person->loc(i).two << " ";

    }
  else
    {
      if (has_Affection_col) cout << "0 ";
      if (has_Avail_col) cout << "0 ";
      for (int i=1;i<=ex_ph;i++) cout << "-9 ";
      for (int i=1;i<=ex_ge;i++) cout << "0 0 ";
    }
  cout << "\n";
  
}
