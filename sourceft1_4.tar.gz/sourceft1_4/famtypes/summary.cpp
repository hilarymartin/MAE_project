#include "famtypes.h"

 
void FT::summary1()
{
  
  cout << "Writing initial summary statistics to [ " << outputfile << " ]\n";
  
  OUTPUT << "Initial file summary statistics:\n"
      << "--------------------------------\n";
  
  // 1. Number of families read
  OUTPUT << sample.countFamily() << " families selected\n";
  OUTPUT << sample.countIndividual() << " individuals selected\n";

  // 2. Distribution of family size
  
  vector<int> size(200);
  for (int f=1; f<=sample.countFamily(); f++)
    size[sample.fam(f)->nInFamily()]++;

  OUTPUT << "\nTable of family N\n";
  for (int i=1;i<200;i++)
    if (size[i]>0) OUTPUT << i << "\t" << size[i] << "\n";
  OUTPUT << "\n";


  // Number of founders per family
  size.clear();
  size.resize(200);

  for (int f=1; f<=sample.countFamily(); f++)
    {
      int fnd=0;
      for (int i=1; i<=sample.fam(f)->nInFamily(); i++)
        {
          
          CIndividual * person = sample.fam(f)->ind(i);
          if (person->isFounder()) fnd++;
          
        }
      size[fnd]++;
    }
  
  OUTPUT << "# founder per family\n";
  for (int i=1;i<200;i++)
    if (size[i]>0) OUTPUT << i << "\t" << size[i] << "\n";
  OUTPUT << "\n";
  

  // Number of non-founders per family
  size.clear();
  size.resize(200);

  for (int f=1; f<=sample.countFamily(); f++)
    {
      int fnd=0;
      for (int i=1; i<=sample.fam(f)->nInFamily(); i++)
        {
          
          CIndividual * person = sample.fam(f)->ind(i);
          if (!person->isFounder()) fnd++;
          
        }
      size[fnd]++;
    }

  OUTPUT << "# non-founder per family\n";
  for (int i=1;i<200;i++)
    if (size[i]>0) OUTPUT << i << "\t" << size[i] << "\n";
  OUTPUT << "\n";


  // Number of trios

  OUTPUT << " # of parent-offspring trios = ";
  int nt=0;
  for (int i=1;i<200;i++)
    nt += size[i]*i;
  OUTPUT << nt << "\n";


}


void FT::summary2()
{

  cout << "Writing breakdown of family types to [ " << outputfile << " ]\n"
       << "...might take a while...\n";

  // More complete breakdown of families

  vector<int> f_pat;   // # father
  vector<int> f_pat2;  // # aff father
  vector<int> f_pat1;  // # unaff father
  vector<int> f_pat0;  // # missing father

  vector<int> f_mat;  // # father
  vector<int> f_mat2;  // # aff father
  vector<int> f_mat1;  // # unaff father
  vector<int> f_mat0;  // # missing father

  vector<int> f_boy;  // # boys
  vector<int> f_boy2;  // # aff boys
  vector<int> f_boy1;  // # unaff boys
  vector<int> f_boy0;  // # missing boys

  vector<int> f_grl;  // # girls
  vector<int> f_grl2;  // # aff girls
  vector<int> f_grl1;  // # unaff girls
  vector<int> f_grl0;  // # missing girls


  for (int f0=1; f0<=sample.countFamily(); f0++)
    {
      
      int c_pat=0;   // # father
      int c_pat2=0;  // # aff father
      int c_pat1=0;  // # unaff father
      int c_pat0=0;  // # missing father
      
      int c_mat=0;   // # father
      int c_mat2=0;  // # aff father
      int c_mat1=0;  // # unaff father
      int c_mat0=0;  // # missing father
      
      int c_boy=0;   // # boys
      int c_boy2=0;  // # aff boys
      int c_boy1=0;  // # unaff boys
      int c_boy0=0;  // # missing boys
      
      int c_grl=0;   // # girls
      int c_grl2=0;  // # aff girls
      int c_grl1=0;  // # unaff girls
      int c_grl0=0;  // # missing girls

      for (int i=1; i<=sample.fam(f0)->nInFamily(); i++)
	{		  
	  CIndividual * person = sample.fam(f0)->ind(i);
	  
	  if (person->isFounder() && person->bt(2))
	    {
	      if (person->sex==1)
		{
		  c_pat++;
		  if (person->bt(1)==2) c_pat2++;
		  if (person->bt(1)==1) c_pat1++;
		  if (person->bt(1)==0) c_pat0++;
		}
	      else if (person->sex==2)
		{
		  c_mat++;
		  if (person->bt(1)==2) c_mat2++;
		  if (person->bt(1)==1) c_mat1++;
		  if (person->bt(1)==0) c_mat0++;
		}
	    }
	  else if ((!person->isFounder()) && person->bt(2))
	    {
	      if (person->sex==1)
		{
		  c_boy++;
		  if (person->bt(1)==2) c_boy2++;
		  if (person->bt(1)==1) c_boy1++;
		  if (person->bt(1)==0) c_boy0++;
		}
	      else if (person->sex==2)
		{
		  c_grl++;
		  if (person->bt(1)==2) c_grl2++;
		  if (person->bt(1)==1) c_grl1++;
		  if (person->bt(1)==0) c_grl0++;
		}
	    }
	}

      f_pat.push_back(c_pat);
      f_pat2.push_back(c_pat2);
      f_pat1.push_back(c_pat1);
      f_pat0.push_back(c_pat0);

      f_mat.push_back(c_mat);
      f_mat2.push_back(c_mat2);
      f_mat1.push_back(c_mat1);
      f_mat0.push_back(c_mat0);

      f_boy.push_back(c_boy);
      f_boy2.push_back(c_boy2);
      f_boy1.push_back(c_boy1);
      f_boy0.push_back(c_boy0);

      f_grl.push_back(c_grl);
      f_grl2.push_back(c_grl2);
      f_grl1.push_back(c_grl1);
      f_grl0.push_back(c_grl0);
      
    }
  
  int m_pat, m_pat2, m_pat1, m_pat0;
  int m_mat, m_mat2, m_mat1, m_mat0;
  int m_boy, m_boy2, m_boy1, m_boy0;
  int m_grl, m_grl2, m_grl1, m_grl0;

  m_pat= m_pat2= m_pat1= m_pat0=0;
  m_mat= m_mat2= m_mat1= m_mat0=0;
  m_boy= m_boy2= m_boy1= m_boy0=0;
  m_grl= m_grl2= m_grl1= m_grl0=0;


  for (int i=0; i<f_pat.size(); i++)
    {

      if (f_pat[i]>m_pat) m_pat=f_pat[i];
      if (f_pat2[i]>m_pat2) m_pat2=f_pat2[i];
      if (f_pat1[i]>m_pat1) m_pat1=f_pat1[i];
      if (f_pat0[i]>m_pat0) m_pat0=f_pat0[i];

      if (f_mat[i]>m_mat) m_mat=f_mat[i];
      if (f_mat2[i]>m_mat2) m_mat2=f_mat2[i];
      if (f_mat1[i]>m_mat1) m_mat1=f_mat1[i];
      if (f_mat0[i]>m_mat0) m_mat0=f_mat0[i];

      if (f_boy[i]>m_boy) m_boy=f_boy[i];
      if (f_boy2[i]>m_boy2) m_boy2=f_boy2[i];
      if (f_boy1[i]>m_boy1) m_boy1=f_boy1[i];
      if (f_boy0[i]>m_boy0) m_boy0=f_boy0[i];

      if (f_grl[i]>m_grl) m_grl=f_grl[i];
      if (f_grl2[i]>m_grl2) m_grl2=f_grl2[i];
      if (f_grl1[i]>m_grl1) m_grl1=f_grl1[i];
      if (f_grl0[i]>m_grl0) m_grl0=f_grl0[i];

  }

 
  OUTPUT << "\nCounts of available individuals per family:\n\n"
       << "Paternal      Maternal      Boy           Girl           \n"
       << "----------    ----------    ----------    ----------     \n"
       << "*  A  U  ?    *  A  U  ?    *  A  U  ?    *  A  U  ?    N\n"
       << "----------    ----------    ----------    ----------    -\n";
  
  for (int l_pat=0;  l_pat <=m_pat;  l_pat++)
  for (int l_pat2=0; l_pat2<=m_pat2; l_pat2++)
  for (int l_pat1=0; l_pat1<=m_pat1; l_pat1++)
  for (int l_pat0=0; l_pat0<=m_pat0; l_pat0++)

  for (int l_mat=0;  l_mat <=m_mat;  l_mat++)
  for (int l_mat2=0; l_mat2<=m_mat2; l_mat2++)
  for (int l_mat1=0; l_mat1<=m_mat1; l_mat1++)
  for (int l_mat0=0; l_mat0<=m_mat0; l_mat0++)

  for (int l_boy=0;  l_boy <=m_boy;  l_boy++)
  for (int l_boy2=0; l_boy2<=m_boy2; l_boy2++)
  for (int l_boy1=0; l_boy1<=m_boy1; l_boy1++)
  for (int l_boy0=0; l_boy0<=m_boy0; l_boy0++)

  for (int l_grl=0;  l_grl <=m_grl;  l_grl++)
  for (int l_grl2=0; l_grl2<=m_grl2; l_grl2++)
  for (int l_grl1=0; l_grl1<=m_grl1; l_grl1++)
  for (int l_grl0=0; l_grl0<=m_grl0; l_grl0++)
    {

      
      int f=0;
      for (int i=0; i<f_pat.size(); i++)
	if (f_pat[i] ==l_pat && 	 
	    f_pat2[i]==l_pat2 && 
	    f_pat1[i]==l_pat1 && 
	    f_pat0[i]==l_pat0 && 
	    f_mat[i] ==l_mat && 	 
	    f_mat2[i]==l_mat2 && 
	    f_mat1[i]==l_mat1 &&
	    f_mat0[i]==l_mat0 &&
	    f_boy[i] ==l_boy && 	 
	    f_boy2[i]==l_boy2 && 
	    f_boy1[i]==l_boy1 &&
	    f_boy0[i]==l_boy0 &&
	    f_grl[i] ==l_grl && 	 
	    f_grl2[i]==l_grl2 && 
	    f_grl1[i]==l_grl1 &&
	    f_grl0[i]==l_grl0 ) f++;
      
      if (f>0) OUTPUT << l_pat  << "  " 
 		    << l_pat2 << "  "
 		    << l_pat1 << "  "
 		    << l_pat0 << "    "
 		    << l_mat  << "  " 
 		    << l_mat2 << "  "
 		    << l_mat1 << "  "
 		    << l_mat0 << "    "
 		    << l_boy  << "  " 
 		    << l_boy2 << "  "
 		    << l_boy1 << "  "
 		    << l_boy0 << "    "
 		    << l_grl  << "  " 
 		    << l_grl2 << "  "
 		    << l_grl1 << "  "
 		    << l_grl0 << "    "
 		    << f << "\n";      
          

  }
  
  
  OUTPUT << "\n";


  // Now repeat, but collapsing over sex
 
  OUTPUT << "\n\n"
       << "Parent        Offspring      \n"
       << "----------    ----------     \n"
       << "*  A  U  ?    *  A  U  ?    N\n"
       << "----------    ----------    -\n";
  
  for (int l_pat=0;  l_pat <=m_pat+m_mat;  l_pat++)
  for (int l_pat2=0; l_pat2<=m_pat2+m_mat2; l_pat2++)
  for (int l_pat1=0; l_pat1<=m_pat1+m_mat1; l_pat1++)
  for (int l_pat0=0; l_pat0<=m_pat0+m_mat0; l_pat0++)

  for (int l_boy=0;  l_boy <=m_boy+m_grl;  l_boy++)
  for (int l_boy2=0; l_boy2<=m_boy2+m_grl2; l_boy2++)
  for (int l_boy1=0; l_boy1<=m_boy1+m_grl1; l_boy1++)
  for (int l_boy0=0; l_boy0<=m_boy0+m_grl0; l_boy0++)

    {
      
      int f=0;
      for (int i=0; i<f_pat.size(); i++)
	if (f_pat[i]+f_mat[i] ==l_pat && 	 
	    f_pat2[i]+f_mat2[i]==l_pat2 && 
	    f_pat1[i]+f_mat1[i]==l_pat1 && 
	    f_pat0[i]+f_mat0[i]==l_pat0 && 
	    f_boy[i]+f_grl[i] ==l_boy && 	 
	    f_boy2[i]+f_grl2[i]==l_boy2 && 
	    f_boy1[i]+f_grl1[i]==l_boy1 &&
	    f_boy0[i]+f_grl0[i]==l_boy0 ) f++;
      
      if (f>0) OUTPUT << l_pat  << "  " 
 		    << l_pat2 << "  "
 		    << l_pat1 << "  "
 		    << l_pat0 << "    "
		    << l_boy  << "  " 
 		    << l_boy2 << "  "
 		    << l_boy1 << "  "
 		    << l_boy0 << "    "
		    << f << "\n";      
          

  }
  
  
  OUTPUT << "\n";


  // Now, breakdown by ...
  // and summarise

  int avail_ind_cnt=0;
  int avail_fam_cnt=0;

  OUTPUT << "\n\n"
       << "Parent        Offspring      \n"
       << "----------    ----------     \n"
       << "*             *  A  U  ?    N\n"
       << "----------    ----------    -\n";
  
  for (int l_pat=0;  l_pat <=m_pat+m_mat;  l_pat++)
  for (int l_boy=0;  l_boy <=m_boy+m_grl;  l_boy++)
  for (int l_boy2=0; l_boy2<=m_boy2+m_grl2; l_boy2++)
  for (int l_boy1=0; l_boy1<=m_boy1+m_grl1; l_boy1++)
  for (int l_boy0=0; l_boy0<=m_boy0+m_grl0; l_boy0++)

    {
      
      int f=0;
      for (int i=0; i<f_pat.size(); i++)
	if (f_pat[i]+f_mat[i] ==l_pat && 	 
	    f_boy[i]+f_grl[i] ==l_boy && 	 
	    f_boy2[i]+f_grl2[i]==l_boy2 && 
	    f_boy1[i]+f_grl1[i]==l_boy1 &&
	    f_boy0[i]+f_grl0[i]==l_boy0 ) f++;
      
      if (f>0) OUTPUT << l_pat  << "  " 
 		    << "   "
 		    << "   "
 		    << "     "
		    << l_boy  << "  " 
 		    << l_boy2 << "  "
 		    << l_boy1 << "  "
 		    << l_boy0 << "    "
		    << f << "\n";      

      avail_ind_cnt += f * ( l_pat + l_boy ) ;
      avail_fam_cnt += f;
  }

}
