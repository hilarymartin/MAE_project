#include "famtypes.h"

// 0. Check that everybody is either a founder "0 0" 
//    or has two parents fully-specified in the .ped file


bool FT::check_parents()
{
  
  cout << "Searching for missing parents...";
  
  bool alter = false;
  // Normal mode
  if (!treat_unrel_as_sibs)
    {

      for (int f=1; f<=sample.countFamily(); f++)
	for (int i=1; i<=sample.fam(f)->nInFamily(); i++)
	  {
	    CIndividual * person = sample.fam(f)->ind(i);
	    
	    if ( (!person->isFounder()) && 
		 (person->pat == NULL || 
		  person->mat == NULL ) ) { 
	      person->flag = true;
	      alter = true; 
	    }
	  }
    }
  else
    {
      for (int f=1; f<=sample.countFamily(); f++)
	{
	  bool family_has_nonfounder = false;
	  
	  for (int i=1; i<=sample.fam(f)->nInFamily(); i++)
	    if (!sample.fam(f)->ind(i)->isFounder() )
	      family_has_nonfounder = true;
	  
	  if (family_has_nonfounder)
	    {
	      // check for missing parents as per usual, in any case
	      
	      for (int i=1; i<=sample.fam(f)->nInFamily(); i++)
		{
		  CIndividual * person = sample.fam(f)->ind(i);
		  
		  if ( (!person->isFounder()) && 
		       (person->pat == NULL || 
			person->mat == NULL ) ) { 
		    person->flag = true;
		    alter = true; 
		  }
		}
	    }
	  else if (sample.fam(f)->nInFamily()>1)
	    {
	      // this family is all non-founders : if size is >1, then assume these
	      // are siblings, as treat_unrel_as_sibs = T
	      
	      for (int i=1; i<=sample.fam(f)->nInFamily(); i++)
		sample.fam(f)->ind(i)->flag = true;
	      alter=true;
	    }
	  
	}
    }
  

  
  
   // Need to rewrite pedigree
   if (alter)
     {
       
       cout << " found: generating missing parents\n";
       
       NEWPED.open(newpedfile.c_str(),ios::out);              
       streambuf* saved_buffer;
       saved_buffer = cout.rdbuf();
       cout.rdbuf(NEWPED.rdbuf());
       
       int dc = 1;
       
       for (int f=1; f<=sample.countFamily(); f++)
	 {

	   // list of newly created parents: so as not to duplicate
	   vector<string> already_added;
	   
	   for (int i=1; i<=sample.fam(f)->nInFamily(); i++)
	     {
	       
	       CIndividual * person = sample.fam(f)->ind(i);
	       
	       if ( person->flag ) 
		 {
		   
		   OUTPUT << "WARNING: [ MISSING PARENTS ] : family " 
			  << person->family->getID() << " person " 
			  << person->getID() << " has 1 or more missing parents.\n"
			  << "WARNING: will add as necessary and flag as 'unavailable'\n\n";
		   
		   
		   // missing father
		   
		   if (person->pat == NULL && person->mat !=NULL)
		     {
		       
		       string dummy;		     
		       map<string,string>::iterator it = pat.find(person->family->getID()+"_"+person->getID());
		       if (it!=pat.end()) dummy = it->second;
		       else dummy = "DUMM"+int2str(dc++);
		       
		       printPerson(person->family->getID(),
				   person->getID(),
				   dummy,
				   person->mat->getID(),
				   person->sex,
				   person);
		     
		     bool added = false;
		     for (int z=0;z<already_added.size();z++) 
		       if (dummy==already_added[z]) added = true;
		     if (!added) 
		       {
			 printPerson(person->family->getID(),dummy,"0","0",1,NULL);
			 already_added.push_back(dummy);
		       }
		     }
		   else if (person->pat != NULL && person->mat == NULL)
		     {
		       		       
		       string dummy;		     
		       map<string,string>::iterator it = mat.find(person->family->getID()+"_"+person->getID());
		       if (it!=mat.end()) dummy = it->second;
		       else dummy = "DUMM"+int2str(dc++);
		       
		       
		       printPerson(person->family->getID(),
				   person->getID(),
				   person->pat->getID(), 
				   dummy,
				   person->sex,
				   person);
		       
		       bool added = false;
		       for (int z=0;z<already_added.size();z++) 
			 if (dummy==already_added[z]) added = true;
		       if (!added) 
			 {
			   printPerson(person->family->getID(),
				       dummy, "0","0",2,NULL);
			   already_added.push_back(dummy);
			 }
		       
		     }
		   else
		     {
		       // Both father and mother must be missing...
		       
		       
		       // Both parents missing : if treat_unrel_as_sibs flag is set, 
		       // then impute the same parents when both are missing
		       
		       string dummy1;		     
		       string dummy2;		     
		       
		       if (!treat_unrel_as_sibs)
			 {
			   map<string,string>::iterator it = pat.find(person->family->getID()+"_"+person->getID());
			   if (it!=pat.end()) dummy1 = it->second;
			   else dummy1 = "DUMM"+int2str(dc++);
			   
			   it = mat.find(person->family->getID()+"_"+person->getID());
			   if (it!=mat.end()) dummy2 = it->second;
			   else dummy2 = "DUMM"+int2str(dc++);
			 }
		       else
			 {
			   dummy1 = "DUMMA";
			   dummy2 = "DUMMB";			   
			 }

		     printPerson(person->family->getID(),
				 person->getID(),
				 dummy1, 
				 dummy2, 
				 person->sex,
				 person);

		     bool added = false;
		     for (int z=0;z<already_added.size();z++) 
		       if (dummy1==already_added[z]) added = true;
		     if (!added) 
		       {
			 printPerson(person->family->getID(),
				     dummy1,"0","0",1,NULL);
			 already_added.push_back(dummy1);
		       }
		     
		     
  		     added = false;
		     for (int z=0;z<already_added.size();z++) 
		       if (dummy2==already_added[z]) added = true;
		     if (!added) 
		       {
			 printPerson(person->family->getID(),
				     dummy2,"0","0",2,NULL);
			 already_added.push_back(dummy2);
		       }
		     
		     
		   }     
		 }
	       else
		 {
		   if (person->isFounder())
		     printPerson(person->family->getID(),
				 person->getID(),
				 "0", "0", person->sex, person);
		   else
		     printPerson(person->family->getID(),
				 person->getID(),
				 person->pat->getID(), 
				 person->mat->getID(),
				 person->sex, person);
		 }
	     
	     }
	 }
       
       
       // Restore old "cout" buffer
       cout.rdbuf(saved_buffer);
       NEWPED.close();
	        
       
       cout << "About to reprocess file...\n";
       pedfile = newpedfile;
       return false;
     }
   else 
     {
       cout << " all okay\n";
       return true;
     }
   
}
