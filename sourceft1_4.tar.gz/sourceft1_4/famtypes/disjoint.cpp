#include "famtypes.h"

////////////////////////////////////////////
// Disjoint families



bool FT::check_disjoint()
{

  cout << "Checking for disjoint families...";
  
  int d=0;
  
  NEWPED.open(newpedfile.c_str(),ios::out);
  
  for (int f=1; f<=sample.countFamily(); f++)
    {
      
      
      vector<vector<bool> > joins(sample.fam(f)->nInFamily());
      
      for (int i=0;i<joins.size();i++)
	joins[i].resize(sample.fam(f)->nInFamily());
      
      bool atleast1dis=false;
      if (sample.fam(f)->nInFamily()>1) 
	{
	  for (int i=1; i<sample.fam(f)->nInFamily(); i++)
	    {
	      for (int j=i+1; j<=sample.fam(f)->nInFamily(); j++)
		{
		  bool disjoint=false;
		  
		  if (i!=j) {
		    CIndividual * p1 = sample.fam(f)->ind(i);
		    CIndividual * p2 = sample.fam(f)->ind(j);		
		    
		    // If they are not each others
		    // ancestors
		    if (! ( p1->isAncestorOf(p2) || p2->isAncestorOf(p1) ) )
		      disjoint=true;
		    
		    if (disjoint)
		      {
			// and if they share no common 
			// ancestor or descendent
			if (commonRel(sample.fam(f),p1,p2)) disjoint=false;
			
			if (disjoint)
			  {
			    
			    for (int sp1=1; sp1<=p1->nChild(); sp1++)		    
			      {
				CIndividual * p3 = p1->child(sp1)->pat;
				if (p1==p3) p3 = p1->child(sp1)->mat;
				if(p2->isAncestorOf(p3) || p3->isAncestorOf(p2)) disjoint=false;
				if(commonRel(sample.fam(f),p2,p3)) disjoint=false;
			      }
			    
			    
			    if (disjoint)
			      {
				for (int sp2=1; sp2<=p2->nChild(); sp2++)		    
				  {
				    CIndividual * p4 = p2->child(sp2)->pat;
				    if (p2==p4) p4 = p2->child(sp2)->mat;
				    if(p1->isAncestorOf(p4) || p4->isAncestorOf(p1)) disjoint=false;  
				    if(commonRel(sample.fam(f),p1,p4)) disjoint=false;
				  }
				
				if (disjoint)
				  {
				    // Consider all spouses of p1 and p2
				    // and that their spouse isn't connected either
				    for (int sp1=1; sp1<=p1->nChild(); sp1++)
				      {
					CIndividual * p3 = p1->child(sp1)->pat;
					if (p1==p3) p3 = p1->child(sp1)->mat;
					
					for (int sp2=1; sp2<=p2->nChild(); sp2++)
					  {
					    CIndividual * p4 = p2->child(sp2)->pat;
					    if (p2==p4) p4 = p2->child(sp2)->mat;
					    
					    if(commonRel(sample.fam(f),p1,p4)) disjoint=false;
					    if(commonRel(sample.fam(f),p3,p2)) disjoint=false;
					    if(commonRel(sample.fam(f),p3,p4)) disjoint=false;
					  }
				      }
				    
				  }
			      }
			  }
		      }
		    
		    
		    if (disjoint) 
		      {
			atleast1dis = true;
			joins[i-1][j-1] = joins[j-1][i-1] = false;
		      }
		    else
		      joins[i-1][j-1] = joins[j-1][i-1] = true;
		    
		    // 		    if (atleast1dis) cout << "caught out on fam " 
		    // 					  << sample.fam(f)->getID() << " : "
		    // 					  << p1->getID() << "  " 
		    // 					  << p2->getID() << "\n";
		    
		  }
		}
	    }
	  
	  if (atleast1dis) 
	    { 

	      // Figure out what the joined groups are:
	      // using joins[][]
	      

	      // Keep filling in redundant connections in joins[][]
	      bool done=false;
	      while (!done) 
		{
		  bool ncon=false;
		  // take each pair, try to add a new connection
		  // by considering a third individual
		  for (int i=0;i<joins.size();i++)
		    for (int j=0;j<joins.size();j++)
		      for (int k=0;k<joins.size();k++)
			{
			  if (!joins[i][j])
			    if (joins[i][k] && joins[j][k])
			      {
				joins[i][j]=true;
				ncon=true;
			      }
			}  
		  if (!ncon) done=true;
		}
	      
	      vector<int> group(joins.size(),0);
	      
	      int ng=0;
	      
	      // Set first individual to first group (1)
	      group[0] = ++ng;
	      
	      // Consider all other individuals
	      for (int i=2;i<=sample.fam(f)->nInFamily();i++)
		{
		  
		  // Find a person with whom we have a connection
		  for (int j=1;j<=sample.fam(f)->nInFamily();j++)
		    {
		      if (i!=j) // is not self
			{
			  
			  // connects, and has already been assigned a group

			  if ( ( joins[i-1][j-1] || joins[j-1][i-1] ) && group[j-1]!=0)
			    {
			      group[i-1] = group[j-1];
			      goto done_here;
			    }
			}
		    }
		done_here:
		  // if not assigned to a group, make a new one
		  if (group[i-1]==0) 
		    group[i-1]= ++ng;
		}
	      
	      // After trying to connect everything, do we still have >1 group?
	      // If so, the family is disjoint
	      if (ng>1)
		{
		  d++;
		  OUTPUT << "\n >>> *** Family " << sample.fam(f)->getID() 
		         << " is disjoint *** <<< \n\n";
		}
	      
	      if (ng>1) 
		{
		  printPedDisjoint(sample.fam(f),ng,group,true);
		  printPedDisjoint(sample.fam(f),ng,group,false);

		  drawPed(sample.fam(f));
		  
		}
	      else
		{
		  printPedJoint(sample.fam(f));
		}
	      
	      
	    }
	  else
	    {
	      // remember to save normal families also
	      if (newped)
		printPedJoint(sample.fam(f));
	    }
	}
      else
	{
	  // remember to save singletons
	  if (newped)
	    printPedJoint(sample.fam(f));	 
	}
    }
  
  if (newped)
    NEWPED.close();
  
  if (d>0)
    {
      
      cout << "In total, there were " << d  
	   << " disjoint families\n";
      if (newped) cout << "The corrected file has been saved [ " << newpedfile << " ]\n";
      else cout << "Suggest using the save to file option to correct this\n";

      pedfile = newpedfile;
      return false;
      
    }
   else 
     {
       cout << "ALL OKAY!\n\n";
       return true;
     }

}
