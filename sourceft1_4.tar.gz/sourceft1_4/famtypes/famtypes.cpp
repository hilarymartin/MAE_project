#include "famtypes.h"

using namespace std;


// TODO list
//  * specify a filter in terms of the freq count items
//  * search and list any half sibs
//  * check sex of father and mother matches; 

FT::FT() 
{
  has_Affection_col = true;
  has_Avail_col = true;
  really_has_Avail_col = false;
  extra_cols = 0;
  cargs.resize(0);
}

int main(int argc, char* argv[]) 
{

 
  CRandom::srand(time(0));
  
  
  cout << "\n\n";
  cout << " +-----------------------------------------------+\n"
       << " +   FAMTYPES v1.4   |   S. Purcell, L. Thomas   +\n"
       << " +-----------------------------------------------+\n"
       << " + http://pngu.mgh.harvard.edu/purcell/famtypes/ +\n"
       << " +-----------------------------------------------+\n";
  
  FT ft;
  
  if (argc==1) ft.cmdline = false;
  else if (argc==10) 
    {
      ft.cmdline = true;
      for (int i=1; i<argc; i++) ft.cargs.push_back(argv[i]);
    }
  else error("Need either 0 or 9 command line elements... see documentation.");
 

  bool skip_MG = false;
    
  
  ft.preinput();

 repeat_from_here:
    
  ft.loadfile();


  if (!ft.check_parents()) goto repeat_from_here;
  
  ft.summary1();

  
  if (!ft.check_disjoint()) goto repeat_from_here;


  if (!skip_MG) 
  {  
    if (!ft.check_multigen()) 
      { 
	skip_MG=true; 
	goto repeat_from_here; 
      }
  }

  ft.summary2();

  // Final step
 
  if (!ft.really_has_Avail_col)
    ft.has_Avail_col = false;

  // Call this merely to print out PED again, 
  // but without the Avail col, if there was none
  // to start with

  ft.final_display();
    
    
  // close files
  ft.OUTPUT.close();
  
  
}


