#ifndef __FAMTYPES__
#define __FAMTYPES__

#include <iostream>
#include <fstream>
#include <string>
#include "shaunlib.h"
#include <time.h>
#include <map>


class MG { 
 public:
  vector<CIndividual*> nuc_pat;
  vector<CIndividual*> nuc_mat;
  vector<vector<CIndividual*> > nuc_kid;
};



class FT
{
 public:

  FT();
  
  void preinput();
  void loadfile();
  void summary1();
  void summary2();
  bool check_parents();
  bool check_disjoint();
  bool check_multigen();
  bool final_display();  
  


  void printPerson(string fid, string iid, string pat, string mat, int sex, 
		   CIndividual * person);
  bool commonRel(CFamily * f, CIndividual *p1, CIndividual *p2);
  void printPed(CFamily * fam);
  MG drawPed(CFamily * fam);
  void printPedDisjoint(CFamily * fam, int,vector<int> &, bool);
  void printPedJoint(CFamily * fam);
  bool inAnother(CIndividual * i, int,
		 vector<CIndividual*> & nuc_pat,
		 vector<CIndividual*> & nuc_mat,
		 vector<vector<CIndividual*> > & nuc_kids);
  bool yesno(string);
  
  
  // output files
  bool newped;
  ofstream NEWPED;
  ofstream OUTPUT;
  ifstream CHECKPED;
  
  bool has_Affection_col;
  bool has_Avail_col;
  bool really_has_Avail_col;
  bool treat_unrel_as_sibs;
  int extra_cols;
  int ex_ge;
  int ex_ph;
  
  bool cmdline;
  vector<string> cargs;
  
  string pedfile;
  string newpedfile;
  string outputfile;

  CSample sample;
  CDatfile dat;
  CMap locmap;

  map<string,string> pat;
  map<string,string> mat;


};



#endif
