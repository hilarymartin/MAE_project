#include "famtypes.h"
#include <map>
 
//////////////////////////////////
// Display final PED file (w/out Avail col 
// is so desired)

bool FT::final_display()
{

  NEWPED.open(newpedfile.c_str(),ios::out);
           
  // Redirect to file? 
  streambuf* saved_buffer;
  saved_buffer = cout.rdbuf();
  cout.rdbuf(NEWPED.rdbuf());
  
  // Iterate over each family
  for (int f=1; f<=sample.countFamily(); f++)
    {
      for (int i=1; i<=sample.fam(f)->nInFamily(); i++)            
	{
	  CIndividual * person = sample.fam(f)->ind(i);

	  string spat,smat;

	  if (person->pat == NULL) spat = "0";
	  else spat = person->pat->getID();
	  
	  if (person->mat == NULL) smat = "0";
	  else smat = person->mat->getID();

	  printPerson(person->family->getID(),
		      person->getID(),
		      spat,
		      smat,
		      person->sex,
		      person);
	  
	}

    } // Next nuclear family within this entire family

  
  // Restore old "cout" buffer
  cout.rdbuf(saved_buffer);
	  
  // Close down files, etc
  NEWPED.close();

  return true;
}
