#include "famtypes.h"
#include <stdio.h>
#include <list>

// input file

void FT::preinput()
{

  if (cmdline)
    {
      pedfile = cargs[0];
    }
  else
    {
      pedfile = "data.ped";
      cout << "\n\nName of ped file [data.ped]: ";
      string tmp;
      cin >> tmp;
      if (tmp!="") pedfile = tmp;
    }

  
  if (cmdline)
    {
      has_Affection_col = has_Avail_col = really_has_Avail_col = treat_unrel_as_sibs = false;
      if (cargs[1] == "y" || cargs[1] == "Y")
        has_Affection_col = true;
      if (cargs[2] == "y" || cargs[2] == "Y")
	has_Avail_col = really_has_Avail_col = true;
      if (cargs[3] == "y" || cargs[3] == "Y")
	treat_unrel_as_sibs = true;
    }
  else
    {

      cout << "PED file may contain one or more of the following\n"
           << "but, if present, they *must* be in this order\n"
           << "starting from column 6 onwards\n\n"
           << "  1)  Affection status (0=missing;1=no;2=yes) \n"
           << "  2)  Availability (0=not available;1=available) \n"
           << "  3)  Any other phenotype or covariate columns\n"
           << "  4)  Any other genotypes\n\n";


      has_Affection_col = yesno("Does this file have an affection status column");      
      has_Avail_col = yesno("Does this file have an availability column");
      really_has_Avail_col = has_Avail_col;
      treat_unrel_as_sibs = yesno("Completely disjoint family == siblings?");
    }


  // TEMP///

//  if (!has_Avail_col) 
//    error("I'm sorry... for now you need to always have an availability column\n(code all as 1's if not applicable)\n");
  

  int ec = 5;
  if (has_Affection_col) ec++;
  if (has_Avail_col) ec++;

  if(cmdline)
    {
      ex_ph = atoi(cargs[4].c_str());
      ex_ge = atoi(cargs[5].c_str());
    }
  else
    {
      cout << "\nHow many other other phenotypes, covariates beyond column " 
          << ec << " : ";
      cin >> ex_ph;
  
      cout << "How many other other genotypes (#genos, not #cols) beyond column " 
           << ec + ex_ph << " : ";
      ex_ge = 0;
      cin >> ex_ge;
    } 
 
  // Check the PEDFILE
  int totcol = ec + ex_ph + 2 * ex_ge;
  cout << "\nBased on your inputs, the ped file should contain " << totcol << " columns...";
  CHECKPED.open(pedfile.c_str());
  if (CHECKPED.fail()) 
  {
    cout << "\n[" << pedfile << "] does not exist\n";
    exit(0);
  }

  string dummy;
  int cnt=0;

  do 
  {
    CHECKPED >> dummy;
    if(CHECKPED.eof()) break;
    if (dummy!="") cnt++;
  }  	while(!CHECKPED.eof());
  
  if (cnt % totcol !=0 ) 
    { 
      cout << "\n\nERROR: Number of items in ped file is not a multiple of " << totcol << "\n"; 
      cout << "1) check that the last line has a carriage return after last item\n"
	   << "2) check that you specified the correct # of fields above\n"
	   << "3) check that every line in the ped file has " << totcol << " columns\n\n";
      exit(0); 
    } 
  
  int implied_lines = cnt/totcol;
  
  CHECKPED.close();
  
  cnt=0;
  int flag=0;
  
  FILE *fp;
  fp=fopen(pedfile.c_str(),"r");
  char c;
  int r;
  while((c=getc(fp))!=EOF)
        {
        flag=1;
	if (c!='\n' && c!=' ' && c!='\t') r=2;
        if (c=='\n' && r==2)
	  {
            cnt+=1;
            flag+=1;
            r=1; 
            }	

        if (c=='\n' && r!=2)
            {
            flag+=1;
            r=1; 
            }	
	//cout << cnt << "\t" << flag << "\t" << r << "\t[" << c << "]\n"; 
	}
  fclose(fp);
  if (flag==1) cnt++;
  
  cout << cnt << " lines read \n";
  
  if (cnt != implied_lines) 
    {
      cout << "\n\nERROR: the number of counted lines in the file (" 
	   << cnt << ") differs from the expected ("<<implied_lines<<")\n";
      cout << "Check your ped file for errors\n";
    }


  if(cmdline)
    {
      newpedfile = cargs[6];
      outputfile = cargs[7];
    }
  else
    {

      // Ultimately remove newped references: always write to file
      newped=true;

      newpedfile = "";  
      if (newped)
        {
          string tmp;
          cout << "\nName of new ped output file: ";
          cin >> tmp;
          if (tmp!="") { newpedfile = tmp; newped = true; } 
          else { cout << "Bad file name\n"; exit(0); }
        }

      outputfile = "";  
      cout << "Name of secondary output file: ";
      cin >> outputfile;
    }
 
  OUTPUT.open(outputfile.c_str());
  
  OUTPUT << "_______________\n";
  OUTPUT << "|FAMTYPES V1.4|\n";
  OUTPUT << "_______________\n\n";
  OUTPUT << "File: " << pedfile <<"\n";
  OUTPUT << "Affection status: " << has_Affection_col << "\n";
  OUTPUT << "Availability: " << has_Avail_col <<"\n";
  OUTPUT << "Unrelated as sib-pairs: " << treat_unrel_as_sibs << "\n";
  OUTPUT << "Number of phenotypes: " << ex_ph << "\n";
  OUTPUT << "Number of genotypes: " << ex_ge << "\n";
  OUTPUT << "Output file: " << newpedfile << "\n";
  OUTPUT << "Log file: " << outputfile << "\n\n";
//  OUTPUT << "Filter: " << << "\n";



}


void FT::loadfile()
{
  CSample nsample;
  CDatfile ndat;

  sample = nsample;
  dat = ndat;
  
  // setup and load data
  if (has_Affection_col) { dat.type.push_back("A"); dat.name.push_back("Affection"); }
  if (has_Avail_col) { dat.type.push_back("B"); dat.name.push_back("Availability"); }

  int resiz = 0;
  if (has_Affection_col) resiz++;
  if (has_Avail_col) resiz++;
  for (int i=0; i< ex_ph;i++) 
   { dat.type.push_back("C"); dat.name.push_back("extra"+int2str(i));  }
  for (int i=0; i< ex_ge;i++) 
   { 
    dat.type.push_back("M"); 
    dat.name.push_back("geno"+int2str(i));
    locmap.order["geno"+int2str(i)]= i+1;
    locmap.chr["geno"+int2str(i)]="0";
    locmap.cM["geno"+int2str(i)]=0;
    locmap.bp["geno"+int2str(i)]=0;
    //    sample.addLocus();
   }

  resiz += ex_ph + ex_ge;
  dat.data.resize(resiz);

  sample.readPedfile(pedfile,dat,locmap);  

  /////////////////////////////////////////
  // Fill in affection and availability if 
  // not specified 

  vector<short> aff;
  vector<bool> avail;

  // If need be, add bt(1) and bt(2)
  if ((!has_Affection_col) && (!has_Avail_col) ) 
    {   sample.addBTrait(); sample.addBTrait(); } 
  else if (!( has_Affection_col && has_Avail_col ) ) 
    {   sample.addBTrait(); } 
  

  // A nasty hack... made CIndividual 'public' ... 
   
  for (int f=1; f<=sample.countFamily(); f++)
    for (int i=1; i<=sample.fam(f)->nInFamily(); i++)
      { sample.fam(f)->ind(i)->bt_.resize(2); }

  
  if (has_Affection_col)
   for (int f=1; f<=sample.countFamily(); f++)
     for (int i=1; i<=sample.fam(f)->nInFamily(); i++)
	{ aff.push_back(sample.fam(f)->ind(i)->bt(1)); }	
  else	 
   for (int f=1; f<=sample.countFamily(); f++)
     for (int i=1; i<=sample.fam(f)->nInFamily(); i++)
	{ aff.push_back(1); }	

  if (has_Avail_col && has_Affection_col)
    for (int f=1; f<=sample.countFamily(); f++)
      for (int i=1; i<=sample.fam(f)->nInFamily(); i++)
	{ avail.push_back(sample.fam(f)->ind(i)->bt(2)); }	
  else if (has_Avail_col && (!has_Affection_col))
    for (int f=1; f<=sample.countFamily(); f++)
      for (int i=1; i<=sample.fam(f)->nInFamily(); i++)
	{ avail.push_back(sample.fam(f)->ind(i)->bt(1)); }	
  else	 
    for (int f=1; f<=sample.countFamily(); f++)
     for (int i=1; i<=sample.fam(f)->nInFamily(); i++)
	{avail.push_back(1); }	

   int ct=0;
   for (int f=1; f<=sample.countFamily(); f++)
     for (int i=1; i<=sample.fam(f)->nInFamily(); i++)
     {
       sample.fam(f)->ind(i)->bt(1) = aff[ct] + 1; 
       sample.fam(f)->ind(i)->bt(2) = avail[ct]; 	 
       ct++;
     }

   
   ////////////////////////////////////////////////
   // Deal with Availability

   has_Avail_col = true;


   ////////////////////////////////////////////////
   // Check for duplicate indIDs within each family

   for (int f=1; f<=sample.countFamily(); f++)
   {
     list<string> indIDlist;
     
     // Put all the indIDs in family f into the indIDlist
     for(int i=1; i<=sample.fam(f)->nInFamily(); i++)
       { indIDlist.push_back(sample.fam(f)->ind(i)->getID()); }

     // Sort the indIDs and remove duplicates
     indIDlist.sort();
     indIDlist.unique();
     
     // Report error and quit if size of family and  number of unique IDs 
     // mismatch.
     if(indIDlist.size()!=sample.fam(f)->nInFamily())
     {
       cout << "\n\nERROR: Family " << sample.fam(f)->getID() 
            << " has duplicate indIDs\n";
       exit(0);
     }
   }

  
   ////////////////////////////////////
   // Check for sex of each individual
   
   for (int f=1; f<=sample.countFamily(); f++)
     for (int i=1; i<=sample.fam(f)->nInFamily(); i++)
       if (sample.fam(f)->ind(i)->sex!=1 && 
	   sample.fam(f)->ind(i)->sex!=2) 
	 {

	   bool isMale = false;
	   bool isFemale = false;

	   for (int j=1; j<=sample.fam(f)->nInFamily(); j++)
	     {
	       if (sample.fam(f)->ind(j)->pat == sample.fam(f)->ind(i) )
		 isMale = true;

	       if (sample.fam(f)->ind(j)->mat == sample.fam(f)->ind(i) )
		 isFemale = true;

	     }

	   if (isMale && !isFemale)
	     {
	       OUTPUT << "MISSING or INCORRECT SEX CODE for family "
		      << sample.fam(f)->getID() 
		      << " individual "
		      << sample.fam(f)->ind(i)->getID() 
		      << "\n ... but is referenced as a father: changed to male (1)\n\n";
	       sample.fam(f)->ind(i)->sex=1;
	     }
	   else if ((!isMale) && isFemale)
	     {
	       OUTPUT << "MISSING or INCORRECT SEX CODE for family "
		      << sample.fam(f)->getID() 
		      << " individual "
		      << sample.fam(f)->ind(i)->getID() 
		      << "\n ... but is referenced as a mother: changed to female (2)\n\n";
	       sample.fam(f)->ind(i)->sex=2;
	     }
	   else
	     {
	       OUTPUT << "***WARNING***: MISSING or INCORRECT SEX CODE for family "
		      << sample.fam(f)->getID() 
		      << " individual "
		      << sample.fam(f)->ind(i)->getID() 
		      << "\n ... other family informative uninformative... *** changed to male (1) *** \n\n";
	       sample.fam(f)->ind(i)->sex=1;
	       
	     }

	 }
   


	 

  /////////////////////////////////////////
  // Re-read file to get actual mat and pat IDs

  
  CHECKPED.open(pedfile.c_str());
  CHECKPED.clear();
  
  while(!CHECKPED.eof())
    {
      string p, m, f_id, i_id;
      CHECKPED >> f_id >> i_id >> p >> m;
      CHECKPED.ignore(1000000,'\n'); // ignore rest of line
      if (p!="0") pat.insert(make_pair(f_id+"_"+i_id,p));
      if (m!="0") mat.insert(make_pair(f_id+"_"+i_id,m));
      
      if ( ( p=="0" && m!="0" ) ||
	   ( p!="0" && m=="0" ) )
	OUTPUT << "WARNING: [ MISSING PARENTS ] : family " 
	       << f_id << " individual " << i_id 
	       << " has only one parent specified.\n"
	       << "WARNING: A dummy parent will be inserted automatically, but...\n"
	       << "WARNING: ideally you would manually check/correct this entry\n\n"; 
    }

  CHECKPED.close();




  ////////////////////////////////////
  // Look for half sibs and flag specifically
  
  for (int f=1; f<=sample.countFamily(); f++)
    {
      // look at each pair:
      for (int i=1; i<sample.fam(f)->nInFamily(); i++)
	for (int j=i+1; j<=sample.fam(f)->nInFamily(); j++)
	  {
	    CIndividual * p1 = sample.fam(f)->ind(i);
	    CIndividual * p2 = sample.fam(f)->ind(j);
	    
	    string pat1, pat2, mat1, mat2; 
	    map<string,string>::iterator it;
	    
	    it = pat.find(p1->family->getID()+"_"+p1->getID());
	    if (it == pat.end()) pat1="0"; else pat1 = it->second;
	    
	    it = mat.find(p1->family->getID()+"_"+p1->getID());
	    if (it == mat.end()) mat1="0"; else mat1 = it->second;
	    
	    it = pat.find(p2->family->getID()+"_"+p2->getID());
	    if (it == pat.end()) pat2="0"; else pat2 = it->second;
	    
	    it = mat.find(p2->family->getID()+"_"+p2->getID());
	    if (it == mat.end()) mat2="0"; else mat2 = it->second;

	    bool matchFather = false;
	    bool matchMother = false;

	    if (pat1 == pat2 && pat1 != "0") matchFather = true;
	    if (mat1 == mat2 && mat1 != "0") matchMother = true;
	    
	    if ( ( matchFather && (!matchMother) ) || 
		 ( matchMother && (!matchFather) ) )
	      OUTPUT << "HALF-SIBS CONTAINED IN FAMILY " 
		     << p1->family->getID() << " : " 
		     << p1->getID() << " and " 
		     << p2->getID() << "\n\n";
	   }
     }



 
}
