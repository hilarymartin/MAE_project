#include "famtypes.h"
#include <map>
 
//////////////////////////////////
// Multigenerational families

bool FT::check_multigen()
{
  int choice=-1;

  if(cmdline)
    {
      choice = atoi(cargs[8].c_str());	
      NEWPED.open(newpedfile.c_str(),ios::out);
    }
  else
    {
      cerr << "Filter for which families to include in the final PED file:\n";
  
      cerr << "     1) No filter \n"
           << " Based on AVAILABLE individuals:\n ALL families in a multigenerational family\n"
           << "     2) Families: 2 parents & 1+ offspring \n"
           << "     3) Families: 2 parents & 1+ affected offspring \n"
           << " Based on AVAILABLE individuals:\n ONE family from each multigenerational family\n"
           << "     4) Families: 2 parents & most affected offspring \n\n";

      NEWPED.open(newpedfile.c_str(),ios::out);
           
      while(choice<1 || choice>4)
	{
	  choice=-1;
	  cerr << "Please enter your choice: ";
	  cin >> choice;
	}
      
    }

      bool mg_all = false;
      bool mg_all_2p = false;
      bool mg_all_2p_aff = false;
      bool mg_one_2p_aff = false;
      
      if (choice==1) mg_all = true;
      if (choice==2) mg_all_2p = true;
      if (choice==3) mg_all_2p_aff = true;
      if (choice==4) mg_one_2p_aff = true;
      
      // Count of multi-generational families
      int m=0;
      

      bool needtorerun=false;
      

      // Counts for inds/fams in MG-space

      int avail_ind_cnt = 0;
      int avail_mfam_cnt = 0;
      int avail_nfam_cnt = 0;           

      // Iterate over each family
      for (int f=1; f<=sample.countFamily(); f++)
	{
	  
	  OUTPUT << "===================================================\n\n"
	         << "Family " << sample.fam(f)->getID() << "\n\n";
	  // Can we find a nonfounder with children?
	  // (can rewrite this function: no need to consider pairs)
	  bool multi=false;
	  for (int i=1; i<=sample.fam(f)->nInFamily(); i++)
	    {
	      bool kid=false;
	      bool parent=false;
	      for (int j=1; j<=sample.fam(f)->nInFamily(); j++)
		{
		  if (i!=j) {
		    CIndividual * p1 = sample.fam(f)->ind(i);
		    CIndividual * p2 = sample.fam(f)->ind(j);		
		    if (p1->isChildOf(p2)) kid=true;
		    if (p1->isParentOf(p2)) parent=true;
		  }
		}
	      if( kid && parent) multi=true;;
	    }
	  
	  // This family is multigenerational
	  if (multi) 
	    { 
	      m++;
	    }	  
	  
	  
	  // Print/display the family
	  printPed(sample.fam(f));
	  MG mg = drawPed(sample.fam(f));
	  
	  
	  // Automatically select family
	  vector<bool> sel(mg.nuc_pat.size(),false);
	  
	  // Select all families
	  if (mg_all)
	    {
	      for (int i=0;i<sel.size();i++) sel[i]=true;
	    }
	  
	  // Select all 2 parent available families
	  // and at least 1 available offspring
	  if (mg_all_2p)
	    {
	      for (int i=0;i<sel.size();i++)
		{ 
		  if (mg.nuc_pat[i]!=NULL && 
		      mg.nuc_mat[i]!=NULL)
		    if (mg.nuc_pat[i]->bt(2) && mg.nuc_mat[i]->bt(2))
		      {
			for (int j=0;j<mg.nuc_kid[i].size();j++)
			  if (mg.nuc_kid[i][j]->bt(2))
			    sel[i]=true;
		      }
		}
	    }
	  
	  
	  // Select all 2 parent available families; aff kids only
	  if (mg_all_2p_aff)
	    {
	      for (int i=0;i<sel.size();i++)
		{ 
		  if (mg.nuc_pat[i]!=NULL && 
		      mg.nuc_mat[i]!=NULL)
		    if (mg.nuc_pat[i]->bt(2) && mg.nuc_mat[i]->bt(2))
		      {
			// check for at least one affected, available kid
			bool aff=false;
			for (int j=0;j<mg.nuc_kid[i].size();j++)
			  if (mg.nuc_kid[i][j]->bt(1)==2 && mg.nuc_kid[i][j]->bt(2)) aff=true;
			// found one?
			if (aff==true) sel[i]=true;
		      }
		}
	    }


	  	  
	  // Select one 2 parent nuclear family with 
	  // most affected kids; output only affected
	  
	  if (mg_one_2p_aff)
	    {
	      int naff = 0;
	      int s=-1;
	      for (int i=0;i<sel.size();i++)
		{
		  if (mg.nuc_pat[i]!=NULL && 
		      mg.nuc_mat[i]!=NULL)
		    // 2p ? 
		    if (mg.nuc_pat[i]->bt(2) && mg.nuc_mat[i]->bt(2))
		      {
			int n=0;
			for (int j=0;j<mg.nuc_kid[i].size();j++)
			  {
			    if (mg.nuc_kid[i][j]->bt(1)==2 && mg.nuc_kid[i][j]->bt(2))
			      n++;
			  }
			
			if (n>naff) { s=i;naff=n; }
		      }
		}
	      
	      
	      // Select the max affected one (if any)
	      if (s > -1) 
		{
		  sel[s]=true;	      
		}
	    }
	  
	  
	  // check for selection happening
	  for (int i=0;i<sel.size();i++)
	    if (!sel[i]) needtorerun=true;
	  
	  // display selection information
	  for (int i=0; i<sel.size();i++)
	    {
	      if (sel[i]) OUTPUT << "Nuclear family ("<<i+1<<") selected\n";
	      else OUTPUT << "Nuclear family ("<<i+1<<") not selected\n";
	    }


	  //////////////////////////////////////
	  // Display only seletected families
	  	  

	  // Redirect to file? 
	  streambuf* saved_buffer;
	  saved_buffer = cout.rdbuf();
	  cout.rdbuf(NEWPED.rdbuf());
	  
	  int num_selected = 0;
	  map<string,int> ind_map; 
	  
	  for (int i=0;i<sel.size();i++)
	    {
	      if (sel[i])
		{
		  num_selected++;
		  
		  // Display this family
		  
		  // If mg_all* we need to make new Family IDs
		  string fid;

		  if (mg.nuc_pat[i]!=NULL) fid = mg.nuc_pat[i]->family->getID();
		  else fid = mg.nuc_mat[i]->family->getID();
		  if (( mg_all || mg_all_2p || mg_all_2p_aff ) && sel.size()>1)
		    fid = "MG"+int2str(i+1)+"_"+fid;
		  
		  // Display father
		  if (mg.nuc_pat[i]!=NULL) 
		      printPerson(fid,mg.nuc_pat[i]->getID(),"0","0",1,mg.nuc_pat[i]);

		  // Display mother
		  if (mg.nuc_mat[i]!=NULL) 
		    printPerson(fid,mg.nuc_mat[i]->getID(),"0","0",2,mg.nuc_mat[i]);
		  
				    
		  // Display kids
		  for (int j=0;j<mg.nuc_kid[i].size();j++)
		    {
		      
		      if (mg_all || mg_all_2p || 
			  (mg_all_2p_aff && mg.nuc_kid[i][j]->bt(1)==2 && mg.nuc_kid[i][j]->bt(2) ) ||
			  (mg_one_2p_aff && mg.nuc_kid[i][j]->bt(1)==2 && mg.nuc_kid[i][j]->bt(2) ) )
			{
			  printPerson(fid,
				      mg.nuc_kid[i][j]->getID(),
				      mg.nuc_pat[i]->getID(),
				      mg.nuc_mat[i]->getID(),
				      mg.nuc_kid[i][j]->sex,
				      mg.nuc_kid[i][j]);
			}
		    }

		  // Count available individuals in this selected sam
		  map<string,int>::iterator it;
		  
		  if (mg.nuc_pat[i]!=NULL)
		    if (mg.nuc_pat[i]->bt(2)) 
		    if (ind_map.find(mg.nuc_pat[i]->getID())  == ind_map.end() ) 
		      ind_map.insert(make_pair( mg.nuc_pat[i]->getID(), 1 ) ) ;
		  
		  if (mg.nuc_mat[i]!=NULL)
		    if (mg.nuc_mat[i]->bt(2)) 
		      if (ind_map.find(mg.nuc_mat[i]->getID())  == ind_map.end() ) 
			ind_map.insert( make_pair(mg.nuc_mat[i]->getID(), 1 ) ) ;
		  
		  for (int j=0;j<mg.nuc_kid[i].size();j++)
		    if (mg.nuc_kid[i][j]->bt(2)) 
		      if (ind_map.find(mg.nuc_kid[i][j]->getID())  == ind_map.end() ) 
			ind_map.insert( make_pair(mg.nuc_kid[i][j]->getID(), 1) ) ;
		  

		} // end if selected family
	      	      	    
	      
	    } // Next nuclear family within this entire family
	  
	  // Total up counts
	  
	  avail_nfam_cnt += num_selected;
	  if (multi && num_selected>0) avail_mfam_cnt++;
	  avail_ind_cnt += ind_map.size();

	  // Restore old "cout" buffer
	  cout.rdbuf(saved_buffer);
	  
	  // End of write-to-file function
	  
    } // Next family
      
    // Close down files, etc
    NEWPED.close();
      

      cerr << "Closed files, report stats\n" <<flush;

            
    cerr << "In total, there are " << m  
	 << " multigenerational families\n";
    
    
     OUTPUT << "\n\nFamilies selected:\n"
 	   << "------------------\n\n";
    
     OUTPUT << avail_nfam_cnt << " nuclear + multigenerational sub-families \n";
     OUTPUT << avail_mfam_cnt << " multi-generational families\n"; 

     OUTPUT << "All available individuals in all selected families:\n";
     OUTPUT << avail_ind_cnt << " individuals\n\n\n";
    

      if (m>0 || needtorerun) 
	{
	  pedfile = newpedfile;
	  return false;
	  
	}
      
  return true;
}
