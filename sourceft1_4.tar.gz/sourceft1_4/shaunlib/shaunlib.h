#ifndef __SHAUNLIB_H__
#define __SHAUNLIB_H__

#include <iostream>
#include "csample.h"
#include "chaplotype.h"
#include "cdatfile.h"
#include "cmapfile.h"
#include "cmatrix.h"
#include "cmymath.h"
#include "cdata.h"
#include "copt.h"
#include "canneal.h"
#include "csimann.h"
#include "csasimplex.h"
#include "crandom.h"
#include "misc.h"
#include "error.h"
#include "cbox.h"
#include "csampleop.h"

#endif


