#ifndef __CINDIVIDUAL_H__
#define __CINDIVIDUAL_H__

#include <vector>

#include "clocus.h"
#include "csample.h"
#include "cfamily.h"
#include "chaplotype.h"
#include "cbox.h"

class CSample;
class CPhase;

class CIndividual
{
 public:
   // FUNCTIONS

      CIndividual(CSample* s); 

      void setID(string s) { id = s; }
      string getID() { return id; }

   // DATA MEMBERS

      //Individual ID
      string                       id;
      // Sex
      int                          sex;

      // Pointer to family
      CFamily*                     family;
      // Pointer to sample
      CSample*                     sample;

      // Pointer to father
      CIndividual*                 pat;
      // Pointer to mother
      CIndividual*                 mat;
      // Trait information
      bool                         observed;
      // Multi-purpose flag
      bool                         flag;

      // Handle to user-defined CDat 
      CHandle                      box;
      
      // Access functions

      CLocus & loc(const int n)
	{ return loc_[n-1]; }
      CPhase & phase(const int n)
	{ return phase_[n-1]; }
      vector<CPhase> & phase()
	{ return phase_; }
      CIndividual * child(const int n)
	{ return child_[n-1]; } 
      float & qt(const int n)
	{ return qt_[n-1]; }
      float & cov(const int n)
	{ return cov_[n-1]; }
      short & bt(const int n)
	{ return bt_[n-1]; }
      
      int nChild() { return nChild_; }
      void addChild(CIndividual *c) 
	{ 
	  nChild_++; 
	  child_.push_back(c);
	} 

      int  nPhase() { return nPhase_; }
      void addPhase(CHaplotype pat, CHaplotype mat, double prob = 0);
      void removePhase(int);

      // Individual-based function

      // Enumerate all possible Haplotype Pairs for an individual
      // given genotype information
      void enumeratePhase(); 

 public:
      // private:
      // Genotype information
      vector<CLocus>               loc_;
      // Haplotype information
      vector<CPhase>               phase_;
      int                          nPhase_;

      // Vector of pointers to children
      vector<CIndividual*>         child_;
      int                          nChild_;
      // Continuous traits
      vector<float>                qt_;
      // Covariates
      vector<float>                cov_;
      // Binary traits
      vector<short>                bt_;

 public:

      // Functions

      bool isFounder()
        { return (mat == 0 && pat == 0); }
      bool isChildOfFather(CIndividual *f)
	{ return (pat == f); }
      bool isChildOfMother(CIndividual *f)
	{ return (mat == f); }
      bool isChildOf(CIndividual *f)
	{ return isChildOfFather(f) || isChildOfMother(f); }
      bool isFatherOf(CIndividual *f)
	{ return f->pat == this; }    
      bool isMotherOf(CIndividual *f)
	{ return f->mat == this; }    
      bool isParentOf(CIndividual *f)
	{ return isFatherOf(f) || isMotherOf(f); }

      bool isAncestorOf(CIndividual *f);
      int countMeioses(CIndividual *f);

};

#endif

