// Simplex version of simulated annealing

#ifndef __CSIMANN_H__
#define __CSIMANN_H__

#include "cmatrix.h"
#include "error.h"
#include "cdata.h"
#include "cfunction.h"


class CSimAnn
{
 public:
  CSimAnn();
  CSimAnn(CFunction_ABC *);

  void setTol(double tol) 
    { ftol = tol; }

  void setParam(int n)
    { ndim = n; 
      x.setCol(n); 
      y.setCol(n+1); 
      mpts=n+1;
      p.setRow(n+1); 
      p.setCol(n); 
      psum.setCol(n); 
      ptry.setCol(n); 
      pb.setCol(n);
    }

  int getParam()
    { return ndim; }

  void setStart(CVector &);

  void randomise(int fac = 10);

  // Starting temperature 
  void setTemp(double temptr)
      { maxT = temptr; }

  // Rate of decline
  void setDecline(double decline)
      { Tdecline = decline; }

  // Number of cycles
  void setCycle(int cycle)
      { Tcycles = cycle; }

  // Max Number of iterations
  void setMaxIter(int mit)
      { Titer = mit; }


  void optimise();
  CVector getEstimates();
  double getLikelihood()
    { return yb; }

  bool verbose;

  CFunction_ABC *myFunction; 

 private:

  void minimise();   
  
  double ftol;
  
  int ndim; // cols of Matrix p
  int mpts; // rows of Matrix p
  
  int iter;
  int NMAX;
  
  CMatrix p;
  CVector x;
  CVector y;
  CVector psum;
  CVector ptry;


  double T, maxT, minT, Tdecline;
  int Titer, Tcycles;
  double temp;
  
  CVector pb;
  double yb;
  
  // Random number seed? -> NR ran1()
  int idum;
  
  // Temperature
  double tt;
  
  double amotsa(const int ihi, double  & yhi, const double fac);    


   // inline function
   void get_psum()
       {
	   double sum;
	   for (int n=1;n<=ndim;n++) 
	   {
	       sum=0.0;
	       for (int m=1; m<=mpts; m++) 
		   sum += p[m][n];
	       psum[n]=sum;
	   }
       }

};


#endif

