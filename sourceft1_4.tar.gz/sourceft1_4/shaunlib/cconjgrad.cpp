 #include <iostream>

#include "copt.h"
#include "crandom.h"

CPowell::CPowell(CFunction_ABC *f)
{
  setTol(0.000001);
  setParam(3);
  userFunction = f;
  setMaxIter(5000);
  iter = 0;
  verbose = false;
}


//defined in header...
void NR::powell(CVector &p, 
		CMatrix &xi, 
		const double ftol, 
		int &iter,
		double &fret) 
const int ITMAX=200;

void CPowell::optimise()
{
    

    const DP TINY=1.0e-25;

    int i,j,ibig;
    double del,fp,fptt,t;

    // Set number of dimensions
    int n=p.getCol();

    // Temporary vectors
    CVector pt(n),ptt(n),xit(n);

    // Function return value 
    fret=userFunction->func(p);

    // Copy p to pt
    pt = p;
 
    // Iterate 
    for (iter=0;;++iter) 
    {
	fp=fret;
	ibig=0;
	del=0.0;
	
	for (i=1;i<=n;i++) 
	{
	    for (j=1;j<=n;j++) xit[j]=xi[j][i];
	    fptt=fret;
	    linmin(p,xit,fret,func);
	    if (fptt-fret > del) 
	    {
		del=fptt-fret;
		ibig=i+1;
	    }
	}

	// Done?
	if (2.0*(fp-fret) <= ftol*(fabs(fp)+fabs(fret))+TINY) return;
	
	// Exceeded maximum # of iterations?
	if (iter == ITMAX) error("CPowell exceeding maximum iterations.");
	
	for (j=1;j<=n;j++) 
	{
	    ptt[j]=2.0*p[j]-pt[j];
	    xit[j]=p[j]-pt[j];
	    pt[j]=p[j];
	}

	fptt=userFunction->func(ptt);
	
	if (fptt < fp) 
	{
	    t=2.0*(fp-2.0*fret+fptt)*mymath::sqr(fp-fret-del)-del*mymath::sqr(fp-fptt);
	    if (t < 0.0) 
	    {
		linmin(p,xit,fret,func);
		for (j=1;j<=n;j++) 
		{
		    xi[j][ibig-1]=xi[j][n-1];
		    xi[j][n-1]=xit[j];
		}
	    }
	}
    }
}



