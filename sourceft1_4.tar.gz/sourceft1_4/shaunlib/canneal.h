#ifndef __CANNEAL_H__
#define __CANNEAL_H__

#include <cmath>

#include "cfunction.h"
#include "cmatrix.h"

class CAnneal
{

 public:
  CAnneal();
  CAnneal(CFunction_ABC *);

  // Number of temperatures to be used
  void setNumTemp(int n)
      { ntemps = n; }
  
  // Number of iterations at each temperature
  void setMaxIter(int n)
      { niters = n; }
  
  // Set back iters this much if improved
  void setSetBack(int n)
      { setback = n; }       
  
  // Limit number of function calls (due to setback)
  void setMaxSetBack(int n)
      { maxcalls = n; } 

  // Quit if function reduced to this amount
  void setTol(double d)
      { fquit = d; }      

  // Starting temperature (standard deviation)
  void setStartTemp(double d)
      { starttemp = d; }  

  // Stopping temperature
  void setStopTemp(double d)
      { stoptemp = d; }

  // Number of parameters 
  void setParam(int n)
      { 
	  ndim = n; 
	  x.setCol(n);
	  cent.setCol(n);
      }

  int getParam()
    { return ndim; }

  // Starting values
  void setStart(CVector &s)
      { x = s; }
  
  void anneal();
  
  CVector getEstimates()
      { return x; }
  
  double bestFunction()
      { return bestfval; }

  bool verbose;

  // Function to be minimized (in wrapper CFunction class)
  CFunction_ABC *userFunction;

 private:

  // Number of temperatures to be used
  int ntemps; 

  // Number of iterations at each temperature
  int niters;        

  // Set back iters this much if improved
  int setback;       

  // Limit number of function calls (due to setback)
  int maxcalls;

  // Quit if function reduced to this amount
  double fquit;      

  // Starting temperature (standard deviation)
  double starttemp;  

  // Stopping temperature
  double stoptemp;

  // Number of parameters
  int ndim;
  
  // Parameter estimates
  CVector x;
  
  // Working vector
  CVector cent;

  // Best function value
  double bestfval;

  // Perturb estimates
  void shake(double) ;    

};
    

#endif



