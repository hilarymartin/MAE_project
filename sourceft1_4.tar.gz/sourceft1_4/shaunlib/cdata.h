// Header file for CData class
// Similar to CMatrix, using CVector to store data
// but designed for datafiles
// Variable names can be stored
// Easier to extract columns , etc , to 
// send to functions for correlation, etc.

#ifndef __CDATA_H__
#define __CDATA_H__

#include <string>
#include "cmatrix.h"
#include "misc.h"

class CData
{
public:
      CData();
      CData(int ind, int var);

      ~CData();

      void setInd(int);
      int getInd() const;

      void setVar(int);
      int getVar() const;

      CVector & operator [] (const int n)
	{ return d[n-1]; }
      CVector operator [] (const int n) const
	{ return d[n-1]; }

      CColVector operator () (const int n)
	{ return extractVarIf(n); }

      // Import / export functions
      void display(); 
      void import(string filename);
      void write(string filename);

      void field_delimit(string delimiter)
	{ fd = delimiter; }
      void line_delimit(string delimiter)
	{ ld = delimiter; }

      // Filter function
      void include_all();
      void exclude_all();
      void include(int);
      void exclude(int);

      // Filter var function
      void include_all_var();
      void exclude_all_var();
      void include_var(int);
      void exclude_var(int);


      // Missing data value
      static string missing;

      // Extraction Functions
      CMatrix extractMatrix(int,int,int,int);
      CRowVector extractInd(int);
      CColVector extractVar(int);
      CColVector extractVarIf(int);
      // also overload () operator for extractVar()?      


      // Member data: ?make private and CVector friends
      vector<CVector> d;     // one individual
      BoolArray filter;      // implemented as 'char' (1-n) indexing
      BoolArray filter_var;  // implemented as 'char' (1-n) indexing
      StringArray varname; 
      bool header;
      string name;
      int row;

      string fd;
      string ld;

};

#endif
