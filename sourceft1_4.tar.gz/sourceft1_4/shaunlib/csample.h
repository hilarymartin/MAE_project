#ifndef __CSAMPLE_H__
#define __CSAMPLE_H__

#include <vector>
#include <string>

#include "cindividual.h"
#include "cfamily.h"
#include "clocus.h"
#include "cslocus.h"
#include "cdatfile.h"
#include "cmapfile.h"
#include "ctrait.h"
#include "cibd.h"
#include "cdata.h"

class CIndividual;
class CFamily;
class CLocus;
class CSLocus;
class CDatfile;
class CIbd;
class CMap;

class CSample
{

 public:
   CSample(string n = "Sample 1");  // supply sample name
   ~CSample();

   string name;

   void addIndividual();
   void setIndividual(int n);
   int countIndividual();

   void addLocus();
   void addLocus(string);
   void setLocus(int n);
   int countLocus();
   void downcode();

   void addFamily();
   void setFamily(int n);
   int countFamily();

   void addQTrait();
   void setQTrait(int);
   int countQTrait();

   void addCovariate();
   void setCovariate(int);
   int countCovariate();

   void addBTrait();
   void setBTrait(int);
   int countBTrait();

   void addIBD(CSLocus *, CIndividual *, CIndividual *,
	       double, double, double);


   static int missing_pheno;
   static int missing_geno;
   
   bool readPedfile(string,CDatfile &,CMap &);   
   bool readIbdfile(string);

   bool readSibpairfile(string f, int t = 0, int g = 0);

   // Return pointers to individuals / families
   CFamily * getFamily(string);
   CIndividual * getIndividual(string,string);
   CSLocus * getLocus(string n); 
   CIbd * getIBD(CSLocus *, CIndividual *, CIndividual *);
  

   // Access to data members (1-n indexing)

   CIndividual * ind(const int n) const
     { return ind_[n-1]; }

   CFamily * fam(const int n) const
     { return fam_[n-1]; }

   CSLocus * loc(const int n) const
     { return loc_[n-1]; }

   CIbd * ibd(const int n) const
     { return ibd_[n-1]; }

   CQTrait * qt(const int n) const
     { return qt_[n-1]; }

   CCovariate * cov(const int n) const
     { return cov_[n-1]; }
   
   CBTrait * bt(const int n) const
     { return bt_[n-1]; }

 private:

   long unsigned nIndividual;
   vector<CIndividual*> ind_;

   long unsigned nFamily;
   vector<CFamily*> fam_;

   long unsigned nLocus;
   vector<CSLocus*> loc_;

   long unsigned nIbd;
   vector<CIbd*> ibd_;

   short nQTrait;
   vector<CQTrait*> qt_;

   short nCovariate;
   vector<CCovariate*> cov_;

   short nBTrait;
   vector<CBTrait*> bt_;
   
};

#endif

