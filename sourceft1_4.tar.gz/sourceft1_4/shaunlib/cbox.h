#ifndef __CBOX_H__
#define __CBOX_H__

class CBox;

class CHandle
{
    CBox * rep;
 public:
    CBox * operator->() { return rep; }
    void set(CBox * pp) { rep = pp; } 
};

#endif
