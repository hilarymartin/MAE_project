// Miscellaneous functions

#include "misc.h"
#include "error.h"
#include "crandom.h"
#include <fstream>
#include <string>
#include <iomanip>

CArgs::CArgs(int _n , char *argv[] )
{
  n = _n;
  a.push_back(argv[0]);
  for (int i=1 ; i < n ; i++ )
    a.push_back(argv[i]);
}

bool CArgs::find(string s)
{
    for (int i=0 ; i < n ; i++ )
      if (a[i] == s) return true;
    return false;
}  

string CArgs::value(string s)
{
    for (int i=0 ; i < n ; i++ )
      if (a[i] == s && (i+1 < n) ) return a[i+1];
    return "";
} 

//===============================================================
// Int2Str - converts signed int to std::string
// replaces itoa
//
std::string int2str(int n)
{
  int next;
  std::string str_num;
  
  register int r, k;
  int flag = 0;
  
  next = 0;
  if (n < 0)
    {
      next++;
      str_num += '-';
      n = -n;
    }
  
  if (n == 0)
    {
      str_num += '0';
    }
  else
    {
      k = 10000;
      while (k > 0)
	{
	  r = n / k;
	  if (flag || r > 0) 
	    {
	      char tmp = '0' + r;
	      str_num += tmp;
	      flag = 1;
	    }
	  n -= r * k;
	  k = k / 10;
	}
    }
  
  return(str_num);
}


unsigned long graycode(const unsigned long n, const int is)
{
    int ish;
    unsigned long ans,idiv;
    
    if (is >= 0)
	return n ^ (n >> 1);
    ish=1;
    ans=n;
    for (;;) {
	ans ^= (idiv=ans >> ish);
	if (idiv <= 1 || ish == 16) return ans;
	ish <<= 1;
    }
    
}

string uniqname(string f)
{
    ifstream s;
    int r;
    string u;

 repeat:

    r = CRandom::rand(9999);
    u = f+int2str(r);
    s.open(u.c_str());
    if (!s) 
    {
	s.close();
	return u;
    }

    s.close();
    goto repeat;
}


void checkFileExists(string f)
{

  ifstream inp;
  
  inp.open(f.c_str(), ifstream::in);
  inp.close();
  if(inp.fail())
    {
      inp.clear(ios::failbit);
      string msg = "No file [ " + f + " ] exists.";
      error(msg);
    }
  
  return;

}

