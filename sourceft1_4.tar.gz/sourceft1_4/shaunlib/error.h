#ifndef __CERROR_H__
#define __CERROR_H__

#include <string>

using namespace std;

void error(string);

#endif
