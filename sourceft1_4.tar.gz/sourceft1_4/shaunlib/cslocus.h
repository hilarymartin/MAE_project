#ifndef __CSLOCUS_H__
#define __CSLOCUS_H__

#include <vector>
#include <string>

using namespace std;

class CSLocus
{

 public:
      CSLocus(int);
      ~CSLocus();

      string allele(int n) { return allele_[n-1]; }
      
      void addAllele(string,double);
      void setAllele(int);
      int countAlleles();
      
      string               name;           // locus name
      int                  countAllele;    // number of alleles
      vector<string>       allele_;        // vector of allele codes
      vector<double>       freqAllele;     // vector of allele freqs

      bool                 usat;           // flag is T if this is a downcoded 
                                           // SNP from a usat
};

#endif
