#include <iostream>

#include "cfamily.h"
#include "cibd.h"
#include <math.h>
#include "misc.h"

CFamily::CFamily(CSample* s)
{
   // Assign default Family ID
   // and increment
   id = int2str(s->countFamily()+1);
   nInFamily(0);
   ind_.resize(0);
   proband = NULL;
}


CFamily::~CFamily()
{
 // 
}


void CFamily::assignToFamily(CIndividual* i, string fcode)
{
 // Assign individual ID to family class
 //   if ((nInFamily()) == ind_.capacity()) ind_.resize(nInFamily()+1);
 //   ind_.push_back(NULL);
 //   ind_[nInFamily()] = i;
 //  nInFamily( nInFamily() + 1 ); 

   ind_.push_back(i);
   int temp = nInFamily();
   nInFamily(++temp);
   // Assign this family ID to individual
   i->family = this;
}



CMatrix CFamily::genrel(bool all) const
{
  CMatrix g(nInFamily(),nInFamily());

  // Note that CMatrix uses 1 - n indexing
  // whilst CSample-related vectors use 0 - (n-1)
  
  // For each individual
  for (int i = 1 ; i <= nInFamily() ; i++)
    {
      // Diagonal
      g[i][i] = 1; 
      
      // For other of pair (symmetry)
      for (int j = i+1 ; j <= nInFamily() ; j++)
	{
	  
	  // Are both founders?
	if (ind(i)->isFounder() && ind(j)->isFounder()) g[i][j] = 0;
	else
	  {
	    g[i][j] = 0; // initialise

	    // Assuming no inbreeding
	    // Find nearest common ancestor
	    IntArray m_i;
	    IntArray m_j;
	    BoolArray nca;

	    m_i().resize(nInFamily());
	    m_j().resize(nInFamily());
	    nca().resize(nInFamily());

	    // 1. Iterate through each other pedigree member
	    for (int k = 1 ; k <= nInFamily() ; k++)
	      {

		nca(k) = true;

		// For individual i (1)
		if (ind(k)->isAncestorOf(ind(i)))
		  m_i(k) = ind(k)->countMeioses(ind(i));

		// For individual j (2)
		if (ind(k)->isAncestorOf(ind(j)))
		  m_j(k) = ind(k)->countMeioses(ind(j));
		
		// If k is not an ancestor of either i or j 
		// do not consider further
		if (!(ind(k)->isAncestorOf(ind(i)) &&
		      ind(k)->isAncestorOf(ind(j))) )
		  nca(k) = false;
	      } 

	    // 2. Find nearest of remaining
	    int k_min = 99999;
	    for (int k = 1 ; k <= nInFamily() ; k++)
	      if ( ((m_i(k) + m_j(k)) < k_min) && nca(k)  ) 
		k_min = (m_i(k) + m_j(k));
	    
	    for (int k = 1 ; k <= nInFamily() ; k++)
	      if ( (m_i(k) + m_j(k)) >  k_min )
		nca(k) = false;
		
	    // 3. Calculate genrel()

	    for (int k = 1 ; k <= nInFamily() ; k++)
	      {
		if (nca(k))
		  g[i][j] += pow(0.5,ind(k)->countMeioses(ind(i))
				 +ind(k)->countMeioses(ind(j)) );
	      }
	  }
	g[j][i] = g[i][j];
	}
    }
  if (!all) return observed(g); else return g;
}

CMatrix CFamily::p0(CSLocus *l,bool all) const
{
  CSample *sample = ind(1)->sample;
  CMatrix m = genrel(); 
  for (int i = 1 ; i <= nInFamily() ; i++)
    {
      m[i][i] = 0;
      for (int j = i+1 ; j <= nInFamily() ; j++)
	if (CIbd *ibd = sample->getIBD(l,ind(i),ind(j)))
	  m[i][j] = m[j][i] = ibd->p0;
    }
  return m;
}

CMatrix CFamily::p1(CSLocus *l,bool all) const
{
  CSample *sample = ind(1)->sample;
  CMatrix m = genrel(); 
  for (int i = 1 ; i <= nInFamily() ; i++)
    {
      m[i][i] = 0;
      for (int j = i+1 ; j <= nInFamily() ; j++)
	if (CIbd *ibd = sample->getIBD(l,ind(i),ind(j)))
	  m[i][j] = m[j][i] = ibd->p1;
    }
  if (!all) return observed(m); else return m;
}

CMatrix CFamily::p2(CSLocus *l,bool all) const
{
  CSample *sample = ind(1)->sample;
  CMatrix m = genrel(); 
  for (int i = 1 ; i <= nInFamily() ; i++)
    {
      m[i][i] = 1;
      for (int j = i+1 ; j <= nInFamily() ; j++)
	if (CIbd *ibd = sample->getIBD(l,ind(i),ind(j)))
	  m[i][j] = m[j][i] = ibd->p2;
    }
  if (!all) return observed(m); else return m;
}

CMatrix CFamily::pihat(CSLocus *l,bool all) const
{
  CSample *sample = ind(1)->sample;
  CMatrix m = genrel(); 
  for (int i = 1 ; i <= nInFamily() ; i++)
    {
      m[i][i] = 1;
      for (int j = i+1 ; j <= nInFamily() ; j++)
	if (CIbd *ibd = sample->getIBD(l,ind(i),ind(j)))
	  m[i][j] = m[j][i] = (ibd->p1)/2+ibd->p2;
    }
  if (!all) return observed(m); else return m;
}


CMatrix CFamily::observed(const CMatrix &f) const
{
  int obs = 0 ;
  for (int i = 1 ; i <= nInFamily() ; i++)
    if (ind(i)->observed) obs++;
  CMatrix r(obs,obs);
  int oi = 0;
  int oj = 0;
  for (int i = 1 ; i <= nInFamily() ; i++)
    {
      oj = 0;
      if (!ind(i)->observed) continue;
      oi++;
      for (int j = 1 ; j <= nInFamily() ; j++)
	{
	  if (!ind(j)->observed) continue; 
	  oj++;
	  r[oi][oj] = f[i][j];
	}
    }
  return r;
}

CIndividual & CFamily::getChildFromTrio()
{
    for (int c=1; c<=nInFamily(); c++)
	if (!ind(c)->isFounder())
	    return *ind(c);	      
}
