#include "csampleop.h"

//===============================================================
// Recode SNPs from ACGT/1234 coding to 1/2 coding
//

 
StringArray recodeSNPs(CSample & sample)
{
 
    int nloc = sample.countLocus();
    StringArray ACGT; 
    ACGT().resize(nloc);
     
    /////////////////////////
    // Get high / low pairing
     
    for (int i = 1 ; i <= nloc ; i++ )
    {
 
        ACGT(i) = "Z1";
 
        for (int j = 1 ; j <= sample.countFamily(); j++)
        {
            for (int k = 1; k <= sample.fam(j)->nInFamily(); k++)
            {
 
                if (sample.fam(j)->ind(k)->loc(i).one != "0")
                {
                    if (sample.fam(j)->ind(k)->loc(i).one < ACGT(i).substr(0,1) )
                        ACGT(i).replace(0,1,sample.fam(j)->ind(k)->loc(i).one);
                    if (sample.fam(j)->ind(k)->loc(i).one > ACGT(i).substr(1,1) )
                        ACGT(i).replace(1,1,sample.fam(j)->ind(k)->loc(i).one);
                }
                 
                if (sample.fam(j)->ind(k)->loc(i).two != "0")
                {
                    if (sample.fam(j)->ind(k)->loc(i).two < ACGT(i).substr(0,1) )
                        ACGT(i).replace(0,1,sample.fam(j)->ind(k)->loc(i).two);
                    if (sample.fam(j)->ind(k)->loc(i).two > ACGT(i).substr(1,1) )
                        ACGT(i).replace(1,1,sample.fam(j)->ind(k)->loc(i).two);
                }
 
            }
        }
         
    }

    ////////////////////
    // Recode
     
    for (int i = 1 ; i <= nloc ; i++ )
    {
        for (int j = 1 ; j <= sample.countFamily() ; j++)
        {
            for (int k = 1 ; k <= sample.fam(j)->nInFamily(); k++)
            {
                if (sample.fam(j)->ind(k)->loc(i).one == ACGT(i).substr(0,1) )
                    sample.fam(j)->ind(k)->loc(i).one = "1";
                if (sample.fam(j)->ind(k)->loc(i).one == ACGT(i).substr(1,1) )
                    sample.fam(j)->ind(k)->loc(i).one = "2";

                if (sample.fam(j)->ind(k)->loc(i).two == ACGT(i).substr(0,1) )
                    sample.fam(j)->ind(k)->loc(i).two = "1";
                if (sample.fam(j)->ind(k)->loc(i).two == ACGT(i).substr(1,1) )
                    sample.fam(j)->ind(k)->loc(i).two = "2";
            }
        }
    }
    
    return ACGT;
}

