#include "cfunction.h"

#include <cmath>

#define   MAXROUNDS      4
#define   SQRT_HALF      (1.0/M_SQRT2)
#define   TWO            (M_SQRT2 * M_SQRT2)

void CFunction_ABC::deriv(CVector& x, CVector& d, double initial_h)
{
    double a[MAXROUNDS][MAXROUNDS];
    
    // Calculate derivatives along each direction ...
    for (int k = 1; k <= x.getCol(); k++)
    {
	double left, right;
	double save_x = x[k];
	double h = initial_h;
	
	// Initial crude estimate
	x[k] = save_x - h;
	left  = func(x);
	x[k] = save_x + h;
	right = func(x);
	a[0][0] = (right - left) / (2.0 * h);
	
	// Initial guess of error is large
	double err = 1e30;
	
	// At each round, update Neville tableau with smaller 
	// stepsize and higher order extrapolation ...
	for (int i = 1; i < MAXROUNDS; i++)
	{
	    // Decrease h
	    h *= SQRT_HALF;
	    
	    // Re-evaluate function
	    x[k] = save_x - h;
	    left  = func(x);
	    x[k] = save_x + h;
	    right = func(x);
	    a[0][i] = (right - left) / (2.0 * h);
	    
	    // Calculate extrapolations of various orders ...
	    double factor = TWO;
	    
	    for (int j = 1; j <= i; j++)
            {
		a[j][i] = (a[j-1][i] * factor - a[j-1][i-1])/(factor - 1.0);
		
		factor *= TWO;
		
		double error = max(fabs(a[j][i] - a[j-1][i]), fabs(a[j][i] - a[j-1][i-1]));
		
		// Did we improve solution?
		if (error < err)
		{
		    err = error;
		    d[k] = a[j][i];
		}
            }
	    
	    // Stop if solution is deteriorating ...
	    if (fabs(a[i][i] - a[i-1][i-1]) >= 2.0 * err)
            {
		x[k] = save_x;
		break;
            }
	}

	x[k] = save_x;
    }
}



CMatrix CFunction_ABC::hessian(CVector param, double eps) 
{
    // p usually the MLE 
    int ndim = param.getCol();
    CVector d(ndim);
    CMatrix h(ndim,ndim);
    for (int i=1; i<=ndim; i++)
	d[i] = param[i]*eps > eps ? param[i]*eps : eps;
    

    for (int i=1; i <= ndim ; i++)
	for (int j=1 ; j <= i ; j++)
	{
	    
	    CVector p_ij = param;
	    CVector p_i = param;
	    CVector p_j = param;
	    
	    p_ij = param;
	    

	    p_ij[i] += d[i];
	    p_ij[j] += d[j];

	    p_i[i] += d[i];
	    p_j[j] += d[j];
	    
	    h[i][j] = ( func(p_ij)/-2
			- func(p_i)/-2
			- func(p_j)/-2
			+ func(param)/-2 ) 
		/ ( d[i] * d[j] );
	    
	}
    
    // force symmetry
    for (int i=1; i <= ndim ; i++)
	for (int j=1 ; j < i ; j++)
	    h[j][i] = h[i][j]; 

    return h;
}
