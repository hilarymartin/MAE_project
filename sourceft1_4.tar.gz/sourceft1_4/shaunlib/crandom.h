#ifndef __CRANDOM_H__
#define __CRANDOM_H__

#include <vector>
#include "cmatrix.h"

class CRandom 
{
 public:

    static const int IA;
    static const int IM;
    static const int IQ;
    static const int IR;
    static const int NTAB;
    static const int NDIV;

    static const double EPS;
    static const double AM;
    static const double RNMX;

    // Current seed
    static int idum;
    
    static int iy;
    static IntArray iv; 

    static void srand(long unsigned iseed = 0);
    static double rand();
    static int rand (int);

};


#endif
