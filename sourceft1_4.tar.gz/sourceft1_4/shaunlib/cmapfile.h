#ifndef __CMAPFILE_H__
#define __CMAPFILE_H__

#include "cindividual.h"
#include "cdatfile.h"
#include "cmatrix.h"
#include <map>

class CIndividual;
class CSample;
class CDatfile;

class CMap
{
 public:
   // FUNCTIONS

      CMap(); 
      ~CMap(); 

      bool readMapfile(string, CDatfile &);

      string                 token1;
      string                 token2;
      string                 token3;

      map<string, int>       order;
      map<string, string>    chr;
      map<string, double>    cM;
      map<string, long int>  bp;

      // Show recombination fraction between two loci
      double theta(int a, int b) { return rf[a][b]; } 

      // Get entire matrix of recombination fractions (including skipped markers)
      CMatrix & theta() { return rf; }
      
      // Get BP position for a SNP, if this information has been loaded
//      long int pos(int a) { if ( bp.size() > a-1 ) return bp[a-1]; else return -1; }


 private:
      
      // Matrix of recombination fractions
      CMatrix rf;
      
      // Number of loci
      int n;

};

#endif

