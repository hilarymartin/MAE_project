// Implementation of Sample class

#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include "csample.h"
#include "cfamily.h"
#include "cibd.h"
#include "error.h"

int CSample::missing_pheno = -9;
int CSample::missing_geno = 0;

CSample::CSample(string n) : name(n)
{

  nIndividual = 0;
  nFamily = 0;
  nLocus = 0;
  nIbd = 0;
  nQTrait = 0;
  nCovariate = 0;
  nBTrait = 0;

  ind_.resize(0);
  fam_.resize(0);
  loc_.resize(0);
  ibd_.resize(0);
  qt_.resize(0);
  cov_.resize(0);
  bt_.resize(0);
  
}

CSample::~CSample()
{
  for (int i = 0 ; i < nFamily ; i++ )
    delete fam_[i];

  for (int i = 0 ; i < nIndividual ; i++ )
    delete ind_[i];
  
  for (int i = 0 ; i < nQTrait; i++)
    delete qt_[i];

  for (int i = 0 ; i < nCovariate; i++)
    delete cov_[i];

  for (int i = 0 ; i < nBTrait; i++)
    delete bt_[i];

  for (int i = 0 ; i < nIbd; i++)
    delete ibd_[i];

  for (int i = 0 ; i < nLocus; i++)
    delete loc_[i];
}


bool CSample::readPedfile(string f, CDatfile & dat, CMap & locmap)
{


    // M        Marker (general coding)
    // N        SNP (nucleotide)
    // T        Quantitative trait
    // B,D,A    Binary trait
    // C        Covariate
    // S        Skip locus
    // X        Skip trait
    
    
    // Analyse the Datfile to find out how
    // many markers and traits are needed
    // Get file name;
    // Use to process PedFile;

    //
    // Add as many loci as needed
    //

    for (int i = 0 ; i < dat.type.size() ; i++)
	    if ( dat.type[i] == "M" || dat.type[i] == "N" )      
	    addLocus();
    
    // 
    // Read in additional data
    
    for (int i = 0 ; i < dat.type.size() ; i++)
    {
	
	//  M     rs1982732   0.231 0.0234 0.3424 
	//  N     rs1982732   A/G  0.3423
   	
	// Add a new locus : general
	if ( dat.type[i] == "M" )
        {

	    // look up order in locmap
	    map<string,int>::iterator it = locmap.order.find(dat.name[i]);
	    if (it==locmap.order.end())
		error("Cannot locate marker in DAT file.");
	    int l = it->second;

	    // append name
	    loc(l)->name = dat.name[i];
	    
	    // add alleles
	    for (int j=0; j< dat.data[i].size(); j++)
		loc(l)->addAllele(int2str(j+1),
				  atof(dat.data[i][j].c_str()));
	    
	    // if SNP and only single freq entered, add other allele
	    if (dat.data[i].size() == 1 )
		loc(l)->addAllele("2",
				  1-atof(dat.data[i][0].c_str()));
        }
	
	
     // Add a new locus : SNP with coding 
	if ( dat.type[i] == "N" )
	{

	    // look up order in locmap
	    map<string,int>::iterator it = locmap.order.find(dat.name[i]);
	    if (it==locmap.order.end())
		error("Cannot locate marker in DAT file.");
	    int l = it->second;

	    // add SNP name
	    loc(l)->name = dat.name[i];
	    
	    string alleles = dat.data[i][0];
	    
	    // valid code?
	    if (alleles.length() != 3 || alleles.substr(1,1) != "/") 
		error("Problem with SNP coding... must be in A/G form");
	    
	    // set allele codes (use direct access of allele_ for 
	    // convenience.... 
	    loc(l)->allele_[0] = alleles.substr(0,1);
	    loc(l)->allele_[1] = alleles.substr(2,1);
	    
	    // set alleles freqs, if given
	    if (dat.data[i].size() == 2 )
	    {
		loc(l)->addAllele("1",
				  atof(dat.data[i][1].c_str()));
		loc(l)->addAllele("2",
				  1-atof(dat.data[i][1].c_str()));
	    }
	}
	
	
	// Add a new Q Trait
	if ( dat.type[i] == "T" )
	{
	    addQTrait();
	    qt(countQTrait())->name = dat.name[i];
	    
	    // add mean?
	    if (dat.data[i].size() >= 1 )
	    {
		qt(countQTrait())->mean = atof(dat.data[i][0].c_str());
		qt(countQTrait())->mean_set;
	    }
	    
	    // add mean?
	    if (dat.data[i].size() >= 2 )
	    {
		qt(countQTrait())->var = atof(dat.data[i][1].c_str());
		qt(countQTrait())->var_set;
	    }
	    
	    // add sibling correlation?
	    if (dat.data[i].size() >= 3 )
	    {
		qt(countQTrait())->sibr = atof(dat.data[i][2].c_str());
		qt(countQTrait())->sibr_set;
	    }
        }
	
	// Add a new C covariate 
	if ( dat.type[i] == "C" )
        {
	    addCovariate();
	    cov(countCovariate())->name = dat.name[i];
	    
	    // add mean?
	    if (dat.data[i].size() >= 1 )
	    {
		cov(countCovariate())->mean = atof(dat.data[i][0].c_str());
		cov(countCovariate())->mean_set = true;	  
	    }
	    
	    // add var?
	    if (dat.data[i].size() >= 2 )
	    {
		cov(countCovariate())->var = atof(dat.data[i][1].c_str());
		cov(countCovariate())->var_set = true;
	    }
	    
	    // add sibling correlation?
	    if (dat.data[i].size() >= 3 )
	    {
	      cov(countCovariate())->sibr = atof(dat.data[i][2].c_str());
	      cov(countCovariate())->sibr_set = true;
	    }	  
        }
	
	// Add a new B Trait
	if ( dat.type[i] == "B" || dat.type[i] == "A" || dat.type[i] == "D" )
	{
	    addBTrait();
	    bt(countBTrait())->name = dat.name[i];
	   
	    // add mean?
	    if (dat.data[i].size() >= 1 )
		bt(countCovariate())->prevalence = atof(dat.data[i][0].c_str());
	    
        }
	
	// Assign a name to the sample
//     if ( dat.type[i] == "N" ) name = dat.name[i];
    }
    
    // Read in Pedfile
    
    ifstream in;
    in.open(f.c_str());
    in.clear();
    
    while (!in.eof())
    {
	string p, m;
	int s ;
	string newFamilyID = "-1";
	string newIndividualID;
	
	// Read in first lines of individual's data
	in >> newFamilyID >> newIndividualID >> p >> m >> s;
	
	// Skip blank lines at EOF
	if (newFamilyID == "-1") break;
	
	// Does this family already exist?
	int match = -1;
	for (int i = 1 ; i <= countFamily() ; i++)
	    if ( newFamilyID == fam(i)->getID() )
	    {
		match = i;
		break;
	    }
	
	// Create new family
	if (match == -1)
	{
	    addFamily();
	    match = countFamily();
	    fam(match)->setID(newFamilyID);
	}
	
	// Create new individual
	addIndividual();
	
	// Use the fact that this is the last individual to
	// be created
	int n = countIndividual();
	
	// Note that this individual has been observed
	ind(n)->observed = true;
	
	// Assign to family increases nInFamily automatically
	ind(n)->setID(newIndividualID);  
	fam(match)->assignToFamily(ind(n),newIndividualID);
	
	// Sex
	if (s == 1) ind(n)->sex = 1;       // Male
	else if (s == 2) ind(n)->sex = 2;  // Female
	else ind(n)->sex = 0;              // Unknown
	
	
	// Read genotype and phenotype data
	// The order in which the data are read in 
	// is specified in the .dat file
	
	int loc_counter = 0;
	int qt_counter = 0;
	int cov_counter = 0;
	int bt_counter = 0;
	
	for (int i = 0 ; i < dat.type.size() ; i++)
	{
	    
	    // Read locus 
	    if ( dat.type[i] == "M" || dat.type[i] == "N" )
	    {

		// move to next locus
		loc_counter++;
		
		// read in 
		string g1, g2;
		in >> g1 >> g2;

		// handle incomplete missingness 
		if (g1 == "0" && g2 != "0" 
		    || g1 != "0" && g2 == "0")
		{
		    string errmsg = "Error in individual " + int2str(n) + 
			": must have both or no missing alleles in a genotype";
		    error(errmsg);
		    
		}
		
		// look up order in locmap
		map<string,int>::iterator it = locmap.order.find(dat.name[i]);
		if (it==locmap.order.end())
		    error("Cannot locate marker in DAT file.");
		int l = it->second;
		
		// store
		ind(n)->loc(l).one = g1;
		ind(n)->loc(l).two = g2;
		
	    }
	
        // Read QT
	if ( dat.type[i] == "T" )
{
	    in >> ind(n)->qt(++qt_counter);
//	    cout << "ind("<<n<<") ->qt("<<qt_counter<<") = " << ind(n)->qt(qt_counter) << "\n";
}

	// Read Covariate
	if ( dat.type[i] == "C" ) 
	    in >> ind(n)->cov(++cov_counter);
	
	// Read BT
	if ( dat.type[i] == "B" || dat.type[i] == "A" || dat.type[i] == "D")
	{
	    string t2;
	    short t;

	    in >> t2;
	    
	    // 0/1 coding
	    if (dat.type[i] == "B" || dat.type[i] == "D") 
	    {
		if (t2 == "0") t = 0;
		if (t2 == "1") t = 1;   
	    }

	    // 0=missing/1=no/2=yes coding (Affection Status)
	    if (dat.type[i] == "A")
	    {
		if (t2 == "0") t = -1;   
		if (t2 == "1") t = 0;   
		if (t2 == "2") t = 1;   
	    }		

	    if (t2 == "A") t = 1;
	    if (t2 == "U") t = 0;
	    if (t2 == "C") t = 1;
	    if (t2 == "L") t = 0;

	    ind(n)->bt(++bt_counter) = t;
	}
	
	// Skip locus
	if ( dat.type[i] == "S" )
	{
	    string forget_me;
	    in >> forget_me >> forget_me;
	}

	// Skip trait
	if ( dat.type[i] == "X" )
	{
	    string forget_me;
	    in >> forget_me;
	}

    }

   }

   in.clear();
   in.close();


   // Read in data once more, to assign parents to individuals
   // now that all the data are in
   in.open(f.c_str());
   while (!in.eof())
   {
       
       string p, m, f_id, i_id; 
       in >> f_id >> i_id >> p >> m;
       in.ignore(1000000,'\n'); // ignore rest of line

       if (f_id != "") // skip blank lines
       {
	   if (i_id == p || i_id == m || ( p == m && p != "0" )  )
	   {
	       string errmsg = "Pedigree error : family " 
		   + f_id + " individual " + i_id;
	       error(errmsg);
	   }
	   
	   CIndividual * individual = getIndividual(f_id,i_id);
	   CIndividual * mother = getIndividual(f_id,m);
	   CIndividual * father = getIndividual(f_id,p);

	   individual->mat = mother;
	   individual->pat = father;
       }
     }
   in.close();

   // Populate child[] information
   for (int i = 1 ; i <= countFamily() ; i++)
     for (int j = 1 ; j <= fam(i)->nInFamily() ; j++)
       for (int k = 1 ; k <= fam(i)->nInFamily() ; k++)	
	 if (fam(i)->ind(j)->isParentOf(fam(i)->ind(k)))
	   fam(i)->ind(j)->addChild(fam(i)->ind(k));

   // Modify this flag if failure.
   return true;

}

void CSample::addIndividual()
{

// need more space ?
//     if (nIndividual == ind_.capacity()) ind_.resize(nIndividual+1);
// add new pointer

//     ind_.push_back(NULL);

// assign new individual to pointer
     // have to use old notation
     // as we cannot use a returned pointer 
     // as an lvalue, apparently...

//     ind_[nIndividual++] = new CIndividual(this);

    ind_.push_back(new CIndividual(this));
    nIndividual++;

}

int CSample::countIndividual() { return nIndividual; }

void CSample::setIndividual(int n)
   { for (int i=1; i<=n; i++) addIndividual(); }

void CSample::addLocus()
{
//     if (nLocus == loc_.capacity()) loc_.resize(nLocus+1);
//     loc_.push_back(NULL);
//     loc_[nLocus] = new CSLocus(nLocus) ;
//     nLocus++;

     loc_.push_back(new CSLocus(nLocus));
     nLocus++;

}

void CSample::setLocus(int n)
   { for (int i=1; i<=n; i++) addLocus(); }

int CSample::countLocus() { return nLocus; }

void CSample::addFamily()
{
   if (nFamily == fam_.capacity()) fam_.resize(nFamily+1);
   fam_.push_back(NULL);
   fam_[nFamily++] = new CFamily(this);
}


void CSample::setFamily(int n)
   { for (int i=1; i<=n; i++) addFamily(); }

int CSample::countFamily() { return nFamily; }





void CSample::addQTrait()
{
   if (nQTrait == qt_.capacity()) qt_.resize(nQTrait+1);
   qt_.push_back(NULL);
   qt_[nQTrait++] = new CQTrait;
}

void CSample::setQTrait(int n)
   { for (int i=1 ; i<=n ; i++ ) addQTrait(); }

int CSample::countQTrait()
   { return nQTrait; }



void CSample::addCovariate()
{
   if (nCovariate == cov_.capacity()) cov_.resize(nCovariate+1);
   cov_.push_back(NULL);
   cov_[nCovariate++] = new CCovariate;
}

void CSample::setCovariate(int n)
   { for (int i=1 ; i<=n ; i++ ) addCovariate(); }

int CSample::countCovariate()
   { return nCovariate; }





void CSample::addBTrait()
{
   if (nBTrait == bt_.capacity()) bt_.resize(nBTrait+1);
   bt_.push_back(NULL);
   bt_[nBTrait++] = new CBTrait;
}

void CSample::setBTrait(int n)
   { for (int i=1; i<=n; i++) addBTrait(); }

int CSample::countBTrait()
   { return nBTrait; }

CFamily * CSample::getFamily(string f_id)
{
  for (int i = 1 ; i <= countFamily() ; i++)
    if (fam(i)->getID() == f_id) return fam(i);
  return 0;
}

CIndividual * CSample::getIndividual(string f_id, string i_id)
{
  CFamily * family = getFamily(f_id);
  if (family == 0) return 0;
  for (int i = 1 ; i <= family->nInFamily(); i++)
    if ( family->ind(i)->getID() == i_id ) return family->ind(i);
  return 0;
}

CSLocus * CSample::getLocus(string n)
{
  CSLocus * l = NULL;
  for (int i = 1 ; i <= nLocus; i++)
    if ( loc(i)->name == n ) l = loc(i);
  return l;
}

void CSample::addIBD(CSLocus *l, CIndividual *i1, CIndividual *i2, 
		     double p0_, double p1_, double p2_)
{
  if (nIbd == ibd_.capacity()) ibd_.resize(nIbd+1);
  ibd_.push_back(NULL);
  ibd_[nIbd++] = new CIbd(l,i1,i2);
  ibd(nIbd)->p0 = p0_; 
  ibd(nIbd)->p1 = p1_;
  ibd(nIbd)->p2 = p2_;
}

bool CSample::readIbdfile(string f)
{

  // Requires Loci named with unique strings  

   ifstream in;

   string fid, id1, id2;
   string locus;
   double p0, p1, p2;

   in.open(f.c_str());

   int cnt = 0;

   while (!in.eof())
     
     {
       in >> fid >> id1 >> id2
	  >> locus
	  >> p0 >> p1 >> p2;

       CSLocus * plocus = getLocus(locus);
       CFamily * pfamily = getFamily(fid);
       CIndividual * pi1 = getIndividual(fid,id1);
       CIndividual * pi2 = getIndividual(fid,id2);

       if (plocus == 0 || pfamily == 0 || pi1 == 0 || pi2 == 0)
	 error("Datapoint in IBD file has no match in PED file");

       // Store IBD in (i->id) < (j->id) for pair (i,j)
       
       if (pi1->id < pi2->id) 
	   addIBD(getLocus(locus),
		  getIndividual(fid,id1),
		  getIndividual(fid,id2),
		  p0,p1,p2);
	   else
	   addIBD(getLocus(locus),
		  getIndividual(fid,id2),
		  getIndividual(fid,id1),
		  p0,p1,p2);

       CIbd *i = getIBD(getLocus(locus),
			getIndividual(fid,id1),
			getIndividual(fid,id2));
       
     }
   in.close();
}

CIbd * CSample::getIBD(CSLocus *l, CIndividual *i1, CIndividual *i2)
{
  CIbd * p = 0;
  for (int i = 1 ; i <= nIbd ; i++) 
    if (l==ibd(i)->loc && i1 == ibd(i)->ind1 && i2 == ibd(i)->ind2) 
      return ibd(i);
  return p;
}


bool CSample::readSibpairfile(string f,int t, int l)
{
  
  // Read data file;

  // Structure 
  // ID : F_ID 
  // TRAIT : S1T1 S1T2 S2T1 S2T2 
  // GENO  : S1L1A1 S1L1A2 S1L2A1 S1L2A2  S2L1A1 S2L1A2 S2L2A1 S2L2A2 
  // IBD   : T1IBD0 T1IBD1 T1IBD2 T2IBD0 T2IBD1 T2IBD2

  CData d;
  d.field_delimit(" ,\t");
  d.line_delimit("\n");
  d.header = false;
  d.import(f);

  int col = 1; // FID 
  col += 2*t;  // traits
  col += 2*2*l; // Two alleles per sib per locus
  col += 3*l;  // Three IBD probabilities per pair per locus

  if (d.getVar() != col) error("Sib Pair Data file does not match specification");

  setLocus(l);
  setQTrait(t);
  
  // Locus and trait must be set before these...
  setIndividual(d.getInd()*4);
  setFamily(d.getInd());

  int i = 0 ; // Individual counter
  for (int j = 1 ; j <= nFamily ; j++ )
    {

      CFamily * family = fam(j);
      CIndividual * father = ind(++i);
      CIndividual * mother = ind(++i);
      CIndividual * sib1   = ind(++i);
      CIndividual * sib2   = ind(++i);

      // Set family ID
      family->setID(int2str((int)d[j][1]));

      father->setID("1"); 
      father->observed = false;
      father->sex = 1; 
      family->assignToFamily(father,"1");
      
      mother->setID("2"); 
      mother->observed = false;
      mother->sex = 2; 
      family->assignToFamily(mother,"2");

      sib1->setID("3");
      sib1->observed = true;
      family->assignToFamily(sib1,"3");
      sib1->sex = 0;
      sib1->pat = father;
      sib1->mat = mother;
      for (int trait = 1 ; trait <= t ; trait++)
	  sib1->qt(trait) = d[j][1+trait];

      sib2->setID("4");
      sib2->observed = true;
      family->assignToFamily(sib2,"4");
      sib2->sex = 0;
      sib2->pat = father;
      sib2->mat = mother;
      for (int trait = 1 ; trait <= t ; trait++)
	sib2->qt(trait) = d[j][1+t+trait];

      father->addChild(sib1);
      father->addChild(sib2);

      mother->addChild(sib1);
      mother->addChild(sib2);

      int v = 1 + (2*t);

      for (int g = 1 ; g <= l ; g++ ) 
	{
	  sib1->loc(g).one = (int)d[j][++v];
	  sib1->loc(g).two = (int)d[j][++v];
	  //  	  cout << "\n" << g << " (s1) :" << sib1->loc(g).one << "/" << sib1->loc(g).two;
	}
      for (int g = 1 ; g <= l ; g++ ) 
	{
	  sib2->loc(g).one = (int)d[j][++v];
	  sib2->loc(g).two = (int)d[j][++v];
	  //  	  cout << "\n" << g << " (s2) :" << sib2->loc(g).one << "/" << sib2->loc(g).two;
	}

      for (int g = 1 ; g <= l ; g++ ) 
	{
	  v++;
	  addIBD(loc(g),sib1,sib2,
	       d[j][v],
	       d[j][v+1],
	       d[j][v+2]);
	  v += 2; 

  	CIbd * myibd = getIBD(loc(g),sib1,sib2);
	//  	cout << "\nIBD " << g << "(" << sib1->family->getID() << ") = " << myibd->p0 << " " << myibd->p1 << " " << myibd->p2 ; 
	}
    }
}

