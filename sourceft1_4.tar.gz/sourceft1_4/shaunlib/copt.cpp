 #include <iostream>

#include "copt.h"
#include "cmymath.h"
#include "crandom.h"

#define OPSWAP(a,b) {swap=(a); (a)=(b); (b)=swap;}

COpt::COpt()
{
  setTol(0.00000001);
  setParam(3);
  setMaxIter(5000);
  iter = 0;
  verbose = false;
}


COpt::COpt(CFunction_ABC *f)
{
  setTol(0.00000001);
  setParam(3);
  myFunction = f;
  setMaxIter(5000);
  iter = 0;
  verbose = false;
}

void COpt::setStart(CVector &s)
{
  for (int i=1; i<=ndim+1; i++)
    for (int j=1; j<=ndim; j++)
      p[i][j] = s[j];
  //  randomise();
}


void COpt::randomise(int fac)
{
  for (int i=1; i<=ndim+1; i++)
    for (int j=1; j<=ndim; j++)
      p[i][j] += (CRandom::rand()-0.5) / fac ; 
}


CVector COpt::getEstimates()
{
  // Take first row of simplex structure
  CVector parameters(ndim);
  for (int i = 1 ; i <= ndim ; i++ ) 
    parameters[i] = p[1][i];
  return parameters;
}


void COpt::optimise()
{
  // Load y vector
  for (int i=1; i<=ndim+1; i++)
    {
      for (int j=1; j<=ndim; j++)
	x[j] = p[i][j];
      y[i] = myFunction->func(x);
    }

  // Optimise

  const double TINY = 1.0e-10;

  // p : n+1 rows, n columns
  // y : vector : n+1 elements 

  int i, ihi, ilo, inhi, j, mpts=ndim+1;
  double rtol, sum, swap, ysave, ytry;

  iter=0;

  for (int j=1; j<=ndim; j++) 
    psum[j] = p.sumCol(j);

  for(;;) 
  {
      ilo=1;
      ihi=y[1]>y[2] ? (inhi=2,1) : (inhi=1,2);
      for(i=1; i<=mpts; i++)
      {
	  if (y[i]<=y[ilo]) ilo=i;
	  if (y[i]>y[ihi])
	  {
	      inhi=ihi;
	      ihi=i;
	  } 
	  else if (y[i] > y[inhi] && i != ihi) inhi=i;
      }
      rtol = 2.0*fabs(y[ihi]-y[ilo])/(fabs(y[ihi])+fabs(y[ilo])+TINY);
      if (rtol < ftol) 
      {
	  OPSWAP(y[1],y[ilo])
	      for (i=1; i<=ndim; i++) OPSWAP(p[1][i],p[ilo][i])
					  break;
      }
      if (iter >= NMAX) error("CSimplex: Maximum Iterations exceeded.");
      iter += 2;
      
      if (verbose) 
      {
	  cout << "\n-2LL = " << y[1] << " (" << iter << " iter) : param = ";
	  for (int j=1; j<=ndim; j++)
	      cout << "\t" << p[1][j];
      }
      
      ytry = amotry(ihi,-1.0);
      
      if (ytry<=y[ilo])
	ytry = amotry(ihi,2.0);
      else if (ytry >= y[inhi]) {
	ysave=y[ihi];
	ytry=amotry(ihi,0.5);
	if (ytry >= ysave) {
	  for (i=1; i<= mpts; i++) {
	    if (i!=ilo) {
	      for(j=1; j<=ndim; j++)
		p[i][j]=psum[j]=0.5*(p[i][j]+p[ilo][j]);
	      y[i]=myFunction->func(psum);
	    }
	  }
	  iter += ndim;
	  
	  for (int j=1; j<=ndim; j++) 
	    psum[j] = p.sumCol(j);
	  
	}
      } else --iter;
    }
}


double COpt::amotry(int ihi, double fac)
{
  int j;
  double fac1, fac2, ytry;
  
  fac1=(1.0-fac)/ndim;
  fac2=fac1-fac;
  for(j=1;j<=ndim;j++) ptry[j]=psum[j]*fac1-p[ihi][j]*fac2;
  ytry=myFunction->func(ptry);

  if (ytry < y[ihi]) {
    y[ihi]=ytry;
    for(j=1;j<=ndim;j++) {
      psum[j] += ptry[j]-p[ihi][j];
      p[ihi][j]=ptry[j];
    }
  }
  return ytry;
}



