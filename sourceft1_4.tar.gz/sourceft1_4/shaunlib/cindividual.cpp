#include <iostream>
#include <cmath>
#include "cindividual.h"

CIndividual::CIndividual(CSample *s)
{
    sample = s;
    qt_.resize(s->countQTrait());
    loc_.resize(s->countLocus());    
    cov_.resize(s->countCovariate());
    bt_.resize(s->countBTrait());
    nPhase_ = 0;
    phase_.resize(0);
    nChild_ = 0; 
    child_.resize(0);
    observed = false;
    mat = pat  = 0 ;
    flag = false;
}

//  CIndividual::~CIndividual()
//  {
//  };

bool CIndividual::isAncestorOf(CIndividual *f)
{
  vector<CIndividual*> inds;
  vector<bool> checked;
  bool finished = false;
  int nm = 0;

  // Add self to list
  inds.push_back(this);
  checked.push_back(false);

  while (!finished)
    {
      // Check list for a match
      for (int i = 0 ; i < inds.size() ; i++)
	  if (inds[i] == f) return true;
      

      // Increment meioses counter
      nm++;

      // Add children of unchecked inds
      int already = inds.size();
      for (int i = 0 ; i < already ; i++)
	{
	  if (!checked[i])
	    {
	      for (int j = 1 ; j <= inds[i]->nChild() ; j++)
		{
		  inds.push_back(inds[i]->child(j));
		  checked.push_back(false);
		}
	      checked[i] = true;				     
	    }
	}
      

      // All done?
      finished = true;
      for (int i = 0 ; i < inds.size() ; i++)
	if ( checked[i] == false ) finished = false;
      // loop back 
    }
  return false;
}


int CIndividual::countMeioses(CIndividual *f)
{
  vector<CIndividual*> inds;
  vector<bool> checked;
  bool finished = false;
  int nm = 0;

  // Add self to list
  inds.push_back(this);
  checked.push_back(false);

  while (!finished)
    {
      // Check list for a match
      for (int i = 0 ; i < inds.size() ; i++)
	if (inds[i] == f) return nm; // needs changing if inbreeding
      
      // Increment meioses counter
      nm++;

      // Add children of unchecked inds
      int already = inds.size();
      for (int i = 0 ; i < already ; i++)
	{
	  if (!checked[i])
	    {
	      for (int j = 1 ; j <= inds[i]->nChild() ; j++)
		{
		  inds.push_back(inds[i]->child(j));
		  checked.push_back(false);
		}
	      checked[i] = true;				     
	    }
	}
      

      // All done?
      finished = true;
      for (int i = 0 ; i < inds.size() ; i++)
	if ( checked[i] == false ) finished = false;
      // loop back 
    }
  return nm;
}


void CIndividual::enumeratePhase()
{
    // populate hap with all consistent haplotype pairs
    // genotype data could be missing

    // For H heterozygous sites, there are 2^(H-1) possible haplotypes
    // After 1st heterozygous site, add all flips of subsequent heterozygous sites

    // Deal with missing sites: treat as hets 
    
    // list of heterozygous sites
    vector<int> het;

    // list of missing sites
    vector<int> miss;

    // Temporary Haplotype Pair
    int n = sample->countLocus();

    // Copy diplotype information into temporary haplotype
    CHaplotype a(n), b(n), save_a(n), save_b(n);
    
    for (int i=1; i<=n; i++)
    {
	a.pos(i) = loc(i).one;
	b.pos(i) = loc(i).two;

	save_a.pos(i) = loc(i).one;
	save_b.pos(i) = loc(i).two;
    }
    
    // move up to 1st heterozygous site
    int h = 0;
    for (int p = 1 ; p <= n ; p++) 
	if ( a.pos(p) != b.pos(p) )
	   { h = p; break; } 
    
    // add het sites
    for (int p = h+1 ; p <= n ; p++)
	if ( a.pos(p) != b.pos(p) )
	    het.push_back(p);

    // add all missing sites
    for (int p = 1 ; p <= n ; p++)
	if ( a.pos(p) == "0" ) 
	    miss.push_back(p);

    int nhap = int(pow(2.0,int(het.size())));
    int nmiss = int(pow(2.0,int(miss.size()))); 
    
    // if no missing (2^0 = 1) 
    if (miss.size() == 0) nmiss = 0;

    // append flipped heterozygous sites 
    for (int i = 0 ; i < nhap ; i++)
    {
	int gc = graycode(i,het.size());
	
	a = save_a;
	b = save_b;
	
	for (int p = 0; p < het.size(); p++)
	    if (gc & int(pow(2.0,p))) 
	    {
		a.pos(het[p]) = save_b.pos(het[p]);
		b.pos(het[p]) = save_a.pos(het[p]);
	    }
	
	// If no missing genotypes just add these straight
	if (nmiss == 0)
	{
	    addPhase(a,b);
	    addPhase(b,a);
	}
	else
	{

	    // Otherwsie append all possible missing sites
	    for (int i = 0 ; i < nmiss ; i++)    
	    {
		int gc = graycode(i,nmiss);
		
		a = save_a;
		b = save_b;
		
		for (int p = 0; p < miss.size() ; p++)
		{

		    // missing genotype, first position
		    if (gc & int(pow(2.0,p*2)))
			a.pos(miss[p]) = 1;
		    else
			a.pos(miss[p]) = 2;
		    
		    if (gc & int(pow(2.0,p*2+1)))
			b.pos(miss[p]) = 1;
		    else
			b.pos(miss[p]) = 2;
		    
		}
		
		addPhase(a,b);
		addPhase(b,a);
		
	    }
	    
	}

    }
}


void CIndividual::addPhase(CHaplotype pat, CHaplotype mat, double prob)
{
    CPhase new_phase(pat,mat,prob);
    phase_.push_back(new_phase);
    nPhase_++;
}

void CIndividual::removePhase(int n)
{
    phase_.erase(phase_.begin()+n-1);
    nPhase_--;
}

