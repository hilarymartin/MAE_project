#include <iostream>
#include "csasimplex.h"

#include "copt.h"
#include "csimann.h"

CSASimplex::CSASimplex(CFunction_ABC *f)
{
    userFunction = f;
    obest = 99999999;
    th = 1; 

    nparam=2;
    verbose = false;

    simplex_rand_factor = 10;
    simplex_tol = 1e-6;
    simplex_mxiter = 20000;

    sa_rand_factor = 10;
    sa_tol = 1e-6;    
    sa_mxiter = 100;
    sa_temp = 10;
    sa_cycle = 10;
    sa_decline = 0.8;
    
    start.setCol(nparam);
    start.clear();
}


void CSASimplex::minimise()
{

    for (int i = 1 ; i <= th ; i++)
    {
	
	// SIMULATED ANNEALING
	
	CSimAnn sa(userFunction);
	sa.setParam(nparam);
	sa.setStart(start);
	sa.randomise(sa_rand_factor);
	sa.setTol(sa_tol);
	sa.setMaxIter(sa_mxiter);
	sa.setDecline(sa_decline);
	sa.setTemp(sa_temp);
	sa.setCycle(sa_cycle);
	sa.verbose = verbose;
	sa.optimise();

	// Improvement?
	if (sa.getLikelihood() < obest) 
	{
	    start = pbest = sa.getEstimates();
	    obest = sa.getLikelihood();
	}

	if (semiverbose)
	{
 	    sa.getEstimates().display();
 	    cout << "\tSA step -2LL = " << sa.getLikelihood() ;
	}

	// SIMPLEX

	COpt simplex(userFunction);
	
	simplex.setParam(nparam);
	
	simplex.setStart(start);
	simplex.randomise(simplex_rand_factor);
	simplex.setTol(simplex_tol);
	simplex.setMaxIter(simplex_mxiter);
	simplex.verbose = verbose;
	simplex.optimise();
	
	if (simplex.getLikelihood() < obest) 
	{
	    start = pbest = simplex.getEstimates();
	    obest = simplex.getLikelihood();
	}

	if (semiverbose)
	{
 	    simplex.getEstimates().display();
 	    cout << "\tSIMPLEX step -2LL = " << simplex.getLikelihood() ;
	}

	
    }
}
    
