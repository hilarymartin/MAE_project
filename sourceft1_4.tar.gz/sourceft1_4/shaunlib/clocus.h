#ifndef __CLOCUS_H__
#define __CLOCUS_H__

#include <string>

using namespace std;

class CLocus
{

 public:
      CLocus();
      ~CLocus();

      string one;       // first allele
      string two;       // second allele

      static string missing;

};

#endif


