// Implement CMatrix class

#include <iostream>
#include <math.h>
#include <stdarg.h>

#include "cmatrix.h"
#include "error.h"
#include "cmymath.h"
#include "cdata.h"

using namespace std;

CVector::CVector()
    { setCol(2); }
CVector::CVector(int n)
    { setCol(n); }
CRowVector::CRowVector()
    { setCol(2); }
CRowVector::CRowVector(int n)
    { setCol(n); }
CColVector::CColVector()
    { setCol(2); }
CColVector::CColVector(int n)
    { setCol(n); }
CVector::~CVector()
    { /* nothing */ }


void CVector::setCol(int c)
    { col = c; d.resize(col); }

int CVector::getCol() const
    { return col; }


// ---------------------------------------------
// Vector operation functions

CVector CVector::negate() const
{
     CVector n(col);
     for (int i=1; i <= col; i++)
             n[i] = -(*this)[i];
     return n;
}

void CVector::add(int n)
     { for (int i=1; i <= col; i++) (*this)[i] += n; }

void CVector::add(double n)
     { for (int i=1; i <= col; i++) (*this)[i] += n; }

void CVector::subtract(int n)
     { this->add(-n); }

void CVector::subtract(double n)
     { this->add(-n); }

void CVector::multiply(int n)
     { for (int i=1; i <= col; i++) (*this)[i] *= n; }

void CVector::multiply(double n)
     { for (int i=1; i <= col; i++) (*this)[i] *= n; }

void CVector::power(double n)
     { for (int i=1; i <= col ; i++) (*this)[i] = pow((*this)[i],n); }

void CVector::sqrt()
     { for (int i=1; i <= col ; i++) (*this)[i] = ::sqrt((*this)[i]); }

void CVector::clear()
     { for (int i=1; i <= col ; i++) (*this)[i] = 0; }  

void CVector::load(int num, ...)
{
  va_list arguments;        
  va_start(arguments, num); 
  setCol(num);
  for(int i=1; i <= num; i++)   
    (*this)[i] = va_arg(arguments, double);  
  va_end(arguments);      
}

CMatrix CVector::v2d() const
{
  CMatrix n(col,col); 
  for (int i = 1 ; i <= col ; i++) n[i][i] = (*this)[i];
  return n;
}


double CVector::sum() const
{
       double s=0;
       for (int i = 1 ; i <= getCol() ; i++)
           s += (*this)[i];
       return s;
}


CVector CVector::operator+(const CVector & rhs) const
{
     CVector n(col);
     if ( col != rhs.col )
        error("Vectors not conformable for addition");
     for (int i=1; i <= col; i++)
         n[i] = (*this)[i] + rhs[i];
     return n;
}

CVector CVector::operator-(const CVector & rhs) const
{
     CVector n(col);
     if ( col != rhs.col )
        error("Vectors not conformable for subtraction");
     n = *this + rhs.negate();
     return n;
}

CVector CVector::operator%(const CVector &rhs) const
{
     CVector n(col);
     if ( col != rhs.col )
        error("Vectors not conformable for element multiplication");
     for (int i=1; i <= col; i++)
         n[i] = (*this)[i] * rhs[i];
     return n;
}

CVector CVector::operator/(const CVector &rhs) const
{
     CVector n(col);
     if ( col != rhs.col )
        error("Vectors not conformable for element division");
     for (int i=1; i <= col; i++)
         n[i] = (*this)[i] / rhs[i];
     return n;
}


CRowVector CRowVector::operator+(const CRowVector & rhs) const
{
     CRowVector n(col);
     if ( col != rhs.col )
        error("Vectors not conformable for addition");
     for (int i=1; i <= col; i++)
         n[i] = (*this)[i] + rhs[i];
     return n;
}

CRowVector CRowVector::operator-(const CRowVector & rhs) const
{
     CRowVector n(col);
     if ( col != rhs.col )
        error("Vectors not conformable for subtraction");
     for (int i=1; i <= col; i++)
         n[i] = (*this)[i] - rhs[i];
     return n;
}

CRowVector CRowVector::operator%(const CRowVector & rhs) const
{
     CRowVector n(col);
     if ( col != rhs.col )
        error("Vectors not conformable for element multiplication");
     for (int i=1; i <= col; i++)
         n[i] = (*this)[i] * rhs[i];
     return n;
}

CRowVector CRowVector::operator/(const CRowVector & rhs) const
{
     CRowVector n(col);
     if ( col != rhs.col )
        error("Vectors not conformable for element division");
     for (int i=1; i <= col; i++)
         n[i] = (*this)[i] / rhs[i];
     return n;
}



CColVector CColVector::operator+(const CColVector & rhs) const
{
     CColVector n(col);
     if ( col != rhs.col )
        error("Vectors not conformable for addition");
     for (int i=1; i <= col; i++)
         n[i] = (*this)[i] + rhs[i];
     return n;
}

CColVector CColVector::operator-(const CColVector & rhs) const
{
     CColVector n(col);
     if ( col != rhs.col )
        error("Vectors not conformable for subtraction");
     for (int i=1; i <= col; i++)
         n[i] = (*this)[i] - rhs[i];
     return n;
}


CColVector CColVector::operator%(const CColVector & rhs) const
{
     CColVector n(col);
     if ( col != rhs.col )
        error("Vectors not conformable for element multiplication");
     for (int i=1; i <= col; i++)
         n[i] = (*this)[i] * rhs[i];
     return n;
}

CColVector CColVector::operator/(const CColVector & rhs) const
{
     CColVector n(col);
     if ( col != rhs.col )
        error("Vectors not conformable for element division");
     for (int i=1; i <= col; i++)
         n[i] = (*this)[i] / rhs[i];
     return n;
}


CRowVector CRowVector::operator*(const CMatrix &rhs) const
{
     if ( getCol() != rhs.getRow() )
      error("Vector and matrix not conformable for multiplication.");
     CRowVector n(rhs.getCol());
     for (int i=1; i <= getCol(); i++)
       {
	 n[i] = 0;
         for (int j=1; j <= rhs.getRow(); j++)
	   n[i] += (*this)[j] * rhs[j][i];
       }
     return n;
}

CMatrix CColVector::operator*(const CRowVector & rhs) const
{
     if ( getCol() != rhs.getCol() )
      error("Vectors not conformable for multiplication.");
     CMatrix n(getCol(),getCol());
     for (int i=1; i <= col; i++)
         for (int j=1; j <= col; j++)
             n[i][j] = (*this)[i] * rhs[j];
     return n;
}


double CRowVector::operator*(const CColVector & rhs) const
{
     if ( getCol() != rhs.getCol() )
      error("Vectors not conformable for multiplication.");
     double n = 0;
     for (int i=1; i <= col; i++)
         n += (*this)[i] * rhs[i];
     return n;
}


CRowVector CRowVector::operator|(const CRowVector &rhs) const
{
  CRowVector n(getCol()+rhs.getCol());
  for (int i=1; i <= getCol(); i++)
          n[i] = (*this)[i];
  for (int i=1; i <= rhs.getCol(); i++)
      n[getCol()+i] = rhs[i];
  return n;
}

CMatrix CRowVector::operator||(const CRowVector &rhs) const
{
  if (getCol() != rhs.getCol())
    error("RowVectors must have same # of rows for || adhesion.");

  CMatrix n(2,getCol());

  for (int i=1; i <= getCol(); i++)
      n[1][i] = (*this)[i];

  for (int i=1; i <= getCol(); i++)
      n[2][i] = rhs[i];

  return n;
}

CMatrix CRowVector::operator||(const CMatrix &rhs) const
{
  if (getCol() != rhs.getCol())
    error("RowVector must have same # of elements as cols in Matrix for || adhesion.");

  CMatrix n(1+rhs.getRow(),getCol());

  for (int i=1; i <= getCol(); i++)
      n[1][i] = (*this)[i];

  for (int i=1; i <= rhs.getRow(); i++)
      for (int j=1; j <= getCol(); j++)
	  n[i+1][j] = rhs[i][j];

  return n;
}



CMatrix CColVector::operator|(const CColVector &rhs) const
{
  if (getCol() != rhs.getCol())
    error("ColVectors must have same # of cols for | adhesion.");

  CMatrix n(getCol(),2);

  for (int i=1; i <= getCol(); i++)
      n[i][1] = (*this)[i];

  for (int i=1; i <= getCol(); i++)
      n[i][2] = rhs[i];

  return n;

}


CMatrix CColVector::operator|(const CMatrix &rhs) const
{
    if (getCol() != rhs.getRow())
	error("ColVector must have same # of elements as rows in Matrix for | adhesion.");

    CMatrix n(getCol(),1+rhs.getCol());

    for (int i=1; i <= getCol(); i++)
	n[i][1] = (*this)[i];

    for (int i=1; i <= getCol(); i++)
	for (int j=1; j <= rhs.getCol(); j++)
	    n[i][j+1] = rhs[i][j];
    
    return n;
}



CColVector CColVector::operator||(const CColVector &rhs) const
{
  CColVector n(getCol()+rhs.getCol());
  for (int i=1; i <= getCol(); i++)
          n[i] = (*this)[i];
  for (int i=1; i <= rhs.getCol(); i++)
      n[getCol()+i] = rhs[i];
  return n;
}




CColVector CRowVector::transpose() const
{
   CColVector n(getCol());
   n.copy(*this);
   return n;
}

CRowVector CColVector::transpose() const
{
   CRowVector n(getCol());
   n.copy(*this);
   return n;
}


CVector & CVector::operator=(const CVector & rhs)
        { copy(rhs); return *this; }


bool CVector::operator==(const CVector & rhs) const
{
    if (col != rhs.getCol()) return false;
    for (int i=1; i <= col; i++)
	if ( (*this)[i] != rhs[i] ) return false;
    return true;
}

void CVector::copy(const CVector & rhs)
{
  setCol(rhs.getCol());
  for (int i=1; i <= col; i++)
    (*this)[i] = rhs[i];
}

CColVector & CColVector::operator=(const CColVector & rhs)
{ copy(rhs); return *this; }

CColVector & CColVector::operator=(const CVector & rhs)
{ copy(rhs); return *this; }

CRowVector & CRowVector::operator=(const CRowVector & rhs)
{ copy(rhs); return *this; }

CRowVector & CRowVector::operator=(const CVector & rhs)
{ copy(rhs); return *this; }




void CVector::display()
{
  cout << "\n[ ";
  for (int i=1; i <= col; i++)
    cout << (*this)[i] << " ";
  cout << "]";
}


void CColVector::display()
{
  for (int i=1; i <= col; i++)
    cout << "\n[ " << (*this)[i] << " ]";
}


/////////////////////////////////////
// Matrix Manipulation functions


CMatrix::CMatrix()
{
   setRow(2);
   setCol(2);
}

CMatrix::CMatrix(int r, int c)
{
   setRow(r);
   setCol(c);
}


CMatrix::~CMatrix()
{
// nothing
}


void CMatrix::setRow(int r)
{ row = r; d.resize(r); (*this).setCol((*this).getCol()); }

int CMatrix::getRow() const
{ return row; }

int CMatrix::getCol() const
{ return row > 0 ? (*this)[1].getCol() : 0 ; }

void CMatrix::setCol(int c)
{
     for (int i=1; i <= row; i++)
         (*this)[i].setCol(c);
}


void CMatrix::load(int num, ...)
{
  va_list arguments;        
  va_start(arguments, num); 
  for(int i=1; i <= row; i++)  
    for (int j=1 ; j <= getCol() ; j++)
      (*this)[i][j] = va_arg(arguments, double);  
  va_end(arguments);      
}

void CMatrix::unit(double n)
{
  int r = getRow() < getCol() ? getRow() : getCol();
  for (int i=1 ; i <= r ; i++)
    (*this)[i][i] = n;
}

void CMatrix::import(string filename)
{ 
  CData temp; 
  temp.import(filename); 
  copy(temp.extractMatrix(1,1,temp.getInd(),temp.getVar()));
}


void CMatrix::add(int n)
{
  for (int i=1; i <= row; i++)
    for (int j=1; j <= getCol(); j++)
      (*this)[i][j] += n;
}

void CMatrix::add(double n)
{
  for (int i=1; i <= row; i++)
    for (int j=1; j <= getCol(); j++)
      (*this)[i][j] += n;
}

void CMatrix::subtract(int n)
   { this->add(-n); }

void CMatrix::subtract(double n)
   {  this->add(-n); }

void CMatrix::multiply(int n)
{
  for (int i=1; i <= row; i++)
    for (int j=1; j <= getCol(); j++)
      (*this)[i][j] *= n;
}

void CMatrix::multiply(double n)
{
  for (int i=1; i <= row; i++)
    for (int j=1; j <= getCol(); j++)
      (*this)[i][j] *= n;
}

CMatrix CMatrix::negate() const
{
     CMatrix n(row,getCol());
     for (int i=1; i <= row; i++)
         for (int j=1; j <= getCol(); j++)
             n[i][j] = -(*this)[i][j];
     return n;
}

void CMatrix::negate()
{
  for (int i=1; i <= row; i++)
    for (int j=1; j <= getCol(); j++)
      (*this)[i][j] = -(*this)[i][j];
}

void CMatrix::clear()
{
  for (int i=1; i <= row; i++)
    for (int j=1; j <= getCol(); j++)
      (*this)[i][j] = 0;
}

CMatrix CMatrix::operator+(const CMatrix & rhs) const
{
     CMatrix n(row,getCol());

     if ( row != rhs.row || getCol() != rhs.getCol() )
        error("Matrices not conformable for addition");

     for (int i=1; i <= row; i++)
         for (int j=1; j <= getCol(); j++)
            n[i][j] = (*this)[i][j] + rhs[i][j];

     return n;
}

CMatrix CMatrix::operator-(const CMatrix & rhs) const
{
     CMatrix n(row,getCol());
     if ( row != rhs.row || getCol() != rhs.getCol() )
        error("Matrices not conformable for subtraction");
     n = *this + rhs.negate();
     return n;
}

CMatrix CMatrix::operator*(const CMatrix & rhs) const
{
     if ( getCol() != rhs.row )
      {
       cout << "\nMatrices not conformable!\n";
       exit(0);
      }
     CMatrix n(row,rhs.getCol());
     for (int i=1; i <= row; i++)
         for (int j=1; j <= rhs.getCol(); j++)
             {
              n[i][j] = 0;
              for (int k=1; k <= getCol() ; k++)
                n[i][j] += (*this)[i][k] * rhs[k][j];
             }
     return n;
}

CColVector CMatrix::operator*(const CColVector &rhs) const
{
     if ( getCol() != rhs.getCol() )
      {
       cout << "\nMatrices not conformable!\n";
       exit(0);
      }
     CColVector n(row);
     for (int i=1; i <= row; i++)
         {
          n[i] = 0;
              for (int k=1; k <= getCol() ; k++)
                n[i] += (*this)[i][k] * rhs[k];
             }
     return n;
}


CMatrix CMatrix::operator&(const CMatrix &rhs) const
{
  CMatrix m((*this).getRow() * rhs.getRow() , 
	    (*this).getCol() * rhs.getCol() );
  
  int indx_i = 1; 
  int indx_j = 1;

  for (int i1 = 1 ; i1 <= (*this).getRow() ; i1++)
    for (int i2 = 1 ; i2 <= rhs.getRow() ; i2++)
      {
	
	for (int j1 = 1 ; j1 <= (*this).getCol() ; j1++)
	  for (int j2 = 1 ; j2 <= rhs.getCol() ; j2++)
	    {
	      m[indx_i][indx_j] = (*this)[i1][j1] 
		* rhs[i2][j2];
	      indx_j++;
	    }
	indx_i++;
	indx_j=1;
      }
  return m;
}



CMatrix & CMatrix::operator=(const CMatrix & rhs)
{
  copy(rhs);
  return *this;
}

CMatrix & CMatrix::operator=(const double rhs)
{
  setCol(1);
  setRow(1);
  (*this)[1][1] = rhs;
  return *this;
}



void CMatrix::copy(const CMatrix & rhs)
{
  setRow(rhs.getRow());
  setCol(rhs.getCol());
  for (int i=1; i <= getRow(); i++)
    for (int j=1; j <= getCol(); j++)
      (*this)[i][j] = rhs[i][j];
}


CMatrix CMatrix::operator|(const CMatrix &rhs) const
{
  if (getRow() != rhs.getRow())
    error("Matrices must have same # of rows for | adhesion.");

  CMatrix n(getRow(), getCol()+rhs.getCol());

  for (int i=1; i <= getRow(); i++)
    for (int j=1; j <= getCol(); j++)
      n[i][j] = (*this)[i][j];

  for (int i=1; i <= getRow(); i++)
    for (int j=1; j <= rhs.getCol(); j++)
      n[i][j+getCol()] = rhs[i][j];

  return n;
}


CMatrix CMatrix::operator||(const CMatrix &rhs) const
{
  if (getCol() != rhs.getCol())
    error("Matrices must have same # of cols for || adhesion.");
  CMatrix n(getRow()+rhs.getRow(), getCol());
  for (int i=1; i <= getRow(); i++)
      for (int j=1; j <= getCol(); j++)
          n[i][j] = (*this)[i][j];
  for (int i=1; i <= rhs.getRow(); i++)
      for (int j=1; j <= getCol(); j++)
          n[i+getRow()][j] = rhs[i][j];
  return n;
}

CMatrix CMatrix::operator|(const CColVector &rhs) const
{
  if (getRow() != rhs.getCol())
    error("Matrices must have same # of rows for | adhesion.");
  CMatrix n(getRow(), getCol()+1);
  for (int i=1; i <= getRow(); i++)
      for (int j=1; j <= getCol(); j++)
          n[i][j] = (*this)[i][j];
  for (int i=1; i <= getRow(); i++)
      n[i][getCol()+1] = rhs[i];
  return n;
}

CMatrix CMatrix::operator||(const CRowVector &rhs) const
{
  if (getCol() != rhs.getCol())
    error("Matrices must have same # of rows for || adhesion.");
  CMatrix n(getRow()+1, getCol());
  for (int i=1; i <= getRow(); i++)
      for (int j=1; j <= getCol(); j++)
          n[i][j] = (*this)[i][j];
  for (int i=1; i <= getCol(); i++)
      n[getRow()+1][i] = rhs[i];
  return n;
}

CVector CMatrix::d2v() const
{
  CVector r(getRow());
  for (int i = 1 ; i <= getRow() ; i++)
    r[i] = (*this)[i][i];
  return r;
}

void CMatrix::display()
{
  for (int i=1; i <= row; i++)
    {
      cout << "\n[ ";
      for (int j=1; j <= (*this)[i].col; j++)
	cout << (*this)[i][j] << " ";
      cout << "]";
    }
}


CMatrix CMatrix::transpose() const
{
 CMatrix n(getCol(),getRow());
 for (int i=1; i <= getCol() ; i++)
     for (int j=1 ; j <= getRow() ; j++)
         n[i][j] = (*this)[j][i];
  return n;
}


CMatrix CMatrix::inverse() const
{
  double d;
  int i, ii, j;
  if (getRow() != getCol() ) error("Cannot invert non-square matrix");
  int n = getCol();

// indx is an integer array
  IntArray indx;
  indx().resize(n);

  CVector col(n);
  CMatrix y(n,n);
  CMatrix tm(n,n);
  tm.copy(*this);

  ludcmp(tm,indx,d);

  for (j=1; j<=n; j++)
    {
      for (i=1; i<=n; i++) col[i]=0;
        col[j]=1;
      lubksb(tm,indx,col);
      for (i=1; i<=n; i++) y[i][j]=col[i];
    }

  return y;

}


void CMatrix::ludcmp(CMatrix &a, IntArray &indx, double &d)
{
  int i, imax, j, k;
  double big, dum, sum, temp;
  int n = a.getCol();
  CVector vv(n);
  d=1;

  for (i=1; i<=n; i++)
    {
      big=0;
      for (j=1; j<=n; j++)
	if ((temp=fabs(a[i][j])) > big) big=temp;
      if (big==0) error("singular matrix in ludcmp");
      vv[i]=1/big;
    }

  for (j=1; j<=n; j++)
    {
      for (i=1; i<j; i++)
	{
	  sum = a[i][j];
	  for (k=1; k<i; k++) sum -= a[i][k] * a[k][j];
	  a[i][j]=sum;
	}
      big=0;
      for (i=j; i<=n; i++)
	{
	  sum=a[i][j];
	  for (k=1; k<j; k++)
	    sum -= a[i][k] * a[k][j];
	  a[i][j]=sum;
	  if ((dum=vv[i]*fabs(sum)) >= big)
	    {
	      big = dum;
	      imax = i;
	    }
	}
      if (j != imax)
	{
	  for (k=1; k<=n; k++)
	    {
	      dum=a[imax][k];
	      a[imax][k]=a[j][k];
	      a[j][k]=dum;
	    }
	  d = -d;
	  vv[imax]=vv[j];
	}
      indx(j)=imax;
      if (a[j][j] == 0) a[j][j] = 1.0e-20;

      if (j != n)
	{
	  dum = 1/(a[j][j]);
	  for (i=j+1; i<=n; i++) a[i][j] *= dum;
	}
    }
}

void CMatrix::lubksb(CMatrix &a, IntArray &indx, CVector &b)
{
  int i, ii=0, ip, j;
  double sum;

  int n = a.getCol();

  for (i=1; i<=n; i++)
    {
      ip=indx(i);
      sum=b[ip];
      b[ip]=b[i];
      if (ii)
	for (j=ii; j<=i-1; j++) sum -= a[i][j]*b[j];
      else if (sum) ii=i;
      b[i]=sum;
    }
  for (i=n; i>=1; i--)
    {
      sum=b[i];
      for (j=i+1; j<=n; j++) sum -= a[i][j]*b[j];
      b[i]=sum/a[i][i];
    }
}


bool CMatrix::singular() const
{
    if (getRow() != getCol() )
	error("matrix must be square");
    
    int i, j;
    double big, dum, sum, temp;
    int n = getCol();
    
    for (i=1; i<=n; i++)
    {
	big=0;
	for (j=1; j<=n; j++)
	    if ((temp=fabs((*this)[i][j])) > big) big=temp;
	if (big==0) return true;
    }
    return false;
}

double CMatrix::det() const
{
  double d;
  int i;

  if (getRow() != getCol() )
     error("Cannot get determinant for non-square matrix");

  int n = getCol();

  IntArray indx;
  indx().resize(n);
  CVector col(n);

  CMatrix tm(n,n);
  tm.copy(*this);

  ludcmp(tm,indx,d);

  for (i=1; i<=n; i++)
    d *= tm[i][i];

  return d;
}




double CMatrix::trace() const
{
  if ( getRow() != getCol() ) 
    error("Cannot calculate trace for non-square matrix");
  double t = 0;
  for (int i = 1 ; i <= getCol() ; i++ )
    t += (*this)[i][i];
  return t;
}

double CMatrix::sumRow(int n) const
{
       double s=0;
       for (int i = 1 ; i <= getCol() ; i++)
           s += (*this)[n][i];
       return s;
}

double CMatrix::sumCol(int n) const
{
       double s=0;
       for (int i = 1 ; i <= getRow() ; i++)
           s += (*this)[i][n];
       return s;
}

double CMatrix::sum() const
{
       double s=0;
       for (int i = 1 ; i <= getRow() ; i++)
           for (int j = 1 ; j <= getCol() ; j++)
               s += (*this)[i][j];
       return s;
}


double CMatrix::chisq() const
{
  double chisq = 0;

  for (int i=1; i <= getRow() ; i++)
      for (int j=1; j <= getCol() ; j++)
         {
	   double expected = (sumRow(i)*sumCol(j))
                   	     / sum();
	   chisq += mymath::sqr( (*this)[i][j] - expected ) / expected ;
	 }
  return chisq;
}



///////////////////////
// CTensor functions



CTensor::CTensor()
{
   setDep(2);
   setRow(2);
   setCol(2);
}

CTensor::CTensor(int d, int r, int c)
{
   setDep(d);
   setRow(r);
   setCol(c);
}


CTensor::~CTensor()
{
// nothing
}


void CTensor::setDep(int depth)
{ dep = depth; d.resize(dep); 
 (*this).setRow((*this).getRow());
 (*this).setCol((*this).getCol());
}
int CTensor::getDep() const   { return dep; }

void CTensor::setRow(int r)
{
    for (int i=1; i <= dep; i++)
	(*this)[i].setRow(r);
}
int CTensor::getRow() const   { return dep > 0 ? (*this)[1].getRow() : 0 ; }


void CTensor::setCol(int c)
{
    for (int i=1; i <= dep; i++)
	    (*this)[i].setCol(c);
}
int CTensor::getCol() const { return dep > 0 ? (*this)[1].getCol() : 0 ; }


void CTensor::clear()
{
    for (int i=1; i <= dep; i++)
	for (int j=1; j <= getRow(); j++)
	    for (int k=1; k <= getCol(); k++)
		(*this)[i][j][k] = 0;
}
