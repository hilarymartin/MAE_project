#ifndef __CMYMATH_H__
#define __CMYMATH_H__

#include "cmatrix.h"
#include <cmath>

using namespace std;

namespace mymath{
    
    // Random numbers, permutation
    void init_rnd(long);
    double rnd();
    int rnd(int);
    double rndnorm();
    void permute(vector<int>&);
    void permute_this(vector<int> &a);
    void permute_this(vector<double> &a);

    // NR-style arrays
    double *nr_vector(long nl, long nh);
    void free_nr_vector(double *v, long nl, long nh);


  double ***nr_3tensor(long nrl, long nrh, long ncl, long nch, long ndl, long ndh);
  void free_nr_3tensor(double ***t, long nrl, long nrh, long ncl, long nch,
	long ndl, long ndh);
  int ***nr_i3tensor(long nrl, long nrh, long ncl, long nch, long ndl, long ndh);
  void free_nr_i3tensor(int ***t, long nrl, long nrh, long ncl, long nch,
	long ndl, long ndh);


  // PDF 
  long double normdist(double);
  long double normden(CColVector &scr, CColVector &mean, CMatrix &var);
  long double normden(double, double, double);
  double nchi(double x, double df, double ncp);
  double invnchi(double p, double df, double ncp);
  double ncpnchi(double p, double x, double df);
  double norm(double x, double mean, double sd);
  double invnorm(double p, double mean, double sd);

  // Basic functions
  double sqr(double);
  long unsigned int factorial(int n);
  long unsigned int combin(int n, int k);
  
  // Power and sample size
  double pdf_power(double alpha, double df, double l);
  double pdf_sample(double alpha, double df, double ncp, double power);

  
  // Statistical functions
  double correlation(const CColVector&, const CColVector&);
  double covariance(const CColVector&, const CColVector&);
  double variance(const CColVector&);
  double stdev(const CColVector&);
  double mean(const CColVector&);


  // Misc
  double linear_hypothesis(CColVector &, CMatrix &, CMatrix &, CColVector &);

  
}



#endif

