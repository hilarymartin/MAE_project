#include "cmapfile.h"
#include "error.h"
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <cstdio>

typedef pair<string,int>      Psi;
typedef pair<string,string>   Pss;
typedef pair<string,double>   Psd;
typedef pair<string,long int> Psl;

CMap::CMap()
{
 token1 = token2 = token3 = "";
 order.clear();
 chr.clear();
 cM.clear();
 bp.clear();
}

CMap::~CMap()
{
// 
}

bool CMap::readMapfile(string filename, CDatfile & dat)
{
    
    // The map file specifies the position and therefore order of all markers. 
    // Markers MUST be in genomic order in the MAP file. 
    // Markers NEED NOT be in genomic order in the DAT/PED files.
    
    // Read in .map file, line-by-line
    // Chromosome      Marker_name     Genetic_distance     Physical_distance     

    ifstream in;
    in.open(filename.c_str());

    vector< vector<string> > entries;    
    
    while(!in.eof())
    {
	
	// read a line
	char buf[100];
	in.getline(buf,100,'\n');
	
	// output to temp
	ofstream out2;
	string filename2 = uniqname(".temp-cmap");
	out2.open(filename2.c_str());
	out2 << buf;
	out2.close();

	// read from temp
	ifstream in2;
	vector<string> words;
	in2.open(filename2.c_str());
	while (!in2.eof())
	{
	    string word ;
	    in2 >> word;
	    if (word != "") words.push_back(word);
	}	    
	in2.close();

        // is this marker indicated to be included in 
	// the DAT file ? 
	for (int i = 0 ; i < dat.type.size() ; i++)
	{
	    if (words.size() > 0)
		if ( dat.name[i] == words[1]) 
		{
		    // add 
		    if ( dat.type[i] == "M" || dat.type[i] == "N")
			entries.push_back(words);
		    break;
		}
	}
	
	// clean up
	remove(filename2.c_str());

    }
    in.close();
    
    
    // Enter info into vars

    for (int i=0; i < entries.size() ; i++)
    {

	if (entries[i].size() == 0) break;
	vector<string> line = entries[i];
	
	// order
	Psi p0(line[1], i+1);
	order.insert(p0);

	// chromosome
	Pss p1(line[1], line[0]);
	chr.insert(p1);
	
	// genetic distance
	Psd p2(line[1], atof(line[2].c_str()));
	cM.insert(p2);
	
	// physical distance? 
	if (entries[i].size() >= 4)
	{
	    Psl p3(line[1], (long int)atof(line[3].c_str()));
	    bp.insert(p3);
	}	    
    }
    
    // Count number of loci in map
    n = chr.size();
    
    rf.setCol(n);
    rf.setRow(n);

     // Calculate recombination fractions, given cM
    map<string,int>::iterator i;
    map<string,int>::iterator j;

    for (i = order.begin(); i != order.end(); i++)
	for (j = order.begin(); j != order.end(); j++)
	{
	    int ni = i->second;
	    int nj = j->second;
	    
	    double cM1 = cM[i->first];
	    double cM2 = cM[j->first];

	    double distance = cM1 - cM2;
	    if (distance < 0) distance = -distance;
	    distance *= 0.01;
	    rf[ni][nj] = (1.0 - exp(-2.0 * distance)) * 0.5;
	}
    
    // Kosambi cM -> recombination 
    // double e_to_4x = exp(4.0 * distance);
    // (0.5 * (e_to_4x - 1.0) / (e_to_4x + 1.0));
    
    in.close();

}


