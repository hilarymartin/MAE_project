// Implementation for Error handling routines

#include <iostream>
#include "error.h"
#include "cmymath.h"

void error(string emsg)
{
 std::cout << "Error detected!"
      << " : " << emsg
      << "\n";
 exit(0);
}
