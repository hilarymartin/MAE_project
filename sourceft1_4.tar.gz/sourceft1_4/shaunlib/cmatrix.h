#ifndef __CMATRIX_H__
#define __CMATRIX_H__

#include <vector>
#include <string>
#include "misc.h"

using namespace std;

class CMatrix;

class CVector
{
 friend class CMatrix;
 public:
      CVector();
      CVector(int);
      CVector(const CVector &rhs) { copy(rhs); }
      virtual ~CVector();

      void copy(const CVector & rhs);
      void add(int n);
      void add(double n);
      void subtract(int n);
      void subtract(double n);
      void multiply(int n);
      void multiply(double n);
      void power(double n);
      void sqrt();
      CVector negate() const;
      double sum() const;
      void clear();
      void load(int num, ...);

      CVector operator+(const CVector &) const;
      CVector operator-(const CVector &) const;
      CVector operator%(const CVector &) const;
      CVector operator/(const CVector &) const;

      CMatrix v2d() const;
      
      void display();

      void setCol(int);
      int getCol() const;

      double & operator [] (const int n)
             { return d[n-1]; }
      double operator [] (const int n) const
  	     { return d[n-1]; } 

      CVector & operator=(const CVector &);
      bool operator== (const CVector &) const;

      vector<double> d;
      int col;
};

/////////////////////////////////////////////
// Derived classes Row and Column vectors
// Specific vector multiplication routines


class CColVector;

class CRowVector : public CVector
{
public:
      CRowVector();
      CRowVector(int);

      CRowVector(const CRowVector &rhs) { copy(rhs); }
      CRowVector & operator=(const CRowVector &);

      CRowVector(const CVector &rhs) { copy(rhs); }
      CRowVector & operator=(const CVector &);

      CRowVector operator+(const CRowVector &) const;
      CRowVector operator-(const CRowVector &) const;
      CRowVector operator%(const CRowVector &) const;
      CRowVector operator/(const CRowVector &) const;
      CRowVector operator*(const CMatrix &) const;
      double operator*(const CColVector &) const;
      CRowVector operator|(const CRowVector &) const;
      CMatrix operator||(const CRowVector &) const;
      CMatrix operator||(const CMatrix &) const;
      CColVector transpose() const;
};


class CColVector : public CVector
{
public:
      CColVector();
      CColVector(int);

      CColVector(const CColVector &rhs) { copy(rhs); }
      CColVector & operator=(const CColVector &);

      CColVector(const CVector &rhs) { copy(rhs); }
      CColVector & operator=(const CVector &);

      CColVector operator+(const CColVector &) const;
      CColVector operator-(const CColVector &) const;
      CColVector operator%(const CColVector &) const;
      CColVector operator/(const CColVector &) const;
      CMatrix operator*(const CRowVector &) const;
      CMatrix operator|(const CColVector &) const;
      CMatrix operator|(const CMatrix &) const;
      CColVector operator||(const CColVector &) const;
      CRowVector transpose() const;
      void display();
};


//////////////////////////////////////
// CMatrix


class CMatrix
{
public:
      CMatrix();
      CMatrix(int, int);
      CMatrix(const CMatrix &rhs) { copy(rhs); }
      CMatrix(const double rhs) 
       	{ setRow(1); setCol(1); d[0].d[0] = rhs; }

      ~CMatrix();

      void setRow(int);
      int getRow() const;
      void setCol(int);
      int getCol() const;

      void copy(const CMatrix & rhs);
      CMatrix & operator = (const CMatrix &);
      CMatrix & operator = (const double);

      CVector & operator [] (const int n)
             { return d[n-1]; }
      CVector operator [] (const int n) const
             { return d[n-1]; }  


      // Matrix Arithmetic

      void add(int n);
      void add(double n);
      void subtract(int n);
      void subtract(double n);
      void multiply(int n);
      void multiply(double n);

      CMatrix negate() const;       // do not modify object
      void negate();                // modify object

      void clear();
      void load(int num, ...);
      void unit(double n = 1.0);

      CVector d2v() const;

      void import(string filename);

      CMatrix operator+(const CMatrix &) const;
      CMatrix operator-(const CMatrix &) const;
      CMatrix operator*(const CMatrix &) const;
      CColVector operator*(const CColVector &) const;
      CMatrix operator&(const CMatrix &) const;

      CMatrix operator|(const CMatrix &) const;
      CMatrix operator||(const CMatrix &) const;
      CMatrix operator|(const CColVector &) const;
      CMatrix operator||(const CRowVector &) const;



      // Display functions
      void display();

      // Matrix Functions
      CMatrix inverse() const;
      double det() const;
      bool singular() const;
      double trace() const;
      CMatrix transpose() const;
      double chisq() const;

      double sumRow(int) const;
      double sumCol(int) const;
      double sum() const;


      vector<CVector> d;
      int row;

private:
      static void ludcmp(CMatrix &a, IntArray &indx, double &d);
      static void lubksb(CMatrix &a, IntArray &indx, CVector &b);

};

//////////////////////////////////////
// CTensor


class CTensor
{
public:
      CTensor();
      CTensor(int, int, int);
      ~CTensor();

      void setRow(int);
      int getRow() const;
      void setCol(int);
      int getCol() const;
      void setDep(int);
      int getDep() const;

      void clear();

      CMatrix & operator [] (const int n)
             { return d[n-1]; }
      CMatrix operator [] (const int n) const
             { return d[n-1]; }  

      vector<CMatrix> d;
      int dep;

};


#endif
