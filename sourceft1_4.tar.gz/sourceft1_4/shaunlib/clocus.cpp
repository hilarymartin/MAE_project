// Implement Locus class

#include <iostream>
#include "clocus.h"

string CLocus::missing = ".";

CLocus::CLocus()
{
   one = two = "0";
}

CLocus::~CLocus()
{
  // nothing
}

