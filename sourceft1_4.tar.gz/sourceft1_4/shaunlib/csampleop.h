#ifndef __CSAMPLEOP_H__
#define __CSAMPLEOP_H__

#include "csample.h"

StringArray recodeSNPs(CSample &);

#endif

