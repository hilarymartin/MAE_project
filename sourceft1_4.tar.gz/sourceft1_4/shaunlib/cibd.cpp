// IBD functions

#include "cibd.h"

CIbd::CIbd(CSLocus *l, CIndividual *i1, CIndividual *i2) 
{
  loc = l;
  ind1 = i1;
  ind2 = i2;

  p0 = p1 = p2 = 0; 
} 


