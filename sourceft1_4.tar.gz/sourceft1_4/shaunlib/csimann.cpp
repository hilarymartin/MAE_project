 #include <iostream>

#include "csimann.h"
#include "cmymath.h"
#include "crandom.h"

template<class T>
inline void SWAP(T &a, T &b)
        {T dum=a; a=b; b=dum;}

CSimAnn::CSimAnn()
{
  setTol(0.00000001);
  setParam(3);
  setMaxIter(5000);
  iter = 0;
  verbose = false;

  maxT = 10;
  Tdecline = 0.8;
  Tcycles = 20;
  Titer = 1000;
}


CSimAnn::CSimAnn(CFunction_ABC *f)
{
  setTol(0.00000001);
  setParam(3);
  myFunction = f;
  setMaxIter(1000);
  iter = 0;

  maxT = 10;
  Tdecline = 0.8;
  Tcycles = 20;
  Titer = 1000;
  verbose = false;
}

void CSimAnn::setStart(CVector &s)
{
  for (int i=1; i<=ndim+1; i++)
    for (int j=1; j<=ndim; j++)
      p[i][j] = s[j];
  //  randomise();
}




void CSimAnn::randomise(int fac)
{
   for (int i=1; i<=ndim+1; i++)
    for (int j=1; j<=ndim; j++)
      p[i][j] += (CRandom::rand()-0.5) / fac ; 
 }


CVector CSimAnn::getEstimates()
{
    return pb;
}


void CSimAnn::optimise()
{

 
    // Load y vector
    for (int i=1; i<=ndim+1; i++)
    {
	for (int j=1; j<=ndim; j++)
	x[j] = p[i][j];
	y[i] = myFunction->func(x);
    }

    // initialise large, and yb will contain best value 
    yb = 9999999;

    tt = maxT;
    
    for (int tc = 1 ; tc <= Tcycles; tc++)
    {
	if (verbose) 
	    cout << "\nSimulated annealing temperature = " << tt << "\n";
	iter = Titer;
	minimise();
	
	tt *= Tdecline;
    }
    
}


void CSimAnn::minimise()
{
    // Temporary variables
    int i,ihi,ilo,j,n;

    double rtol,yhi,ylo,ynhi,ysave,yt,ytry;

    temp = -tt;

    get_psum();

    for (;;) 
    {
	ilo=1;
	ihi=2;
	ynhi=ylo=y[1]+temp*log(CRandom::rand()); // NR ran1()
	yhi=y[2]+temp*log(CRandom::rand());

	if (ylo > yhi)
	{
	    ihi=1;
	    ilo=2;
	    ynhi=yhi;
	    yhi=ylo;
	    ylo=ynhi;
	}

	for (i=3;i<=mpts;i++) 
	{
	    yt=y[i]+temp*log(CRandom::rand());
	    if (yt <= ylo) 
	    {
		ilo=i;
		ylo=yt;
	    }

	    if (yt > yhi) 
	    {
		ynhi=yhi;
		ihi=i;
		yhi=yt;
	    } 
	    else if (yt > ynhi) 
	    {
		ynhi=yt;
	    }
	}
       

	rtol=2.0*fabs(yhi-ylo)/(fabs(yhi)+fabs(ylo));
	
	if (rtol < ftol || iter < 0) 
	{
	    SWAP(y[1],y[ilo]);
	    for (n=1;n<=ndim;n++)
		SWAP(p[1][n],p[ilo][n]);
	    break;
	}
	
	iter -= 2;
	
	ytry=amotsa(ihi,yhi,-1.0);
	
	if (ytry <= ylo) 
	{
	    ytry=amotsa(ihi,yhi,2.0);
	} 
	else if (ytry >= ynhi) 
	{
	    ysave=yhi;
	    ytry=amotsa(ihi,yhi,0.5);
	    if (ytry >= ysave) 
	    {
		for (i=1;i<=mpts;i++) 
		{
		    if (i != ilo) 
		    {
			for (j=1;j<=ndim;j++) 
			{
			    psum[j]=0.5*(p[i][j]+p[ilo][j]);
			    p[i][j]=psum[j];
			}
			y[i]=myFunction->func(psum);
		    }
		}
		iter -= ndim;
		get_psum();
	    }
	} else ++iter;
    }
}



double CSimAnn::amotsa(const int ihi, 
		       double  & yhi, 
		       const double fac)    
{
    int j;
    double fac1,fac2,yflu,ytry;

    fac1=(1.0-fac)/ndim;
    fac2=fac1-fac;

    for (j=1;j<=ndim;j++)
	ptry[j]=psum[j]*fac1-p[ihi][j]*fac2;

    ytry=myFunction->func(ptry);

    if (ytry <= yb) 
    {
	pb = ptry;
	yb = ytry;
    }

    if (verbose)
	cout << "\nYB=" << yb << "\tYTRY="<<ytry 
	     << "\titer="<<iter; 
    
    yflu=ytry-temp*log(CRandom::rand());
    if (yflu < yhi) 
    {
	y[ihi]=ytry;
	yhi=yflu;
	for (j=1;j<=ndim;j++) {
	    psum[j] += ptry[j]-p[ihi][j];
	    p[ihi][j]=ptry[j];
	}
    }
    return yflu;
}




