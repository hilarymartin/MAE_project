// Implement STrait class

#include "ctrait.h"

CQTrait::CQTrait()
{
  mean = sibr = 0;
  var = 1;
  name = "Q-Trait";
  mean_set = var_set = sibr_set = false;
}

CQTrait::~CQTrait()
{
  // nothing
}



CBTrait::CBTrait()
{
  prevalence = 0;
  name = "B-Trait";
  mean_set = prevalence_set = false;
}

CBTrait::~CBTrait()
{
  // nothing 
}

CCovariate::CCovariate()
{
    mean = 0;
    var =  1; 
    sibr = 0;
    mean_set = var_set = sibr_set = false;
}
