// Implementation of MyMath routines

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <math.h>

#include "cmymath.h"
#include "crandom.h"
#include "xtra_dcdflib.h"
#include "xtra_ipmpar.cpp"
#include "error.h"

#define NR_END 1
#define FREE_ARG char*


double mymath::rndnorm() 
{
  double u1 = CRandom::rand();
  double u2 = CRandom::rand();
  return sqrt(-2*log(u1))*cos(2*M_PI*u2);
}

void mymath::permute(vector<int> &a)
{
    // generate random permutation of 0..n-1
    // where n is a.size();

    const int n = a.size( );
    
    for( int i = 0; i < n; i++ )
        a[ i ] = i;
    
    for( int j = 1; j < n; j++ )
    {
        int pos = CRandom::rand(j);
        int tmp = a[ j ];
        a[ j ] = a[ pos ];
        a[ pos ] = tmp;
    }
}

void mymath::permute_this(vector<int> &a)
{
    // permute an existing vector 
    // where n is a.size();

    const int n = a.size( );
    
    for( int j = 1; j < n; j++ )
    {
        int pos = CRandom::rand(j);
        int tmp = a[ j ];
        a[ j ] = a[ pos ];
        a[ pos ] = tmp;
    }
}


////////////////////
// NR data stores

double * mymath::nr_vector(long nl, long nh)
{
  double *v;
  
  v=(double *)malloc((size_t) ((nh-nl+1+NR_END)*sizeof(double)));
  cout << "\nAllocated VAR\n";
  if (!v) error("allocation failure in vector()");
  return v-nl+NR_END;
}
  
void mymath::free_nr_vector(double *v, long nl, long nh)
{
  free((FREE_ARG) (v+nl-NR_END));
}


double *** mymath::nr_3tensor(long nrl, long nrh, long ncl, long nch, long ndl, long ndh)
/* allocate a float 3tensor with range t[nrl..nrh][ncl..nch][ndl..ndh] */
{
	long i,j,nrow=nrh-nrl+1,ncol=nch-ncl+1,ndep=ndh-ndl+1;
	double ***t;

	/* allocate pointers to pointers to rows */
	t=(double ***) malloc((size_t)((nrow+NR_END)*sizeof(double**)));
	if (!t) error("allocation failure 1 in f3tensor()");
	t += NR_END;
	t -= nrl;

	/* allocate pointers to rows and set pointers to them */
	t[nrl]=(double **) malloc((size_t)((nrow*ncol+NR_END)*sizeof(double*)));
	if (!t[nrl]) error("allocation failure 2 in f3tensor()");
	t[nrl] += NR_END;
	t[nrl] -= ncl;

	/* allocate rows and set pointers to them */
	t[nrl][ncl]=(double *) malloc((size_t)((nrow*ncol*ndep+NR_END)*sizeof(double)));
	if (!t[nrl][ncl]) error("allocation failure 3 in f3tensor()");
	t[nrl][ncl] += NR_END;
	t[nrl][ncl] -= ndl;

	for(j=ncl+1;j<=nch;j++) t[nrl][j]=t[nrl][j-1]+ndep;
	for(i=nrl+1;i<=nrh;i++) {
		t[i]=t[i-1]+ncol;
		t[i][ncl]=t[i-1][ncl]+ncol*ndep;
		for(j=ncl+1;j<=nch;j++) t[i][j]=t[i][j-1]+ndep;
	}

	/* return pointer to array of pointers to rows */
	return t;
}

#ifdef __USE_GMP__

mpf_class *** mymath::mp_3tensor(long nrl, long nrh, long ncl, long nch, long ndl, long ndh)
/* allocate a float 3tensor with range t[nrl..nrh][ncl..nch][ndl..ndh] */
{
	long i,j,nrow=nrh-nrl+1,ncol=nch-ncl+1,ndep=ndh-ndl+1;
	mpf_class ***t;

	/* allocate pointers to pointers to rows */
	t=(mpf_class ***) malloc((size_t)((nrow+NR_END)*sizeof(mpf_class**)));
	if (!t) error("allocation failure 1 in f3tensor()");
	t += NR_END;
	t -= nrl;

	/* allocate pointers to rows and set pointers to them */
	t[nrl]=(mpf_class **) malloc((size_t)((nrow*ncol+NR_END)*sizeof(mpf_class*)));
	if (!t[nrl]) error("allocation failure 2 in f3tensor()");
	t[nrl] += NR_END;
	t[nrl] -= ncl;

	/* allocate rows and set pointers to them */
	t[nrl][ncl]=(mpf_class *) malloc((size_t)((nrow*ncol*ndep+NR_END)*sizeof(mpf_class)));
	if (!t[nrl][ncl]) error("allocation failure 3 in f3tensor()");
	t[nrl][ncl] += NR_END;
	t[nrl][ncl] -= ndl;

	for(j=ncl+1;j<=nch;j++) t[nrl][j]=t[nrl][j-1]+ndep;
	for(i=nrl+1;i<=nrh;i++) {
		t[i]=t[i-1]+ncol;
		t[i][ncl]=t[i-1][ncl]+ncol*ndep;
		for(j=ncl+1;j<=nch;j++) t[i][j]=t[i][j-1]+ndep;
	}

	/* return pointer to array of pointers to rows */
	return t;
}

void mymath::free_mp_3tensor(mpf_class ***t, long nrl, long nrh, long ncl, long nch,
	long ndl, long ndh)
/* free a float f3tensor allocated by f3tensor() */
{
	free((FREE_ARG) (t[nrl][ncl]+ndl-NR_END));
	free((FREE_ARG) (t[nrl]+ncl-NR_END));
	free((FREE_ARG) (t+nrl-NR_END));
}

#endif


int *** mymath::nr_i3tensor(long nrl, long nrh, long ncl, long nch, long ndl, long ndh)
/* allocate a int 3tensor with range t[nrl..nrh][ncl..nch][ndl..ndh] */
{
	long i,j,nrow=nrh-nrl+1,ncol=nch-ncl+1,ndep=ndh-ndl+1;
	int ***t;

	/* allocate pointers to pointers to rows */
	t=(int ***) malloc((size_t)((nrow+NR_END)*sizeof(int**)));
	if (!t) error("allocation failure 1 in i3tensor()");
	t += NR_END;
	t -= nrl;

	/* allocate pointers to rows and set pointers to them */
	t[nrl]=(int **) malloc((size_t)((nrow*ncol+NR_END)*sizeof(int*)));
	if (!t[nrl]) error("allocation failure 2 in i3tensor()");
	t[nrl] += NR_END;
	t[nrl] -= ncl;

	/* allocate rows and set pointers to them */
	t[nrl][ncl]=(int *) malloc((size_t)((nrow*ncol*ndep+NR_END)*sizeof(int)));
	if (!t[nrl][ncl]) error("allocation failure 3 in i3tensor()");
	t[nrl][ncl] += NR_END;
	t[nrl][ncl] -= ndl;

	for(j=ncl+1;j<=nch;j++) t[nrl][j]=t[nrl][j-1]+ndep;
	for(i=nrl+1;i<=nrh;i++) {
		t[i]=t[i-1]+ncol;
		t[i][ncl]=t[i-1][ncl]+ncol*ndep;
		for(j=ncl+1;j<=nch;j++) t[i][j]=t[i][j-1]+ndep;
	}

	/* return pointer to array of pointers to rows */
	return t;
}


void mymath::free_nr_3tensor(double ***t, long nrl, long nrh, long ncl, long nch,
	long ndl, long ndh)
/* free a float f3tensor allocated by f3tensor() */
{
	free((FREE_ARG) (t[nrl][ncl]+ndl-NR_END));
	free((FREE_ARG) (t[nrl]+ncl-NR_END));
	free((FREE_ARG) (t+nrl-NR_END));
}





void mymath::free_nr_i3tensor(int ***t, long nrl, long nrh, long ncl, long nch,
	long ndl, long ndh)
/* free a int i3tensor allocated by i3tensor() */
{
	free((FREE_ARG) (t[nrl][ncl]+ndl-NR_END));
	free((FREE_ARG) (t[nrl]+ncl-NR_END));
	free((FREE_ARG) (t+nrl-NR_END));
}


double mymath::sqr(double z) { return z*z; }

long double mymath::normden(CColVector &scr, CColVector &mean, CMatrix &var)
{
  int n = mean.getCol();
  long double pdf = pow(2*M_PI,-(double)n/2) * pow(var.det(),-0.5);
  pdf *= exp(-(  (scr-mean).transpose() * var.inverse() * (scr-mean) )/2);
  return pdf;
}


long double mymath::normden(double scr, double mean, double var)
{
  long double pdf = (1/ sqrt(2*M_PI*var)) * exp( - ( sqr(scr-mean) / (2*var) ) ) ;
  return pdf;
}


long double mymath::normdist(double z)
{
 double sqrt2pi = 2.50662827463;
 long double t0, z1, p0 ;
 t0 = 1 / (1 + 0.2316419 * fabs(z));
 z1 = exp(-0.5 * z*z ) / sqrt2pi;
 p0 = z1 * t0
    * (0.31938153 +
    t0 * (-0.356563782 +
    t0 * (1.781477937 +
    t0 * (-1.821255978 +
    1.330274429 * t0))));
 return z >= 0 ? 1 - p0 : p0 ;
}

double mymath::pdf_power(double alpha, double df, double l)
{
  double x = 0; // X value
  int st=0; // which and status variables
  double bnd; // boundary(s)? - seemingly no effect!

  // *** Inverse chi-squared distribution
  int w=2; // calculate X given P and DF
  double q = alpha; double p = 1-q; bnd=1;
  cdfchi(&w,&p,&q,&x,&df,&st,&bnd);

  // *** Non-central chi-squared distribution
  w=1; bnd=0; // Calculate P given X, DF, L
  q=alpha; p=1-q; // values for p and q are corrupted from previous call
  cdfchn(&w,&p,&q,&x,&df,&l,&st,&bnd);
  return 1-p;
}

double mymath::pdf_sample(double alpha, double df, double ncp, double power)
{
  double x = 0;
  int st =0;
  double bnd;
  double l = 0;

  // Inverse chi-squared distribution 
  // to get critical value, given df and alpha
  int w=2;
  double q = alpha; double p = 1-q; bnd=1;
  cdfchi(&w,&p,&q,&x,&df,&st,&bnd);

  // *** Non-central chi-squared distribution
  w=4; bnd=0; // Calculate P given X, DF, L
  double qpower = 1 - power;
  cdfchn(&w,&power,&qpower,&x,&df,&l,&st,&bnd);
  return l/ncp;
}

double mymath::mean(const CColVector& d) 
{
  double m = 0;
  for (int i=1; i<=d.getCol(); i++)
    m += d[i];
  return m/(float)d.getCol();
}

double mymath::variance(const CColVector& d) 
{
  double m = mean(d);
  double sumsq = 0;
  for (int i=1 ; i <= d.getCol() ; i++)
    sumsq += mymath::sqr(d[i]-m);
  return sumsq/float(d.getCol()-1);
}

double mymath::stdev(const CColVector& d) 
   { return sqrt(variance(d)); }

double mymath::covariance(const CColVector& d1, const CColVector& d2) 
{
  if (d1.getCol() != d2.getCol()) error("Covariance: vectors have unequal N");

  double mean1 = mean(d1);
  double mean2 = mean(d2);
  double cp = 0;
  for (int i=1 ; i <= d1.getCol() ; i++)
    cp += (d1[i]-mean1) * (d2[i]-mean2);
  return cp/float(d1.getCol()-1);
  
}

double mymath::correlation(const CColVector& v1, const CColVector& v2) 
   { return covariance(v1,v2)/(sqrt(variance(v1)*variance(v2))); }


// **********************************************
// *** Non-central chi-squared distribution 
// *** Calculate P given x,l,df
// **********************************************
double mymath::nchi(double x, double df, double ncp)
{
  double p, q;
  int st = 0; // error variable
  int w = 1; // function variable
  double bnd = 1; // boundary function
  cdfchn(&w,&p,&q,&x,&df,&ncp,&st,&bnd);
  return q;
}  

// **********************************************
// *** Non-central chi-squared distribution 
// *** Calculate X given p,df,l
// **********************************************
double mymath::invnchi(double q, double df, double ncp)
{
  double p=1-q;
  double x = 0;
  int w = 2;
  double bnd = 1;
  int st = 0;
  cdfchn(&w,&p,&q,&x,&df,&ncp,&st,&bnd);
  return x;
}

// **********************************************
// *** Non-central chi-squared distribution 
// *** Calculate l given p,x,df
// **********************************************
double mymath::ncpnchi(double q, double df, double x)
{
  double p=1-q;
  double ncp = 0;
  int w = 4;
  double bnd = 1;
  int st = 0;
  cdfchn(&w,&p,&q,&x,&df,&ncp,&st,&bnd);
  return ncp;
}   

// **********************************************
// *** Normal Distribution Distribution
// *** Calculate P given X, MEAN, SD
// **********************************************
double mymath::norm(double x, double mean, double sd)
{
  double p,q;
  int w = 1;
  double bnd = 1;
  int st = 0;
  cdfnor(&w,&p,&q,&x,&mean,&sd,&st,&bnd);
  return q;
}

// **********************************************
// *** Normal Distribution Distribution
// *** Calculate X given P, MEAN, SD
// **********************************************
double mymath::invnorm(double q, double mean, double sd)
{
  double x = 0;
  double p=1-q;
  int w = 2;
  double bnd = 1;
  int st = 0;
  cdfnor(&w,&p,&q,&x,&mean,&sd,&st,&bnd);
  return x;
}

// **********************************************
// *** Function to aid testing linear 
// *** hypotheses after estimating of a
// *** regression
// **********************************************

double mymath::linear_hypothesis(CColVector &b, CMatrix &v, CMatrix &H, CColVector &h)
{
  return ( H*b - h ).transpose() 
    * ( H*v*H.transpose() ).inverse()
    * ( H*b - h ) ;
}



long unsigned int mymath::factorial(int n)
{
  long unsigned int z = 1;
  for (int i = 1 ; i <= n ; i++)
    z *= i; 
  return z;
}

long unsigned int mymath::combin(int n, int k)
{
  if (k>n) return 0;
  long double z = 1;
  int r = k;
  if ( k > (n-k) ) r = n-k;
  for (int i = 0 ; i <= r-1 ; i++)
    z *= (long double)(n-i) / (long double)(r-i);
  return (long unsigned int)z;
}



#ifdef __USE_GMP__

// GMP++ functions to calculate log
// John A. Kassebaum <JKassebaum@OpenGlobe.Net>

typedef mpf_class Float;

	// ==========================================
	//
	// Natural Logarithm (Base 'e' logarithm)
	//
	// ==========================================

//	#define LN_MAXITERS 10000

	Float mymath::mpf_log ( const Float& X )
	{

	#define LN_MAXITERS 10000

     	    Float        last;
     	    Float        rtn;
	    unsigned long   i;
	    unsigned long   precision;
	    Float        term;
	    Float        factor;
	    Float        term_k;
	    long            sign;

	    precision =  2* X.get_prec();
//original: precision =  2*  X.getPrecision();
	    
     	    if ( X > Float(0.5) ){
	    	term    = 1.0 - ( 1.0 / X );
		factor  = 1.0;
		term_k  = term;

		rtn     = term_k / factor;

		last    = rtn;
		term_k  = term_k * term;
		factor  = Float( 2.0 );
		rtn    += (term_k / factor);

//original:	for( i = 3; !epsilon_equivalent( rtn, last, precision ) && (i < LN_MAXITERS); i++ ){
		for( i = 3; !mpf_eq( rtn.get_mpf_t(), last.get_mpf_t(), precision ) && (i < LN_MAXITERS); i++ ){
		    last    = rtn;
		    term_k  = term_k * term;
		    factor  = Float( (double) i );
		    rtn    += (term_k / factor);
		}
	    } else if ( X > Float(0.0) ){
	    	term    = X - 1.0;
		factor  = 1.0;
		term_k  = term;

		sign    = 1;
		rtn     = sign * term_k / factor;

		last    = rtn;
		sign    = sign * -1;
		term_k  = term_k * term;
		factor  = Float( 2.0 );
		rtn    += (sign * term_k / factor);

//original:     for( i = 3; !epsilon_equivalent( rtn, last, precision ) && (i < LN_MAXITERS) ; i++ ){
		for( i = 3; !mpf_eq( rtn.get_mpf_t(), last.get_mpf_t(), precision ) && (i < LN_MAXITERS); i++ ){
		    last    = rtn;
		    sign    = sign * -1;
		    term_k  = term_k * term;
		    factor  = Float( (double) i );
		    rtn    += (sign * term_k / factor);
		}
	    } else {
	    	// Natural Logarithm undefined - 0 or negative argument
		// NOTE - Should Throw and Exception Here!
		rtn = Float(0.0);
	    }

	    return rtn;
	};

	// ==========================================
	//
	// Logarithm with Base ( default: comon logarithm - base 10 )
	//
	// ==========================================

	Float mymath::mpf_log ( const Float& aFloat, const Float& base )
	{
     	    if( base > Float( 0.0 ) )
         	return ( mymath::mpf_log( aFloat ) / mymath::mpf_log ( base ) );
	    else
	    	return Float( 0.0 );  // Base must be positive and not zero!
		                      // NOTE - Should Throw and Exception Here!
	};


#endif
