#ifndef __CHAPLOTYPE_H__
#define __CHAPLOTYPE_H__

#include <iostream>
#include <vector>
#include "misc.h"
#include "cmatrix.h"

class CHaplotype
{
public:
    CHaplotype()
	{ length(0); } 

    CHaplotype(int n_)
	{ length(n_); } 

    // Copy constructor
    CHaplotype(const CHaplotype& h1)
	{
	    copy(h1);
	}

    CHaplotype & operator= (const CHaplotype & h1)
	{
	    copy(h1); return *this;
	}
    
    void CHaplotype::copy(const CHaplotype &h1)
	{
	    length(h1.length());
	    for (int i=1; i<=n; i++)
		pos(i) = h1.pos(i);
	}

    // Set number of loci
    void length(int n_) 
	{ n=n_; 
	  pos().resize(n); 
	}

    // Get number of loci
    int length() const
	{ return n; } 

    // less than operator (for use with associative array)
    bool operator< (const CHaplotype & h1) const
	{
	    for (int i=1; i<=n; i++)
	    {
		if ( pos(i) < h1.pos(i) ) return true;  // less than
		if ( pos(i) > h1.pos(i) ) return false; // greater than
	    }
	    return false; // equal to
	}

    bool operator== (const CHaplotype & h1) const
	{
	    for (int i=1; i<=n; i++)
		if ( pos(i) != h1.pos(i) ) return false;
	    return true;
	}

    void display() const
	{
	    for (int i=1; i<=n; i++)
		cout << pos(i);
	}


    // Data members

    // Haplotype position
    StringArray pos;

    // Number of loci in haplotype
    int n;


};

class CPhase
{
public:
    CPhase(int n=0);
    CPhase(CHaplotype pat, CHaplotype mat, double prob=0);

    CHaplotype paternal;
    CHaplotype maternal;    

    double prob;
    long double probGivenParents(CPhase & , CPhase &, CMatrix &, int );

};

#endif
