#ifndef __OPT2_H__
#define __OPT2_H__

#include "cmatrix.h"
#include "error.h"
#include "cdata.h"
#include "cfunction.h"


class COpt
{
 public:
  COpt();
  COpt(CFunction_ABC *);

  void setTol(double tol) 
    { ftol = tol; }

  void setParam(int n)
    { ndim = n; 
      x.setCol(n); 
      y.setCol(n+1); 
      p.setRow(n+1); 
      p.setCol(n); 
      psum.setCol(n); 
      ptry.setCol(n); }
  int getParam()
    { return ndim; }

  void setStart(CVector &);

  void setMaxIter(int n)
    { NMAX = n; }
  int getIter()
    { return iter; }
  
  void randomise(int fac = 10);
  void optimise();
  CVector getEstimates();
  double getLikelihood()
    { return y[1]; }
  bool verbose;

  CFunction_ABC *myFunction; 

 private:
   
   double ftol;
   int ndim;
   int iter;
   int NMAX;

   CMatrix p;
   CVector x;
   CVector y;
   CVector psum;
   CVector ptry;

   double amotry(int ihi, double fac);

};


#endif

