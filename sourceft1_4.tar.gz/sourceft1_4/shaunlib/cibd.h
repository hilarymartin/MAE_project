#ifndef __CIBD_H__
#define __CIBD_H__

#include "cslocus.h"
#include "cindividual.h"

class CIbd
{
 public:
  
  CIbd(CSLocus *, CIndividual *, CIndividual *);
  
  CSLocus * loc; 
  CIndividual * ind1;
  CIndividual * ind2;
  
  double p0, p1, p2;
};

#endif
