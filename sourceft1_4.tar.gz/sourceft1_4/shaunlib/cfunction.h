#ifndef __CFUNCTION_H__
#define __CFUNCTION_H__

#include "cmatrix.h"

// abstract base class for user-defined functions for CSimplex2
class CFunction_ABC {
 public:  
    
    // Function to be defined by user   
    virtual double func(CVector&) = 0;

    // Derivative of function numerically calculated
    void deriv(CVector& x, CVector& d, double h);
    
    // Hessian matrix of function
    CMatrix hessian(CVector p,double d);

    // Virtual destructor
    virtual ~CFunction_ABC() { } 
};


#endif
