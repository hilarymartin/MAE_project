#include <iostream>
#include <fstream>
#include "cdata.h"
#include "error.h"

string CData::missing=".";

CData::CData()
{
  field_delimit(" ,\t");
  line_delimit("\n");
  header = false;
  setInd(0);
  setVar(0);
}

CData::CData(int i, int v)
{
  field_delimit(" ,\t");
  line_delimit("\n");
  header = false;
  setInd(i);
  setVar(v);
}

CData::~CData()
{ 
 //
}

void CData::setInd(int i)
  { row = i; d.resize(i); filter().resize(i); setVar(getVar()); }

int CData::getInd() const
{ return row; }

int CData::getVar() const
{ return row > 0 ? (*this)[1].getCol() : 0 ; }

void CData::setVar(int v)
{
     for (int i=1; i <= row; i++)
         (*this)[i].setCol(v);
     varname().resize(v);
     filter_var().resize(v);
}


void CData::display()
{
  //  cout << "\nDataset : " << name << "\n";
  cout << "\tF";
  for (int j=1; j<=getVar(); j++ )
    cout << "\t" << varname(j);
  
  for (int i=1; i <= row; i++)
  {
    cout << "\nInd " << i << "\t";
    if (!filter(i)) cout << "X";

    for (int j=1; j <= (*this)[i].getCol(); j++)
      cout << "\t" << (*this)[i][j];
  }
  cout << "\n";
}

 
void CData::import(string filename) 
{

  ifstream in;
  in.open(filename.c_str());
  
  char c;
  string c1, s;

  bool hasdata1 = false;
  bool hasdata2 = false;
  bool err = false;

  int i=0;          // individual count
  int v=0;          // variable count
  int max_v = 0;    // max variable count

  vector<string> st;
  
  while(in.get(c))
    {

      c1 = c;
      
// cout << "\n[" << c1 << "]";

      if (fd.find(c1)<c1.npos && hasdata1) 
	{
	  v++;
	  // cout << "\nNF = " << v;
	  st.push_back(s);
	  s = "";
	  hasdata1 = false;
	}
      else if (ld.find(c1)<c1.npos && hasdata2)
	{
	  if (hasdata1) 
	    { 
	      v++;
	      st.push_back(s);
	      s="";
	      hasdata1 = false;
	      // cout << "\nNF = " << v;
	    }

          i++;
	  // cout << "\nNR = " << i;
	  if (i > 1 && v != max_v) {cout << "\nERROR\n"; err = true;}
	  max_v = v;
	  v = 0;
	  hasdata2 = false;
	}
      else if (fd.find(c1)==c1.npos && ld.find(c1)==c1.npos)
	    { 
	      hasdata1 = hasdata2 = true;
	      s += c1;
	    }
      else 
	{
	  s = "";
	}
    }

  // need to add one more variable if EOF replaced last fd/ld
  if (hasdata2) 
    { 
      if (hasdata1)
	{
	  st.push_back(s);
	  v++;
	  // cout << "\nNF = " << v;
	  if (v != max_v) err = true;
	}  
      i++;
      // cout << "\nNR = " << i;
    }

  in.close();

  v = max_v;
  if (err) error(filename+" contains unequal lines.");

  if (header) setInd(i-1); else setInd(i);
  setVar(v);

  if (header) for (int i1 = 0 ; i1 < getVar() ; i1 ++ ) 
    varname(i1+1) = st[i1];
  
  int count;
  if (header) count = v; else count = 0; 

  for (int i1 = 1 ; i1 <= getInd() ; i1++)
    for (int j = 1 ; j <= getVar() ; j++)
      (*this)[i1][j] = atof(st[count++].c_str());
  
}


void CData::write(string filename)
{
  ofstream out;
  out.open(filename.c_str());
  
  if (header)
      for (int j=1; j<=getVar(); j++ )
	  out << "\t" << varname(j);
  
  
  for (int i=1; i <= row; i++)
  {
      if (filter(i))
	  for (int j=1; j <= (*this)[i].getCol(); j++)
	      if (filter_var(j))
		  out << "\t" << (*this)[i][j];
      
      out << "\n";
  }
  
  out.close();
}



CMatrix CData::extractMatrix(int r1, int c1, int r2, int c2)
{
  if (r2<r1 || c2<c1) error("Matrix not properly specified");
  CMatrix n(r2-r1+1,c2-c1+1);

  // 0-n subscripts for CData
  // 1-n subscripts for CMatrix
  for (int i=r1 ; i<=r2 ; i++)
    for (int j=c1 ; j<=c2 ; j++)
      n[i-r1+1][j-c1+1]  = (*this)[i][j];
  
  return n;
}

CRowVector CData::extractInd(int i)
{
  CRowVector n(getVar());
  for (int j=1 ; j <= getVar() ; j++)
      n[j]  = (*this)[i][j];
  return n;
}

CColVector CData::extractVar(int j)
{
  CColVector n(getInd());
  for (int i=1 ; i <= getInd() ; i++)
      n[i]  = (*this)[i][j];
  return n;
}

CColVector CData::extractVarIf(int j)
{
  vector<double> n;
  for (int i=1 ; i <= getInd() ; i++)
      if (filter(i)) n.push_back((*this)[i][j]);
  CColVector n2(n.size());
  for (int i=0 ; i < n.size() ; i++)
    n2[i+1] = n[i];
  return n2;
}

void CData::include_all()
   { for (int i=1 ; i <= getInd() ; i++) filter(i) = true; }

void CData::exclude_all()
   { for (int i=1 ; i <= getInd() ; i++) filter(i) = false; }

void CData::include(int n)
   { filter(n) = true; }

void CData::exclude(int n)
   { filter(n) = false; } 



void CData::include_all_var()
   { for (int i=1 ; i <= getVar() ; i++) filter_var(i) = true; }

void CData::exclude_all_var()
   { for (int i=1 ; i <= getVar() ; i++) filter_var(i) = false; }

void CData::include_var(int n)
   { filter_var(n) = true; }

void CData::exclude_var(int n)
   { filter_var(n) = false; } 
