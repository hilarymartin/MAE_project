#ifndef __MISC_H__
#define __MISC_H__

#include <string>
#include <vector>

using namespace std;

class CArgs
{
 public:
  CArgs(int,char**);
  
  int count()
    { return n; }
  
  bool any()
    { return n > 1 ? true : false; }

  bool find(string);
  string value(string);

  vector<string> a;

 private:
  int n;

};

class IntArray
{ 
 public: 
  int & operator() (const int n)
    { return store[n-1]; }
  int operator() (const int n) const
    { return store[n-1]; }

  void setCol(const int n) 
    { store.resize(n); }

  vector<int> & operator()() 
    { return store; }
  vector<int> operator()() const 
    { return store; }
 private:  
  vector<int> store;
}; 


class IntMatrix
{ 
 public: 

  IntMatrix() 
    { r = c = 0; }

  IntArray & operator() (const int n)
    { return store[n-1]; }

  IntArray operator() (const int n) const
    { return store[n-1]; }

  void setRow(const int n) 
    { 
      r = n;
      store.resize(r);
      (*this).setCol(c);
    }

  void setCol(const int n)
    { 
      c = n;
      for (int i = 0 ; i < r ; i++)
	store[i].setCol(c);
    }

 private:  
  vector<IntArray> store;
  int r,c;
}; 





class StringArray
{ 
 public: 
  string & operator() (const int n)
    { return store[n-1]; }
  string operator() (const int n) const
    { return store[n-1]; }
  vector<string> & operator()() 
    { return store; }
  vector<string> operator()() const 
    { return store; }
 private:  
  vector<string> store;
}; 


class BoolArray
{ 
 public: 
  char & operator() (const int n)
    { return store[n-1]; }
  char operator() (const int n) const
    { return store[n-1]; }
  vector<char> & operator()() 
    { return store; }
  vector<char> operator()() const 
    { return store; }
 private:  
  vector<char> store;
}; 


std::string int2str(int n);

unsigned long graycode(const unsigned long n, const int is);

string uniqname(string);

void checkFileExists(string);

#endif
