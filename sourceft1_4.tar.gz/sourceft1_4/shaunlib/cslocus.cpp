 // Implement SLocus class

#include "cslocus.h"

CSLocus::CSLocus(int id_)
{
    countAllele = 0;
    allele_.resize(0);
    freqAllele.resize(0);
    name = "Locus";
    usat = false;
}

CSLocus::~CSLocus()
{
  // nothing
}

void CSLocus::setAllele(int n)
{
   countAllele = n;
   allele_.resize(n);
   freqAllele.resize(n);
   // need to check what happens with allele freqs?
}

void CSLocus::addAllele(string code, double freq)
{
   countAllele++;
   allele_.push_back(code);
   freqAllele.push_back(freq);
   // need to check what happens with allele freqs?
}

int CSLocus::countAlleles()
{
  return allele_.size();
}

