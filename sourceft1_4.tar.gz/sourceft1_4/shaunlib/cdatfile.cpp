#include "cdatfile.h"
#include <fstream>
#include <string>
#include <cstdlib>
#include <cstdio>

CDatfile::CDatfile()
{
 token1 = token2 = "";
 type.resize(0);
 name.resize(0);
}

CDatfile::~CDatfile()
{
// 
}

bool CDatfile::readDatfile(string filename)
{

     ifstream in;
     in.open(filename.c_str());

     vector< vector<string> > entries;

     while(!in.eof())
     {
	 // read a line
	 char buf[100];
	 in.getline(buf,100,'\n');

	 // output to temp
	 ofstream out2;
	 string filename2 = uniqname(".DAT");
	 out2.open(filename2.c_str());
	 out2 << buf;
	 out2.close();

	 // read from temp
	 ifstream in2;
	 vector<string> words;

	 in2.open(filename2.c_str());

	 while (!in2.eof())
	 {
	     string word ;
	     in2 >> word;
	     if (word != "") words.push_back(word);

	 }	    
	 in2.close();
	 entries.push_back(words);
	 remove(filename2.c_str());
     }
     in.close();
     

     
     // Process entries
     
     // T : name mean var sibr
     // B : name prevalence
     // A : name prevalence
     // C : name mean var sibr
     // M : name allelefreq...
     // U : name number of alleles (usat to downcode to SNPs)
     // S : skip marker (two cols)
     // X : skip trait  (one col)

     for (int i=0; i < entries.size() ; i++)
     {
	 if (entries[i].size() == 0) break;
	 vector<string> line = entries[i];
	 token1 = line[0]; // type
	 token2 = line[1]; // name
	 
	 vector<string> extra;
	 for (int j=2; j < line.size(); j++)
	     extra.push_back(line[j]);

	 // Does type include a number?
	 if (token1.length()>1)
	 {
	     string temp = token1.substr(1,token1.length());
	     int n = atoi(temp.c_str());
	     for (int i = 0; i < n ; i++)
	     {
		 type.push_back(token1.substr(0,1));
		 name.push_back(token2);
		 data.push_back(extra);
	     }
	 }
	 else
	 {
	     type.push_back(token1);
	     name.push_back(token2);
	     data.push_back(extra);
	 }
     }
     
     
}


