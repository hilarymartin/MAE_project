#include "chaplotype.h"
#include <cmath>
#include <iostream>

CPhase::CPhase(int n)
{
    paternal.length(n);
    maternal.length(n);
}

CPhase::CPhase(CHaplotype pat, CHaplotype mat, double prob_)
{
    paternal = pat;
    maternal = mat;
    prob = prob_;
}

long double CPhase::probGivenParents(CPhase & dad, CPhase & mum, CMatrix & theta, int mr)
{

    // if # recombinations allowed = 0 perform a quick test
    // otherwise, if # recombinations (mr) >= 1, we have to consider all IV

    // get length 
    int n = paternal.n;
    int niv = int(pow(2.0,n));
    vector < vector<bool> > iv;    

    if (mr==0)
    {
	niv = 2;
	vector<bool> t(n);
	
	for (int i=0; i < n; i++)
	    t[i] = false;
	iv.push_back(t);
	
	for (int i=0; i < n; i++)
	    t[i] = true;
	iv.push_back(t);
	
    }
    else
    {
	
	// construct all 2^n possible inheritance vectors
        
	for (int i = 0 ; i < niv ; i++)
	{
	    int gc = graycode(i,n);
	    
	    vector<bool> t(n);
	    iv.push_back(t);
	    
	    // each position
	    for (int p = 0; p < n; p++)
		if (gc & int(pow(2.0,p))) 
		    iv[i][p] = true;
		else
		    iv[i][p] = false;  		
	}
    }

    double total_prob = 0;
    
    // consider each IV 
    for (int iv_pat = 0 ; iv_pat < niv ; iv_pat++)
	for (int iv_mat = 0 ; iv_mat < niv ; iv_mat++)
	{
	    
	    // Is this IV consistent with max allowed recombinations?
	    int pat_r = 0;
	    int mat_r = 0;
	    for (int p=1; p<n; p++)
	    {
		if (iv[iv_pat][p] != iv[iv_pat][p-1]) pat_r++;
		if (iv[iv_mat][p] != iv[iv_mat][p-1]) mat_r++;
	    }
	    
	    // skip if exceeds recombination limit
	    if (pat_r > mr || mat_r > mr) continue;
	    
	    // Is this IV consistent with observed offspring haplotype?
	    CPhase implied(n);
	    
	    for (int p = 1 ; p <= n ; p++)
	    {
		// implied offspring genotype
		
		if (iv[iv_pat][p-1])
		    implied.paternal.pos(p) = dad.paternal.pos(p);
		else
		    implied.paternal.pos(p) = dad.maternal.pos(p);
		
		
		if (iv[iv_mat][p-1])
		    implied.maternal.pos(p) = mum.paternal.pos(p);
		else
		    implied.maternal.pos(p) = mum.maternal.pos(p);
	    }
	    
	    bool match = true;
	    for (int p = 1 ; p <= n ; p++) 
	    {
		if (implied.paternal.pos(p) != paternal.pos(p)) match = false;
		if (implied.maternal.pos(p) != maternal.pos(p)) match = false;
	    }
	    
	    // Calculate probability of child haplotype given parental haplotypes
	    
	    double prob_pat = 0.5;
	    double prob_mat = 0.5;
	    
	    for (int p = 1 ; p < n ; p++)
	    {
		// No transition
		if (iv[iv_pat][p-1] == iv[iv_pat][(p+1)-1]) 
		    prob_pat *= 1 - theta[p][p+1];
		else // Transition
		    prob_pat *= theta[p][p+1];
		
		// No transition
		if (iv[iv_mat][p-1] == iv[iv_mat][(p+1)-1]) 
		    prob_mat *= 1 - theta[p][p+1];
		else // Transition
		    prob_mat *= theta[p][p+1];
		
	    }
	    
	    double prob_child = prob_pat * prob_mat;
	    if (match) total_prob += prob_child;
	    
	}
    
    return total_prob;
    
}



