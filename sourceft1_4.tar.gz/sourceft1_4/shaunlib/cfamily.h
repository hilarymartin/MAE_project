#ifndef __CFAMILY_H__
#define __CFAMILY_H__

#include "cindividual.h"
#include "cmatrix.h"
#include "cslocus.h"

class CIndividual;
class CSample;

class CFamily
{
 public:

      CFamily(CSample *); 
      ~CFamily(); 

      void setID(string s) { id = s; }
      string getID() { return id; }
      int nInFamily() const { return nInFamily_; }
      void nInFamily(const int n) { nInFamily_ = n; }

      void assignToFamily(CIndividual*, string fcode);

      CIndividual & getChildFromTrio();

      CIndividual * proband; 

      CIndividual * ind(const int n) const
	{ return ind_[n-1]; }
 
      
      // Calculate E(pi)
      CMatrix genrel(bool all = true) const;

      // Return IBD matrices for family
      CMatrix p0(CSLocus *, bool all = true) const;
      CMatrix p1(CSLocus *, bool all = true) const; 
      CMatrix p2(CSLocus *, bool all = true) const;
      CMatrix pihat(CSLocus *, bool all = true) const;

      CMatrix observed(const CMatrix &) const;


 private:

      string                  id;
      int                     nInFamily_;
      vector<CIndividual*>    ind_;

};

#endif
