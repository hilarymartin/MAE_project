#ifndef __CDATFILE_H__
#define __CDATFILE_H__

#include "cindividual.h"

class CIndividual;
class CSample;

class CDatfile
{
 public:

      CDatfile(); 
      ~CDatfile(); 

      bool readDatfile(string);

      string                 token1;
      string                 token2;

      vector<string>                   type;
      vector<string>                   name;
      vector< vector<string> >         data;

};

#endif

