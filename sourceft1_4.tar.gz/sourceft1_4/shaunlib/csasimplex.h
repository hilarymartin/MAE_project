#ifndef __CSASIMPLEX_H__
#define __CSASIMPLEX_H__

#include "cfunction.h"
#include "cmatrix.h"

class CSASimplex 
{
 public:

    CSASimplex(CFunction_ABC *);
    
    void setParam(int n)
	{ 
	    nparam = n; 
	    start.setCol(n); 
	}

    void setStart(CVector s)
	{
	    start = s;
	}

    void setSimplexRandFactor(int r)
	{ simplex_rand_factor = r; } 

    void setSARandFactor(int r)
	{ sa_rand_factor = r; } 

    void setSimplexTol(double r)
	{ simplex_tol = r; } 

    void setSATol(double r)
	{ sa_tol = r; } 


    void setSimplexMaxIter(int r)
	{ simplex_mxiter = r; } 

    void setSAMaxIter(int r)
	{ sa_mxiter = r; } 


    void setSATemp(double r)
	{ sa_temp = r; } 

    void setSACycle(int r)
	{ sa_cycle = r; } 

    void setSADecline(double r)
	{ sa_decline = r; } 
    
    void setTryHard(int th_)
	{ th = th_; }

    void minimise();
    
    double getLikelihood()
	{ return obest; } 

    CVector getEstimates()
	{ return pbest; } 
    
    bool verbose;
    bool semiverbose;

 private:

    // Number of times to repeat SA-simplex loop
    int th;

    CFunction_ABC * userFunction;
    
    int nparam;

    int simplex_rand_factor;
    double simplex_tol;
    int simplex_mxiter;

    int sa_rand_factor;
    double sa_tol;
    int sa_mxiter;
    double sa_temp;
    int sa_cycle;
    double sa_decline;

    CVector start;
    
    // Best likelihood, parameter estimates
    double obest;
    CVector pbest;

};

#endif
