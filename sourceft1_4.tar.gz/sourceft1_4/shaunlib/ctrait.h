#ifndef __CTRAIT_H__
#define __CTRAIT_H__

#include <string>

using namespace std;

class CQTrait
{
 public:
   // FUNCTIONS

      CQTrait(); 
      ~CQTrait(); 

      string                  name;
      double                  mean;
      double                  var;
      double                  sibr;
      
      bool                    mean_set;
      bool                    var_set;
      bool                    sibr_set;

};

class CCovariate
{
 public:
    CCovariate::CCovariate();
    
    string                 name;
    double                 mean;
    double                 var;
    double                 sibr;
    
    bool                    mean_set;
    bool                    var_set;
    bool                    sibr_set;
    
};


class CBTrait
{
 public:
      CBTrait(); 
      ~CBTrait(); 

      string                 name;
      double                 prevalence;

      bool                    mean_set;
      bool                    prevalence_set;

};

#endif

