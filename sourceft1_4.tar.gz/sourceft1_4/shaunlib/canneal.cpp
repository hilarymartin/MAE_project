#include <iostream>

#include "canneal.h"

#include "crandom.h"

CAnneal::CAnneal(CFunction_ABC *f)
{
    userFunction = f;
    // and set sensible defaults...
}

void CAnneal::anneal()
{
   int i, iter, seed, bestseed, itemp ;
   double tempmult, temp, fval ;
   bool improved;
   
   // Initialise center to starting values
   cent = x;
 
   // Get function value at starting point
   bestfval = userFunction->func(x);

   temp = starttemp ;
   tempmult = exp ( log ( stoptemp / starttemp ) / (ntemps-1) ) ;

   // Temperature reduction loop
   for (itemp=0 ; itemp<ntemps ; itemp++) 
   {

       // Flags if this temp improved
       improved = false ;                          
       
       // Iterate within a given temperature
       for (iter=0 ; iter<niters ; iter++) 
       {   
	   
	   // Get and set random seed
	   seed = CRandom::rand(32000); // chanaged -- check
	   CRandom::srand(seed);
	 
	 // Perturb...
         shake(temp);

	 // ... and evaluate
         fval = userFunction->func(x);

	 // Check for improvement
	 if (fval < bestfval) 
	 {  
            bestfval = fval ;                         
            bestseed = seed ; // save seed that created the better fit
            improved = true ; 
	 
	    // Can we quit?
            if (bestfval <= fquit)                    // If we reached the user's
               break ;                                // limit, we can quit
	    
	    // If still improving, keep going at this temperature
            iter -= setback ;
            if (iter < 0)    
		iter = 0 ;    
	 }
	 
	 // Escape if get trapped
         if (! --maxcalls)
            break ;
       }

       // Did this temperature see an improvement?
       if (improved) 
       {                         
	   // Reset seed to best
	   CRandom::srand ( bestseed ) ; 
	   
	   // and recreate the point
	   shake (temp) ;  
	   
	   // This is the centre for the next temperature
	   cent = x;
	   
	   // Move away from this seed
	   CRandom::srand ( bestseed / 2 + 999 ) ;
       }

       // Can we quit?
      if (bestfval <= fquit)
         break ;
      
      // Or are we stuck?
      if (! maxcalls)
         break ;

      // Give some output for verbose mode
      if (verbose)
      {
	  cout << "\n Temp = " << temp;
	  cout << " and bestfval = " << bestfval;
	  cout << " and center is ";
	  cent.display();	  
	  cout << "\n";
      }


      // Reduce temperature for next loop
      temp *= tempmult ; 
   }                  
   
   // Return best point in x
   x = cent;
   
}


void CAnneal::shake(double temp)
{
   double r ;
   int n = ndim;
   
   temp *= 3.464101615 / 2 ;  // SQRT ( 12 ) = 3.464...
   
   while (n--) {
       r = CRandom::rand() + CRandom::rand() - CRandom::rand() - CRandom::rand() ;
       x[n+1] = cent[n+1] + temp * r ;
   }
}

